#!/usr/bin/env python3
"""The smart mirror.

Shows the mirrored camera image with the selected garment on the HDMI
monitor or projector, measures height and body widths, and starts the
touchscreen control panel (control_panel.py) on the 7" screen.

Keyboard, optional: M measure · C cancel · N / → next top · P / ← previous top
                    B next bottom (or none) · G clothes on/off · S skeleton on/off
                    Q / Esc quit

Run:  python run_mirror.py
"""
from __future__ import annotations

import argparse
import json
import os
import statistics
import subprocess
import sys
import threading
import time
from pathlib import Path

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")

import cv2  # noqa: E402

from mirror.arms import ArmTracker, show_arms  # noqa: E402
from mirror.camera import Camera  # noqa: E402
from mirror.config import Config, focal_length_px, load_config  # noqa: E402
from mirror.display import list_displays, open_window  # noqa: E402
from mirror.hardware import DistanceReader  # noqa: E402
from mirror.link import Receiver, Sender, parse_command  # noqa: E402
from mirror.measure import distance_from_feet, measure_pose, median_measurements, to_centimetres  # noqa: E402
from mirror.garments import load_garments, render_garment  # noqa: E402
from mirror.outfit import Outfit  # noqa: E402
from mirror.overlay import draw_skeleton  # noqa: E402
from mirror.pose import PoseTracker  # noqa: E402
from mirror.pose_guide import draw_banner, draw_measuring, draw_pose_guide  # noqa: E402
from mirror.posecheck import match_pose  # noqa: E402
from mirror.text import LABELS, distance_advice, whole  # noqa: E402
from mirror.tracker_loop import TrackerLoop  # noqa: E402
from mirror.turn import YawTracker, estimate_yaw  # noqa: E402

STATE_INTERVAL_S = 0.25  # how often the panel gets an update


class MirrorState:
    """Shared between the display loop and the measurement thread."""

    def __init__(self):
        self.lock = threading.Lock()
        self.phase = "idle"  # idle, pose (showing the pose to stand in) or measuring
        self.pose: dict | None = None   # {"score": 0..1, "parts": {...}} during the pose phase
        self.status = "Koppints a Mérés gombra az érintőképernyőn."
        self.result: dict | None = None

    def update(self, **values) -> None:
        with self.lock:
            for key, value in values.items():
                setattr(self, key, value)
        if "status" in values:
            print(values["status"])

    def snapshot(self) -> dict:
        with self.lock:
            return {"phase": self.phase, "pose": self.pose,
                    "status": self.status, "result": self.result}


class Measurer:
    def __init__(self, cfg: Config, loop: TrackerLoop, distance: DistanceReader, state: MirrorState):
        self.cfg, self.loop, self.distance, self.state = cfg, loop, distance, state
        self.f_px = focal_length_px(cfg.camera)
        self._cancel = threading.Event()

    def start(self) -> None:
        """Show the pose to stand in, then measure once the person stands in
        it. Ignored while a measurement is running."""
        with self.state.lock:
            if self.state.phase != "idle":
                return
            self.state.phase = "pose"
        self._cancel.clear()
        threading.Thread(target=self._run, daemon=True).start()

    def cancel(self) -> None:
        """Stops the pose guide. A running measurement takes only a second or two."""
        self._cancel.set()

    def _run(self) -> None:
        try:
            if self.wait_for_pose():
                self.state.update(phase="measuring", pose=None)
                self.measure()
        except Exception as exc:  # keep the mirror running whatever happens
            self.state.update(status=f"A mérés nem sikerült: {exc}")
        finally:
            self.state.update(phase="idle", pose=None)

    def wait_for_pose(self) -> bool:
        """Keeps the pose guide up until the person's pose has matched it by
        at least mirror.pose_match for mirror.pose_hold_s seconds. False when
        cancelled or after mirror.pose_timeout_s."""
        cfg = self.cfg.mirror
        deadline = time.monotonic() + cfg.pose_timeout_s
        held_since, last_pose, shown = None, None, None
        self.state.update(pose={"score": 0.0, "parts": {}},
                          status="Állj a padlón lévő vonalra, és vedd fel a képen látható pózt.")
        while not self._cancel.wait(0.05):
            now = time.monotonic()
            if now > deadline:
                self.state.update(status="Nem sikerült felvenni a pózt. Koppints újra a Mérés gombra.")
                return False
            _, pose, _ = self.loop.latest()
            if pose is last_pose:
                continue   # no newly tracked frame yet
            last_pose = pose
            match = match_pose(pose, estimate_yaw(pose))
            good = match.score >= cfg.pose_match
            if not good:
                held_since = None
            elif held_since is None:
                held_since = now
            values = {"pose": {"score": round(match.score, 3),
                               "parts": {k: round(v, 2) for k, v in match.parts.items()}}}
            text = "Remek, maradj így!" if good else (match.hint or "Vedd fel a képen látható pózt.")
            if text != shown:   # the status also goes to the terminal, so only when it changes
                values["status"] = shown = text
            self.state.update(**values)
            if good and now - held_since >= cfg.pose_hold_s:
                return True
        self.state.update(status="A mérés megszakítva.")
        return False

    def feet_distance(self, pose) -> float | None:
        """Distance to the person from where their feet touch the floor, once
        the camera's height and tilt are in config.json."""
        cfg = self.cfg.mirror
        if cfg.camera_height_m is None or cfg.camera_tilt_deg is None:
            return None
        return distance_from_feet(pose, self.f_px, cfg.camera_height_m, cfg.camera_tilt_deg,
                                  cfg.feet_to_body_center_m)

    def live_distance(self, pose) -> tuple[float | None, str | None]:
        """The distance to the middle of the person's body right now, for the
        touchscreen: from the ultrasonic sensor, or else from the feet."""
        sensor_m = self.distance.read()
        if sensor_m is not None:
            return sensor_m + self.cfg.mirror.sensor_to_body_center_m, "sensor"
        feet_m = self.feet_distance(pose)
        return (feet_m, "feet") if feet_m is not None else (None, None)

    def distance_for(self, poses) -> tuple[float, str]:
        """The ultrasonic sensor if it answers, else the feet, else the floor mark."""
        cfg = self.cfg.mirror
        sensor_m = self.distance.read()
        if sensor_m is not None:
            return sensor_m + cfg.sensor_to_body_center_m, "sensor"
        feet = [d for d in (self.feet_distance(p) for p in poses) if d is not None]
        if len(feet) >= max(3, len(poses) // 3):
            return statistics.median(feet), "feet"
        return cfg.fixed_distance_m, "floor mark"

    def measure(self) -> dict | None:
        cfg = self.cfg.mirror
        n = cfg.measure_frames
        self.state.update(status="Maradj így, mérek...")
        poses = self.loop.collect_poses(n, timeout=n * 0.5 + 5)
        distance_m, source = self.distance_for(poses)

        lines = self.cfg.lines.as_dict()
        tilt = cfg.camera_tilt_deg or 0.0
        combined = median_measurements([measure_pose(p, self.f_px, distance_m, lines, tilt) for p in poses])
        if combined is None:
            self.state.update(status="Nem látom a teljes alakodat. Lépj hátrébb, hogy a fejed és a lábfejed is látsszon.")
            return None

        result = to_centimetres(combined)
        result.update(time=time.strftime("%Y-%m-%d %H:%M:%S"), distance_m=round(distance_m, 3),
                      distance_source=source, frames=combined["frames"])
        with open(cfg.results_file, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(result) + "\n")
        self.state.update(result=result, status="Kész.")
        return result


def result_lines(result: dict) -> list[str]:
    """The result on the mirror, in whole centimetres."""
    height = result.get("height_cm")
    lines = [f"{LABELS['height']}: {whole(height)} cm" if height else f"{LABELS['height']}: -"]
    for name in ("chest", "waist", "hip"):
        value = result["width_cm"].get(name)
        if value:
            lines.append(f"{LABELS[name]}: {whole(value)} cm széles")
    legs = result.get("legs_cm") or {}
    for key in ("leg", "thigh"):
        if legs.get(key):
            wide = " széles" if key == "thigh" else ""
            lines.append(f"{LABELS[key]}: {whole(legs[key])} cm{wide}")
    return lines


def run_mirror(cfg: Config, loop: TrackerLoop, measurer: Measurer, state: MirrorState,
               windowed: bool) -> None:
    import pygame

    pygame.display.init()
    pygame.font.init()
    pygame.display.set_caption("ChangAR")
    screen = open_window(pygame, cfg.mirror.display_index,
                         cfg.mirror.fullscreen and not windowed, (600, 800))
    font = pygame.font.SysFont(None, 34)
    big = pygame.font.SysFont(None, 44)
    clock = pygame.time.Clock()

    garments = load_garments(cfg.mirror.garments_dir)
    print(f"{len(garments)} ruha betöltve innen: {cfg.mirror.garments_dir}/")
    outfit = Outfit([g.kind for g in garments])
    show_skeleton = False
    yaw_tracker, arm_tracker, last_pose, yaw, arms = YawTracker(), ArmTracker(), None, None, {}
    feet_m = None   # distance from the feet, smoothed
    feet_ready = cfg.mirror.camera_height_m is not None and cfg.mirror.camera_tilt_deg is not None
    if not feet_ready:
        print("A talp alapú távolsághoz futtasd a calibrate_floor.py-t; addig nem írom ki a távolságot.")

    try:
        commands = Receiver(cfg.panel.command_port)
    except OSError as exc:
        commands = None
        print(f"A(z) {cfg.panel.command_port} port foglalt ({exc}), így az érintőképernyő nem tudja vezérelni a tükröt.")
    panel = Sender(cfg.panel.state_port)
    next_state_at = 0.0

    def handle(command: str, arg: int | None) -> bool:
        nonlocal show_skeleton
        if command == "measure":
            measurer.start()
        elif command == "cancel":
            measurer.cancel()
        elif command in ("next", "prev"):
            outfit.step("top", 1 if command == "next" else -1)
        elif command == "bottom":
            outfit.step("bottom", 1)
        elif command == "select" and arg is not None:
            outfit.select(arg)
        elif command == "garment":
            outfit.toggle()
        elif command == "skeleton":
            show_skeleton = not show_skeleton
        elif command == "quit":
            return False
        return True

    keys = {pygame.K_m: "measure", pygame.K_c: "cancel", pygame.K_n: "next",
            pygame.K_RIGHT: "next", pygame.K_p: "prev", pygame.K_LEFT: "prev",
            pygame.K_b: "bottom", pygame.K_g: "garment", pygame.K_s: "skeleton", pygame.K_q: "quit",
            pygame.K_ESCAPE: "quit"}

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN and event.key in keys:
                running = handle(keys[event.key], None) and running
        if commands is not None:
            for packet in commands.poll():
                parsed = parse_command(packet)
                if parsed:
                    running = handle(*parsed) and running

        frame, pose, _ = loop.latest()
        snap = state.snapshot()
        if pose is not last_pose:   # a newly tracked frame: update the turn angle and the arms
            last_pose = pose
            if pose is None:
                yaw_tracker.reset()
            yaw = yaw_tracker.update(pose)
            arms = arm_tracker.update(pose)
            d = measurer.feet_distance(pose) if pose is not None else None
            feet_m = None if d is None else d if feet_m is None else 0.6 * feet_m + 0.4 * d

        screen.fill((0, 0, 0))
        if frame is not None:
            image = frame.copy()
            if pose is not None and outfit.visible and outfit.worn:
                for index in outfit.worn:   # bottom first, so the shirt hangs over it
                    render_garment(image, garments[index], pose, yaw, arms)
                # The person's own forearms and hands go over the clothes,
                # unless they're behind the body.
                show_arms(image, frame, pose, arms)
            if show_skeleton:
                draw_skeleton(image, pose)
            image = cv2.flip(image, 1)  # mirror
            rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            h, w = rgb.shape[:2]
            surface = pygame.image.frombuffer(rgb.tobytes(), (w, h), "RGB")
            sw, sh = screen.get_size()
            scale = min(sw / w, sh / h)
            size = (int(w * scale), int(h * scale))
            screen.blit(pygame.transform.scale(surface, size), ((sw - size[0]) // 2, (sh - size[1]) // 2))

        top = 12
        if pose is not None and feet_ready:   # where to stand, from the feet
            text, ok = distance_advice(feet_m, cfg.mirror.fixed_distance_m, cfg.mirror.distance_tolerance_m)
            top = draw_banner(pygame, screen, text, ok, top) + 8
        status = snap["status"] if snap["phase"] != "pose" else ""   # the pose guide shows it
        if show_skeleton and yaw is not None:
            status += f"   fordulás {yaw:+.0f}°"
        label = font.render(status.strip() or " ", True, (255, 255, 255), (0, 0, 0))
        if status.strip():
            screen.blit(label, (12, top))
        if snap["result"]:
            lines = result_lines(snap["result"])
            y = screen.get_height() - 12 - len(lines) * 46
            for text in lines:
                screen.blit(big.render(text, True, (255, 255, 255), (0, 0, 0)), (12, y))
                y += 46
        if snap["phase"] == "pose":
            draw_pose_guide(pygame, screen, snap["pose"], snap["status"], cfg.mirror.pose_match,
                            top=top + label.get_height() + 12)
        elif snap["phase"] == "measuring":
            draw_measuring(pygame, screen)

        now = time.monotonic()
        if now >= next_state_at:
            next_state_at = now + STATE_INTERVAL_S
            reading, source = measurer.live_distance(pose)
            panel.send_state({
                **snap,
                "worn": outfit.worn,
                "garment_count": len(garments),
                "show_garment": outfit.visible,
                "show_skeleton": show_skeleton,
                "person": pose is not None,
                "distance_m": round(reading, 2) if reading is not None else None,
                "distance_source": source,
                "fps": round(loop.fps, 1),
            })

        pygame.display.flip()
        clock.tick(30)

    panel.send_state({"phase": "idle", "status": "A tükör leállt.", "stopped": True})
    if commands is not None:
        commands.close()
    panel.close()
    pygame.quit()


def start_panel(config_path: str, windowed: bool) -> subprocess.Popen | None:
    command = [sys.executable, str(Path(__file__).with_name("control_panel.py")), "--config", config_path]
    if windowed:
        command.append("--windowed")
    try:
        return subprocess.Popen(command)
    except OSError as exc:
        print(f"Nem sikerült elindítani a vezérlőpanelt: {exc}")
        return None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", default="config.json")
    parser.add_argument("--camera-source", help='override camera.source, e.g. "0" or a video file')
    parser.add_argument("--windowed", action="store_true", help="windows instead of full screen")
    parser.add_argument("--no-panel", action="store_true", help="don't start the touchscreen panel")
    parser.add_argument("--list-displays", action="store_true", help="print the screens and exit")
    parser.add_argument("--measure-once", action="store_true",
                        help="measure once without any screen, print the result and exit")
    args = parser.parse_args()

    if args.list_displays:
        import pygame
        pygame.display.init()
        print("\n".join(list_displays(pygame)))
        return 0

    cfg = load_config(args.config)
    if args.camera_source:
        cfg.camera.source = args.camera_source
    Path(cfg.mirror.results_file).parent.mkdir(parents=True, exist_ok=True)

    camera = Camera(cfg.camera)
    loop = TrackerLoop(camera, PoseTracker(cfg.pose), track_every=cfg.pose.track_every)
    loop.start()
    state = MirrorState()
    distance = DistanceReader(cfg.mirror.ultrasonic_trigger_pin, cfg.mirror.ultrasonic_echo_pin)
    measurer = Measurer(cfg, loop, distance, state)

    panel = None
    try:
        if args.measure_once:
            time.sleep(1.0)  # let the camera and tracker settle
            result = measurer.measure()
            print(json.dumps(result, indent=2) if result else state.status)
            return 0 if result else 1
        if cfg.panel.enabled and not args.no_panel:
            panel = start_panel(args.config, args.windowed)
        run_mirror(cfg, loop, measurer, state, args.windowed)
    finally:
        if panel is not None:
            panel.terminate()
            try:
                panel.wait(timeout=3)
            except subprocess.TimeoutExpired:
                panel.kill()
        loop.stop()
        loop.join(timeout=2)   # let the tracking thread finish its frame first
        camera.close()
    return 0


if __name__ == "__main__":
    sys.exit(main())

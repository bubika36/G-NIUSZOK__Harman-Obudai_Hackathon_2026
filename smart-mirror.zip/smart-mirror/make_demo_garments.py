#!/usr/bin/env python3
"""Draws the demo garments and writes garments/garments.json.

Each T-shirt is modelled as an elliptical tube (the body of the shirt) with
sloping shoulders and a neckline, wrapped in a texture with its colour and
prints, and lit from the front. Rendering the same model every 15 degrees
gives views that match each other, so the shirt keeps its shape and its
print turns with the wearer. Each shirt also gets a sleeve (one picture,
used for both arms) and a thumbnail for the touchscreen.

The trousers and shorts are drawn the same way: the part from the waist to
the crotch is a shorter tube, rendered every 15 degrees, and each has one
straight leg picture that the mirror bends at the knee for both legs.

Sizes are in units of T, the distance from the shoulder joints down to the
hip joints, which is what the mirror fits the shirt to.
"""
from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

FOLDER = Path(__file__).parent / "garments"
T = 240               # pixels per torso length in the generated pictures
SS = 2                # supersampling, for smooth edges
VIEW_YAWS = tuple(range(-165, 181, 15))   # a view every 15 degrees, all the way round

# Shirt shape, in units of T. y runs down from the shoulder joints (0) to the
# hip joints (1).
HALF_WIDTH = 0.36     # chest, side to side
HALF_DEPTH = 0.23     # chest, front to back
SHOULDER_TOP = -0.12  # top of the shirt beside the neck
SHOULDER_DROP = 0.09  # how much lower the shoulder seam is at the sides
NECK_RADIUS = 0.12
NECK_FRONT = 0.13     # how deep the neckline dips at the front
NECK_BACK = 0.03
HEM = 1.05             # just below the hip joints, so trousers show
TOP_MARGIN = -0.16    # picture area above the shoulder line
BOTTOM = 1.10
RIB = 0.035           # collar and hem bands
SHOULDER_JOINTS = 0.64  # distance between the shoulder joints the shirt is made for

# Sleeve, in units of T
SLEEVE_TOP_WIDTH = 0.27
SLEEVE_END_WIDTH = 0.25
SLEEVE_CAP = 0.0      # the mirror sews the sleeve's top edge into the armhole
SLEEVE_LENGTH = 0.40  # shoulder joint to cuff

LIGHT = np.array([-0.35, 1.0]) / np.linalg.norm([-0.35, 1.0])  # (x, towards camera)


@dataclass
class Design:
    name: str
    folder: str
    base: tuple[int, int, int]                 # BGR
    trim: tuple[int, int, int]                 # collar, hem and cuffs
    stripes: tuple[int, int, int] | None = None
    logo: tuple[int, int, int] = (245, 245, 245)  # colour of the G-NIUSZOK print
    logo_panel: tuple[int, int, int] | None = None  # solid patch behind it (on stripes)
    logo_y: float = 0.30                       # height of the print, in T below the shoulders
    back: str | None = None                    # back print
    back_number: str | None = None             # a big player number under a name on the back
    pocket: bool = False


LOGO = "G-NIUSZOK"
LOGO_WIDTH = 0.50     # across the chest, in T

DESIGNS = [
    Design("Türkiz póló", "teal_tee", base=(140, 128, 20), trim=(115, 104, 14), back="SMART MIRROR"),
    Design("Piros csíkos póló", "red_stripes", base=(48, 42, 200), trim=(40, 34, 160), stripes=(240, 240, 240),
           logo_panel=(40, 34, 160)),
    Design("Fekete póló", "black_tee", base=(38, 36, 34), trim=(28, 27, 26), logo=(40, 200, 250), back="05"),
    Design("Napsárga póló", "sunny_yellow", base=(60, 200, 245), trim=(40, 170, 220), logo=(45, 45, 45),
           logo_y=0.42, pocket=True),
    Design("Haaland mez", "haaland_jersey", base=(221, 171, 108), trim=(80, 45, 25), logo=(250, 250, 250),
           back="HAALAND", back_number="9"),
]


# ---------- texture: the shirt unrolled, u around the body, v down ----------

TEX_W, TEX_H = 1440, int((BOTTOM - TOP_MARGIN) * T)


def tex_xy(u: float, y: float, top: float = TOP_MARGIN) -> tuple[int, int]:
    """Texture pixel for a point at angle-fraction u around the body and height
    y (in T), on a texture whose first row is at height `top`."""
    return int(u * TEX_W), int((y - top) * T)


def make_texture(d: Design, mirrored: bool) -> np.ndarray:
    """The shirt unrolled. With mirrored=True, text is drawn back to front, so
    it reads correctly once the mirror flips the picture."""
    tex = np.zeros((TEX_H, TEX_W, 3), np.uint8)
    tex[:] = d.base
    if d.stripes:
        for i in range(12):
            y0 = 0.10 + i * 0.12
            _, a = tex_xy(0, y0)
            _, b = tex_xy(0, y0 + 0.045)
            tex[a:b] = d.stripes
    if d.pocket:
        # on the wearer's left chest, which is the right of the picture from the front
        cx, cy = tex_xy(0.81, 0.24)
        w, h = int(0.13 * T), int(0.15 * T)
        cv2.rectangle(tex, (cx - w // 2, cy - h // 2), (cx + w // 2, cy + h // 2), d.trim, -1)
        cv2.rectangle(tex, (cx - w // 2, cy - h // 2), (cx + w // 2, cy - h // 2 + 6), d.base, -1)
    # u = 0.75 is the middle of the chest, u = 0.25 the middle of the back
    _print(tex, LOGO, 0.75, d.logo_y, LOGO_WIDTH, d.logo, mirrored, panel=d.logo_panel)
    if d.back and d.back_number:   # football shirt: name across the shoulders, number below
        _print(tex, d.back, 0.25, 0.10, 0.36, (240, 240, 240), mirrored)
        _print(tex, d.back_number, 0.25, 0.42, 0.20, (240, 240, 240), mirrored)
    elif d.back:
        short = len(d.back) <= 3
        _print(tex, d.back, 0.25, 0.36 if short else 0.12, 0.30 if short else 0.42, (240, 240, 240), mirrored)
    return tex


# Near the middle of the chest or back, one texture pixel across covers less
# shirt than one pixel down (the texture is laid out by angle around the
# body), so prints are stretched sideways to keep their shape.
STRETCH = (TEX_W / (2 * math.pi)) / (HALF_WIDTH * T)


def _print(tex, text, u, y, width_t, colour, mirrored, panel=None, top=TOP_MARGIN):
    """Text centred at u around the body and y down it, width_t wide on the shirt."""
    font, thickness = cv2.FONT_HERSHEY_DUPLEX, 3
    (tw, th), base = cv2.getTextSize(text, font, 2.0, thickness)
    stamp = np.zeros((th + base + 8, tw + 8), np.uint8)
    cv2.putText(stamp, text, (4, th + 4), font, 2.0, 255, thickness, cv2.LINE_AA)
    if mirrored:
        stamp = cv2.flip(stamp, 1)
    width = width_t * T * STRETCH
    height = width_t * T * stamp.shape[0] / stamp.shape[1]
    stamp = cv2.resize(stamp, (int(width), int(height)), interpolation=cv2.INTER_AREA)
    cx, cy = tex_xy(u, y, top)
    x0, y0 = cx - stamp.shape[1] // 2, cy - stamp.shape[0] // 2
    if panel is not None:
        pad_x, pad_y = int(0.04 * T * STRETCH), int(0.03 * T)
        cv2.rectangle(tex, (x0 - pad_x, y0 - pad_y), (x0 + stamp.shape[1] + pad_x, y0 + stamp.shape[0] + pad_y),
                      panel, -1)
    region = tex[y0:y0 + stamp.shape[0], x0:x0 + stamp.shape[1]].astype(np.float32)
    a = stamp[..., None].astype(np.float32) / 255
    tex[y0:y0 + stamp.shape[0], x0:x0 + stamp.shape[1]] = (region * (1 - a) + np.float32(colour) * a).astype(np.uint8)


# ---------- the shirt body seen from one angle ----------

def top_edge(xb: np.ndarray, zb: np.ndarray) -> np.ndarray:
    """Height of the shirt's top edge at body point (xb, zb): shoulders and neckline."""
    shoulder = SHOULDER_TOP + SHOULDER_DROP * (xb / HALF_WIDTH) ** 2
    inside_neck = np.clip(1 - (xb / NECK_RADIUS) ** 2, 0, None)
    neck = SHOULDER_TOP + np.where(zb > 0, NECK_FRONT, NECK_BACK) * np.sqrt(inside_neck)
    return np.where(inside_neck > 0, np.maximum(shoulder, neck), shoulder)


@dataclass
class Tube:
    """An elliptical tube (half-width a, half-depth b) turned by some angle,
    sampled on a supersampled pixel grid. For each pixel: whether the tube
    covers it, and where on the tube's near side it is."""
    w: int                 # picture size, before supersampling
    h: int
    X: np.ndarray          # position in T, across the picture (0 = middle)
    Y: np.ndarray          # and down it
    inside: np.ndarray
    near: np.ndarray       # angle around the tube of the visible surface
    xb: np.ndarray         # that point in body coordinates: side to side
    zb: np.ndarray         # and front (+) to back
    diffuse: np.ndarray    # how much it faces the light


def tube(yaw_deg: float, a: float, b: float, width_t: float, y_top: float, y_bottom: float) -> Tube:
    w, h = int(width_t * T), int((y_bottom - y_top) * T)
    ws, hs = w * SS, h * SS
    psi = math.radians(yaw_deg)
    xs = (np.arange(ws) + 0.5) / (SS * T) - width_t / 2
    ys = (np.arange(hs) + 0.5) / (SS * T) + y_top
    X, Y = np.meshgrid(xs, ys)

    # The tube's outline seen from this angle is an ellipse of half-width R.
    R = math.hypot(a * math.cos(psi), b * math.sin(psi))
    phi = math.atan2(b * math.sin(psi), a * math.cos(psi))
    inside = np.abs(X) <= R
    theta = np.arccos(np.clip(X / R, -1, 1))
    t1, t2 = theta - phi, -theta - phi

    def depth(t):  # towards the camera
        return a * np.cos(t) * math.sin(psi) + b * np.sin(t) * math.cos(psi)

    near = np.where(depth(t1) >= depth(t2), t1, t2)

    # Light: the surface normal of the tube, turned with the wearer
    nbx, nbz = b * np.cos(near), a * np.sin(near)
    norm = np.hypot(nbx, nbz) + 1e-9
    nx = (nbx * math.cos(psi) - nbz * math.sin(psi)) / norm
    nz = (nbx * math.sin(psi) + nbz * math.cos(psi)) / norm
    diffuse = np.clip(nx * LIGHT[0] + nz * LIGHT[1], 0, 1)
    return Tube(w, h, X, Y, inside, near, a * np.cos(near), b * np.sin(near), diffuse)


def render_view(d: Design, tex: np.ndarray, yaw_deg: float) -> tuple[np.ndarray, dict]:
    """The shirt body turned by yaw (0 = front, +90 = wearer's left side
    towards the camera, 180 = back), as BGRA, with its anchor points."""
    margin = 0.06
    width_t = 2 * (HALF_WIDTH + margin)
    tb = tube(yaw_deg, HALF_WIDTH, HALF_DEPTH, width_t, TOP_MARGIN, BOTTOM)
    w, h, Y, inside, near, diffuse = tb.w, tb.h, tb.Y, tb.inside, tb.near, tb.diffuse
    top_n = top_edge(tb.xb, tb.zb)

    # Only the outside of the shirt is drawn: through the neckline and above the
    # far shoulder the picture stays see-through, so the wearer's own neck and
    # shoulders show there.
    front = inside & (Y >= top_n) & (Y <= HEM)

    # Colour from the texture
    u = ((-np.degrees(near)) % 360) / 360
    tx = np.clip((u * TEX_W).astype(int), 0, TEX_W - 1)
    ty = np.clip(((Y - TOP_MARGIN) * T).astype(int), 0, TEX_H - 1)
    colour = tex[ty, tx].astype(np.float32)
    trim = np.array(d.trim, np.float32)
    band = ((Y - top_n) < RIB) | ((HEM - Y) < RIB)
    colour[band] = trim

    # Nearly flat light: no dark sides, so the body and sleeves blend together
    # and with the real person, whose own lighting shows around the shirt.
    shade = (0.90 + 0.10 * diffuse) * (1.0 - 0.04 * np.clip(Y, 0, HEM) / HEM)
    # soft folds around the waist
    shade *= 1 - 0.02 * np.sin(np.degrees(near) / 9) * np.clip((Y - 0.55) / 0.7, 0, 1)
    rgb = np.clip(colour * shade[..., None], 0, 255)
    alpha = front.astype(np.float32) * 255
    img = np.dstack([rgb, alpha]).astype(np.float32)
    img = cv2.resize(img, (w, h), interpolation=cv2.INTER_AREA)
    img = np.clip(img, 0, 255).astype(np.uint8)

    cx = w / 2
    y0 = -TOP_MARGIN * T
    return img, {"top": [round(cx, 1), round(y0, 1)], "bottom": [round(cx, 1), round(y0 + T, 1)]}


# ---------- sleeve ----------

def render_sleeve(d: Design) -> tuple[np.ndarray, dict]:
    """One short sleeve hanging straight down, seen from the side."""
    margin = 0.03
    w = int((SLEEVE_TOP_WIDTH + 2 * margin) * T)
    h = int((SLEEVE_CAP + SLEEVE_LENGTH + 2 * margin) * T)
    ws, hs = w * SS, h * SS
    X, Y = np.meshgrid((np.arange(ws) + 0.5) / (SS * T) - w / (2 * T),
                       (np.arange(hs) + 0.5) / (SS * T) - margin - SLEEVE_CAP)
    # Y: 0 at the shoulder joint, SLEEVE_LENGTH at the cuff
    frac = np.clip(Y / SLEEVE_LENGTH, 0, 1)
    half = (SLEEVE_TOP_WIDTH + (SLEEVE_END_WIDTH - SLEEVE_TOP_WIDTH) * frac) / 2
    across = X / half
    cap = (Y < 0) & ((X / (SLEEVE_TOP_WIDTH / 2)) ** 2 + (Y / max(SLEEVE_CAP, 1e-6)) ** 2 <= 1)
    body = (Y >= 0) & (Y <= SLEEVE_LENGTH) & (np.abs(across) <= 1)
    shape = cap | body

    colour = np.empty((hs, ws, 3), np.float32)
    colour[:] = d.base
    if d.stripes:
        for i in range(4):
            y0 = 0.04 + i * 0.12
            colour[(Y >= y0) & (Y < y0 + 0.045)] = d.stripes
    colour[(SLEEVE_LENGTH - Y) < RIB * 1.2] = d.trim
    nz = np.sqrt(np.clip(1 - np.clip(across, -1, 1) ** 2, 0, 1))
    diffuse = np.clip(np.clip(across, -1, 1) * LIGHT[0] + nz * LIGHT[1], 0, 1)
    rgb = np.clip(colour * (0.90 + 0.10 * diffuse)[..., None], 0, 255)
    img = np.dstack([rgb, shape.astype(np.float32) * 255])
    img = np.clip(cv2.resize(img, (w, h), interpolation=cv2.INTER_AREA), 0, 255).astype(np.uint8)
    cx = w / 2
    y0 = (margin + SLEEVE_CAP) * T
    return img, {"top": [round(cx, 1), round(y0, 1)], "bottom": [round(cx, 1), round(y0 + SLEEVE_LENGTH * T, 1)]}


# ---------- thumbnail ----------

def make_thumbnail(front: np.ndarray, front_anchors: dict, sleeve: np.ndarray, sleeve_anchors: dict) -> np.ndarray:
    """The front view with both sleeves hanging slightly outwards, cropped."""
    pad = int(0.35 * T)
    canvas = np.zeros((front.shape[0] + 2 * pad, front.shape[1] + 2 * pad, 4), np.float32)
    top = np.float32(front_anchors["top"]) + pad
    joint_half = SHOULDER_JOINTS / 2 * T
    s_top, s_bottom = np.float32(sleeve_anchors["top"]), np.float32(sleeve_anchors["bottom"])
    length = float(np.linalg.norm(s_bottom - s_top))
    for side, angle in ((+1, 38), (-1, -38)):
        shoulder = top + (side * joint_half, 0)
        direction = np.float32((math.sin(math.radians(angle)), math.cos(math.radians(angle))))
        dst = np.float32([shoulder, shoulder + direction * length,
                          shoulder + np.float32((direction[1], -direction[0])) * 10])
        src = np.float32([s_top, s_bottom, s_top + (10, 0)])
        matrix = cv2.getAffineTransform(src, dst)
        warped = cv2.warpAffine(sleeve, matrix, (canvas.shape[1], canvas.shape[0])).astype(np.float32)
        _over(canvas, warped)
    body = np.zeros_like(canvas)
    body[pad:pad + front.shape[0], pad:pad + front.shape[1]] = front
    _over(canvas, body)
    ys, xs = np.nonzero(canvas[..., 3] > 0)
    crop = canvas[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    return np.clip(crop, 0, 255).astype(np.uint8)


def _over(dst: np.ndarray, src: np.ndarray) -> None:
    a = src[..., 3:4] / 255
    dst[..., :3] = dst[..., :3] * (1 - a) + src[..., :3] * a
    dst[..., 3:4] = np.maximum(dst[..., 3:4], src[..., 3:4])


# ---------- trousers and shorts ----------
# y runs down from the shoulder joints (0) to the hip joints (1), in T, as for
# the shirts. The legs are measured down from the hip joint.

WAIST = 0.85            # top of the waistband
WAIST_BAND = 0.07
CROTCH = 1.20           # bottom of the waist piece in the middle...
CROTCH_RISE = 0.10      # ...and how much lower it reaches at the sides, over the legs
FEATHER = 0.06          # the waist piece fades out over this much at its bottom edge, into the legs
B_TOP = WAIST - 0.03    # picture area of the waist piece
B_BOTTOM = CROTCH + CROTCH_RISE + 0.03
HIP_HALF_WIDTH = HALF_WIDTH
HIP_HALF_DEPTH = 0.25
HIP_JOINTS = 0.40       # distance between the hip joints the trousers are made for
THIGH = 0.80            # hip joint to knee
SHIN = 0.80             # knee to ankle
LEG_TOP = -0.10         # the leg starts a little above the hip joint, under the waist piece
B_TEX_H = int((B_BOTTOM - B_TOP) * T)


@dataclass
class BottomDesign:
    name: str
    folder: str
    style: str                                  # jeans, chinos, joggers or shorts
    base: tuple[int, int, int]                  # BGR
    trim: tuple[int, int, int]                  # waistband and hems
    stitch: tuple[int, int, int]                # seams and pockets
    leg_widths: tuple[float, float, float]      # at the top, the knee and the hem, in T
    length: float                               # hip joint to hem, in T


BOTTOMS = [
    BottomDesign("Kék farmer", "blue_jeans", "jeans", base=(122, 74, 40), trim=(104, 62, 33),
                 stitch=(70, 150, 215), leg_widths=(0.36, 0.28, 0.27), length=THIGH + SHIN + 0.07),
    BottomDesign("Fekete chino", "black_chinos", "chinos", base=(44, 43, 42), trim=(34, 33, 32),
                 stitch=(62, 61, 60), leg_widths=(0.36, 0.29, 0.27), length=THIGH + SHIN + 0.07),
    BottomDesign("Szürke jogger", "grey_joggers", "joggers", base=(150, 147, 143), trim=(126, 123, 120),
                 stitch=(130, 127, 124), leg_widths=(0.37, 0.30, 0.21), length=THIGH + SHIN + 0.03),
    BottomDesign("Keki sort", "khaki_shorts", "shorts", base=(118, 168, 196), trim=(100, 148, 174),
                 stitch=(86, 128, 152), leg_widths=(0.38, 0.36, 0.36), length=0.50),
]


def _bx(u: float, dx_t: float = 0.0) -> int:
    """Texture column dx_t (in T, across the body) from angle-fraction u."""
    return int(u * TEX_W + dx_t * T * STRETCH)


def _by(y: float) -> int:
    return int((y - B_TOP) * T)


def make_bottom_texture(d: BottomDesign, mirrored: bool) -> np.ndarray:
    """The waist piece unrolled: u = 0.75 is the front, 0.25 the back."""
    tex = np.zeros((B_TEX_H, TEX_W, 3), np.uint8)
    tex[:] = d.base
    band_bottom = WAIST + WAIST_BAND
    tex[_by(WAIST):_by(band_bottom)] = d.trim
    line = max(2, T // 120)
    if d.style == "joggers":
        # ribbed elastic waistband, drawstrings and a G-NIUSZOK print on the left hip
        for x in range(0, TEX_W, 9):
            tex[_by(WAIST):_by(band_bottom), x:x + 3] = np.clip(np.int32(d.trim) - 10, 0, 255)
        for side in (-1, 1):
            x = _bx(0.75, side * 0.02)
            cv2.line(tex, (x, _by(band_bottom - 0.01)), (x + side * 6, _by(1.05)), (232, 232, 232), 5)
            cv2.rectangle(tex, (x + side * 6 - 4, _by(1.05)), (x + side * 6 + 4, _by(1.08)), (60, 60, 60), -1)
        _print(tex, LOGO, 0.75 + 0.17 * T * STRETCH / TEX_W, 1.05, 0.17, (60, 58, 56), mirrored, top=B_TOP)
        return tex

    # belt loops
    for u, dx in ((0.75, -0.11), (0.75, 0.11), (0.5, 0.0), (1.0, 0.0), (0.0, 0.0),
                  (0.25, -0.09), (0.25, 0.09), (0.25, 0.0)):
        x = _bx(u, dx)
        cv2.rectangle(tex, (x - 7, _by(WAIST - 0.01)), (x + 7, _by(band_bottom + 0.015)),
                      np.clip(np.int32(d.trim) - 8, 0, 255).tolist(), -1)
    # button and fly
    button = (60, 120, 190) if d.style == "jeans" else (28, 28, 28)
    cv2.circle(tex, (_bx(0.75), _by(WAIST + WAIST_BAND / 2)), 9, button, -1)
    fly = [(_bx(0.75, 0.035), _by(band_bottom)), (_bx(0.75, 0.035), _by(1.07)), (_bx(0.75, 0.005), _by(1.13))]
    cv2.polylines(tex, [np.int32(fly)], False, d.stitch, line, cv2.LINE_AA)
    cv2.line(tex, (_bx(0.75), _by(band_bottom)), (_bx(0.75), _by(CROTCH)),
             np.clip(np.int32(d.base) - 18, 0, 255).tolist(), line, cv2.LINE_AA)
    # front pockets: curved on jeans, slanted on the others
    for side in (-1, 1):
        if d.style == "jeans":
            pts = [(_bx(0.75, side * (0.10 + 0.09 * (1 - math.cos(t * math.pi / 2)))),
                    _by(band_bottom + 0.13 * math.sin(t * math.pi / 2))) for t in np.linspace(0, 1, 12)]
        else:
            pts = [(_bx(0.75, side * 0.13), _by(band_bottom)), (_bx(0.75, side * 0.19), _by(1.00))]
        cv2.polylines(tex, [np.int32(pts)], False, np.clip(np.int32(d.base) - 25, 0, 255).tolist(),
                      line + 1, cv2.LINE_AA)
        cv2.polylines(tex, [np.int32(pts) + (side * 5, 4)], False, d.stitch, line, cv2.LINE_AA)
    # back pockets
    for side in (-1, 1):
        cx = 0.25 + side * 0.075 * T * STRETCH / TEX_W
        if d.style == "jeans":
            half = 0.065
            pts = [(-half, 0.0), (half, 0.0), (half, 0.13), (0.0, 0.16), (-half, 0.13)]
            poly = np.int32([(_bx(cx, x), _by(band_bottom + 0.04 + y)) for x, y in pts])
            cv2.polylines(tex, [poly], True, d.stitch, line, cv2.LINE_AA)
            cv2.polylines(tex, [poly + (0, 6)], False, d.stitch, line, cv2.LINE_AA)
        else:
            y = _by(band_bottom + 0.06)
            cv2.line(tex, (_bx(cx, -0.055), y), (_bx(cx, 0.055), y),
                     np.clip(np.int32(d.base) - 25, 0, 255).tolist(), line + 2)
            cv2.circle(tex, (_bx(cx), y - 12), 5, (28, 28, 28), -1)
    if d.style == "jeans":
        # leather patch on the back of the waistband
        _print(tex, LOGO, 0.25 + 0.09 * T * STRETCH / TEX_W, WAIST + 0.045, 0.15, (225, 235, 245),
               mirrored, panel=(52, 92, 150), top=B_TOP)
    return tex


def render_waist_view(d: BottomDesign, tex: np.ndarray, yaw_deg: float) -> tuple[np.ndarray, dict]:
    """The part from the waist to the crotch, turned by yaw, as BGRA, with its
    anchors: the middle of the shoulder line (above the picture) and of the hip line."""
    margin = 0.06
    width_t = 2 * (HIP_HALF_WIDTH + margin)
    tb = tube(yaw_deg, HIP_HALF_WIDTH, HIP_HALF_DEPTH, width_t, B_TOP, B_BOTTOM)
    bottom_edge = CROTCH + CROTCH_RISE * (tb.xb / HIP_HALF_WIDTH) ** 2
    # Solid down to near the bottom edge, then fading out, so the edge
    # doesn't show where it lies over the legs.
    fade = np.clip((bottom_edge - tb.Y) / FEATHER, 0, 1)
    shape = (tb.inside & (tb.Y >= WAIST)) * fade
    u = ((-np.degrees(tb.near)) % 360) / 360
    tx = np.clip((u * TEX_W).astype(int), 0, TEX_W - 1)
    ty = np.clip(((tb.Y - B_TOP) * T).astype(int), 0, B_TEX_H - 1)
    colour = tex[ty, tx].astype(np.float32)
    rgb = np.clip(colour * (0.90 + 0.10 * tb.diffuse)[..., None], 0, 255)
    img = np.dstack([rgb, shape.astype(np.float32) * 255])
    img = np.clip(cv2.resize(img, (tb.w, tb.h), interpolation=cv2.INTER_AREA), 0, 255).astype(np.uint8)
    cx = tb.w / 2
    return img, {"top": [round(cx, 1), round(-B_TOP * T, 1)],
                 "bottom": [round(cx, 1), round((1 - B_TOP) * T, 1)]}


def render_leg(d: BottomDesign) -> tuple[np.ndarray, dict]:
    """One straight leg, seen from the front, its outer side on the right.
    Anchors: the hip joint (top), the knee and, for long legs, the ankle (bottom)."""
    margin = 0.03
    top_w, knee_w, hem_w = d.leg_widths
    w = int((max(d.leg_widths) + 2 * margin) * T)
    pic_top = LEG_TOP - margin
    h = int((d.length + margin - pic_top) * T)
    ws, hs = w * SS, h * SS
    X, Y = np.meshgrid((np.arange(ws) + 0.5) / (SS * T) - w / (2 * T),
                       (np.arange(hs) + 0.5) / (SS * T) + pic_top)
    if d.length > THIGH:
        width = np.where(Y <= THIGH, top_w + (knee_w - top_w) * np.clip(Y / THIGH, 0, 1),
                         knee_w + (hem_w - knee_w) * np.clip((Y - THIGH) / (d.length - THIGH), 0, 1))
    else:
        width = top_w + (hem_w - top_w) * np.clip(Y / d.length, 0, 1)
    half = width / 2
    across = X / half
    shape = (Y >= LEG_TOP) & (Y <= d.length) & (np.abs(across) <= 1)

    colour = np.empty((hs, ws, 3), np.float32)
    colour[:] = d.base
    base = np.float32(d.base)
    to_hem = d.length - Y
    if d.style == "jeans":
        # lighter, worn fronts of the thighs and knees, and the outer seam
        wear = np.exp(-(across / 0.55) ** 2) * (np.exp(-((Y - 0.35) / 0.28) ** 2)
                                               + 0.7 * np.exp(-((Y - THIGH) / 0.12) ** 2))
        colour += (np.float32((185, 140, 95)) - base) * (0.30 * wear)[..., None]
        seam = (across > 0.86) & (across < 0.92) & ((Y * 40 % 1) < 0.6)
        colour[seam] = d.stitch
        colour[(to_hem > 0.028) & (to_hem < 0.036)] = d.stitch
    elif d.style == "chinos":
        colour[np.abs(X) < 0.006] = np.clip(base + 16, 0, 255)   # pressed crease
        colour[(to_hem > 0.030) & (to_hem < 0.036)] = d.stitch
    elif d.style == "joggers":
        cuff = to_hem < 0.08
        colour[cuff] = d.trim
        colour[cuff & ((X * 70 % 1) < 0.35)] = np.clip(np.float32(d.trim) - 10, 0, 255)
    elif d.style == "shorts":
        colour[to_hem < 0.06] = d.trim
        colour[(to_hem > 0.064) & (to_hem < 0.072)] = d.stitch
    colour[to_hem < 0.006] = np.clip(np.float32(d.trim) - 12, 0, 255)

    a = np.clip(across, -1, 1)
    diffuse = np.clip(a * LIGHT[0] + np.sqrt(1 - a ** 2) * LIGHT[1], 0, 1)
    rgb = np.clip(colour * (0.90 + 0.10 * diffuse)[..., None], 0, 255)
    img = np.dstack([rgb, shape.astype(np.float32) * 255])
    img = np.clip(cv2.resize(img, (w, h), interpolation=cv2.INTER_AREA), 0, 255).astype(np.uint8)
    cx = w / 2

    def row(y):
        return round((y - pic_top) * T, 1)

    anchors = {"top": [round(cx, 1), row(0)], "knee": [round(cx, 1), row(THIGH)]}
    if d.length > THIGH:
        anchors["bottom"] = [round(cx, 1), row(THIGH + SHIN)]
    return img, anchors


def make_bottom_thumbnail(front: np.ndarray, front_anchors: dict, leg: np.ndarray, leg_anchors: dict) -> np.ndarray:
    """The front of the waist with both legs hanging slightly apart, cropped."""
    pad = int(0.25 * T)
    canvas = np.zeros((front.shape[0] + leg.shape[0] + pad, front.shape[1] + 2 * pad, 4), np.float32)
    hip_line = np.float32(front_anchors["bottom"]) + (pad, 0)
    leg_top = np.float32(leg_anchors["top"])
    for side in (+1, -1):    # the wearer's left leg is on the right of the picture
        hip = hip_line + (side * HIP_JOINTS / 2 * T, 0)
        angle = math.radians(3 * side)
        down = np.float32((math.sin(angle), math.cos(angle)))
        # Where the leg picture's right (its outer side) goes: outwards, so the
        # right leg is the left one mirrored.
        outwards = side * np.float32((down[1], -down[0]))
        dst = np.float32([hip, hip + down * 10, hip + outwards * 10])
        src = np.float32([leg_top, leg_top + (0, 10), leg_top + (10, 0)])
        matrix = cv2.getAffineTransform(src, dst)
        warped = cv2.warpAffine(leg, matrix, (canvas.shape[1], canvas.shape[0])).astype(np.float32)
        _over(canvas, warped)
    waist = np.zeros_like(canvas)
    waist[:front.shape[0], pad:pad + front.shape[1]] = front
    _over(canvas, waist)
    ys, xs = np.nonzero(canvas[..., 3] > 0)
    crop = canvas[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    return np.clip(crop, 0, 255).astype(np.uint8)


def draw_bottom(d: BottomDesign) -> dict:
    out = FOLDER / d.folder
    out.mkdir(exist_ok=True)
    tex = make_bottom_texture(d, mirrored=True)
    views = []
    for yaw in VIEW_YAWS:
        img, anchors = render_waist_view(d, tex, yaw)
        name = f"yaw_{yaw:+04d}.png".replace("+000", "000")
        cv2.imwrite(str(out / name), img)
        views.append({"yaw": yaw, "image": f"{d.folder}/{name}", **anchors})
    leg, leg_anchors = render_leg(d)
    cv2.imwrite(str(out / "leg.png"), leg)
    plain_front, front_anchors = render_waist_view(d, make_bottom_texture(d, mirrored=False), 0)
    cv2.imwrite(str(out / "thumbnail.png"), make_bottom_thumbnail(plain_front, front_anchors, leg, leg_anchors))
    print(f"Megrajzolva: {d.name}: {len(views)} nézet, szár, bélyegkép")
    return {
        "name": d.name,
        "kind": "bottom",
        "thumbnail": f"{d.folder}/thumbnail.png",
        "hip_width": HIP_JOINTS,
        "views": views,
        "leg": {"image": f"{d.folder}/leg.png", **leg_anchors},
    }


def main() -> None:
    FOLDER.mkdir(exist_ok=True)
    index = []
    for d in DESIGNS:
        out = FOLDER / d.folder
        out.mkdir(exist_ok=True)
        tex = make_texture(d, mirrored=True)
        views = []
        for yaw in VIEW_YAWS:
            img, anchors = render_view(d, tex, yaw)
            name = f"yaw_{yaw:+04d}.png".replace("+000", "000")
            cv2.imwrite(str(out / name), img)
            views.append({"yaw": yaw, "image": f"{d.folder}/{name}", **anchors})
            if yaw == 0:
                front_anchors = anchors
        sleeve, sleeve_anchors = render_sleeve(d)
        cv2.imwrite(str(out / "sleeve.png"), sleeve)
        # The touchscreen isn't a mirror: its thumbnail has the text the right way round.
        plain_front, _ = render_view(d, make_texture(d, mirrored=False), 0)
        cv2.imwrite(str(out / "thumbnail.png"), make_thumbnail(plain_front, front_anchors, sleeve, sleeve_anchors))
        index.append({
            "name": d.name,
            "thumbnail": f"{d.folder}/thumbnail.png",
            "shoulder_width": SHOULDER_JOINTS,
            "views": views,
            "sleeve": {"image": f"{d.folder}/sleeve.png", **sleeve_anchors},
        })
        print(f"Megrajzolva: {d.name}: {len(views)} nézet, ujj, bélyegkép")
    for d in BOTTOMS:
        index.append(draw_bottom(d))
    (FOLDER / "garments.json").write_text(json.dumps(index, indent=2, ensure_ascii=False) + "\n",
                                         encoding="utf-8")
    print(f"Kiírva: {FOLDER / 'garments.json'}")


if __name__ == "__main__":
    main()

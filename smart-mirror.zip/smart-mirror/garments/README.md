# Garments

There are two kinds: **tops** and **bottoms**. One of each is worn at a time,
the top drawn over the bottom.

- A **top** is the body of the shirt seen from several angles, plus one
  sleeve picture that's used for both arms. The mirror works out how far the
  person has turned, picks the matching view (blending between neighbours)
  and fits it between the middle of their shoulders and the middle of their
  hips. Each sleeve is pinned to a shoulder and turned along the upper arm,
  so it moves with the arm.
- A **bottom** is the part from the waist to the crotch, seen from several
  angles and fitted the same way, plus one leg picture used for both legs.
  Each leg is bent to run from the hip joint through the knee to the ankle,
  so it follows the legs when they bend, step or kick.

The demo garments here are drawn by `make_demo_garments.py`, with a view every
15 degrees and G-NIUSZOK on the shirts (and on the jeans' back patch and the
joggers). Run it again after changing the designs at the top of that file.

## garments.json

```json
[
  {
    "name": "Blue T-shirt",
    "thumbnail": "blue_tshirt/thumbnail.png",
    "shoulder_width": 0.64,
    "views": [
      {"yaw": 0,   "image": "blue_tshirt/front.png", "top": [100, 38], "bottom": [100, 278]},
      {"yaw": 90,  "image": "blue_tshirt/left.png",  "top": [100, 38], "bottom": [100, 278]},
      {"yaw": 180, "image": "blue_tshirt/back.png",  "top": [100, 38], "bottom": [100, 278]},
      {"yaw": -90, "image": "blue_tshirt/right.png", "top": [100, 38], "bottom": [100, 278]}
    ],
    "sleeve": {"image": "blue_tshirt/sleeve.png", "top": [43, 15], "bottom": [43, 111]}
  },
  {
    "name": "Grey trousers",
    "kind": "bottom",
    "thumbnail": "grey_trousers/thumbnail.png",
    "hip_width": 0.40,
    "views": [
      {"yaw": 0,   "image": "grey_trousers/front.png", "top": [100, -197], "bottom": [100, 43]},
      {"yaw": 90,  "image": "grey_trousers/left.png",  "top": [100, -197], "bottom": [100, 43]},
      {"yaw": 180, "image": "grey_trousers/back.png",  "top": [100, -197], "bottom": [100, 43]},
      {"yaw": -90, "image": "grey_trousers/right.png", "top": [100, -197], "bottom": [100, 43]}
    ],
    "leg": {"image": "grey_trousers/leg.png", "top": [50, 31], "knee": [50, 223], "bottom": [50, 415]}
  }
]
```

- **`kind`**: `"top"` (the default) or `"bottom"`. The touchscreen shows them
  on separate tabs.
- **`yaw`**: which way the wearer faces in that picture, in degrees.
  0 is the front, 90 is the wearer's **left** side towards the camera,
  -90 their right side, 180 the back. More views give smoother turning; four
  is the minimum that works well.
- **`top` and `bottom`** of a view (pixels from the picture's top-left
  corner): the middle of the shoulder line, level with the shoulder joints,
  and the middle of the hip line, level with the hip joints. The mirror lines
  these up with the person's own shoulders and hips. Bottoms use the same two
  points, so tops and bottoms grow and shrink together; for a bottom, the
  shoulder point is above the picture (a negative `y`).
- **`sleeve`** (tops): a short sleeve hanging straight down. `top` is where it
  meets the shoulder joint, `bottom` the middle of the cuff.
- **`leg`** (bottoms): the wearer's **left** leg hanging straight down, seen
  from the front, so its outer side is on the right of the picture (the
  mirror flips it for the right leg). `top` is the hip joint, `knee` the
  knee and `bottom` the ankle, all on the leg's centre line, and the leg is
  stretched to fit between them. For shorts, leave out `bottom`: the leg then
  hangs from the hip towards the knee, and `knee` can be below the picture.
  Start the leg a little above the hip joint, so it tucks under the waist piece.
- **`thumbnail`** (optional): what the touchscreen shows. Without it, the
  front view is used.
- **`shoulder_width`** (tops) and **`hip_width`** (bottoms), optional: the
  distance between the shoulder joints (or hip joints) the garment is made
  for, as a fraction of the top-to-bottom distance. When the person faces
  the camera, the garment is widened or narrowed a little to match theirs.

All pictures are PNGs with a transparent background.

## Real garment photos

1. Put the garment on a person or mannequin against a plain background, arms
   (and legs, for trousers) slightly away from the body.
2. Photograph it every 45 degrees (or more often) while they turn on the
   spot, with the camera at chest height (hip height for trousers) and the
   same distance each time.
3. Photograph one sleeve or one leg on its own, or cut it out of the front
   photo. For trousers, cut the views off just below the crotch: the legs are
   drawn separately.
4. Remove the backgrounds (any background-removal tool), save as PNGs, and
   read the pixel positions in an image editor.

The mirror flips the picture like a real mirror, so text on a garment reads
back to front on the screen. For text that reads correctly in the mirror,
flip the views horizontally (and swap the 90 and -90 pictures), as the demo
garments do. The thumbnail stays unflipped.

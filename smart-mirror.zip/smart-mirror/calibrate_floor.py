#!/usr/bin/env python3
"""Measure how far the camera looks down, so the mirror can work out how far
away a person is from where their feet touch the floor.

The mirror uses this distance when the ultrasonic sensor gives no reading,
and allows for the tilt in every measurement. Run it once, with the camera
mounted the way it will be used, and again whenever the camera is moved:

1. Measure the height of the camera lens above the floor with a tape.
2. Stop the mirror (only one program can use the camera at a time).
3. Run the line below, then stand on the floor mark facing the camera, with
   your whole body in view, until it says it's done. The floor mark is
   mirror.fixed_distance_m from the camera.

Run:  python calibrate_floor.py --camera-height 1.95

It saves mirror.camera_height_m and mirror.camera_tilt_deg in config.json.
"""
from __future__ import annotations

import argparse
import json
import statistics
import sys
import time
from pathlib import Path

from mirror.camera import Camera
from mirror.config import focal_length_px, load_config
from mirror.measure import feet_cut_off, floor_row, tilt_for_floor_distance
from mirror.pose import PoseTracker
from mirror.text import number


def save_settings(path: Path, values: dict) -> None:
    """Writes values into the "mirror" section of config.json, keeping everything else."""
    data = json.loads(path.read_text(encoding="utf-8")) if path.exists() else {}
    data.setdefault("mirror", {}).update(values)
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", default="config.json")
    parser.add_argument("--camera-source", help='override camera.source, e.g. "0" or a video file')
    parser.add_argument("--camera-height", type=float,
                        help="height of the camera lens above the floor, in metres")
    parser.add_argument("--frames", type=int, default=30, help="how many frames to measure the feet in")
    parser.add_argument("--wait", type=int, default=10, help="seconds to walk to the floor mark")
    args = parser.parse_args()

    cfg = load_config(args.config)
    if args.camera_source:
        cfg.camera.source = args.camera_source
    height = args.camera_height or cfg.mirror.camera_height_m
    if not height:
        print("Mérd meg mérőszalaggal, milyen magasan van a kamera lencséje a padló felett, és add meg a "
              "--camera-height kapcsolóval, méterben, tizedesponttal, például: "
              "python calibrate_floor.py --camera-height 1.95")
        return 1
    if not 0.3 <= height <= 3.0:
        print(f"A(z) {height} nem tűnik méterben megadott kameramagasságnak (195 cm esetén 1.95-öt adj meg).")
        return 1

    camera = Camera(cfg.camera)
    tracker = PoseTracker(cfg.pose)
    rows, frame_h = [], None
    try:
        for left in range(args.wait, 0, -1):
            print(f"Állj a padlón lévő vonalra, arccal a kamera felé, teljes alakban a képen. Kezdés {left} mp múlva...")
            time.sleep(1)
        print("Mérés: maradj mozdulatlanul...")
        deadline = time.monotonic() + args.frames + 20
        while len(rows) < args.frames and time.monotonic() < deadline:
            frame = camera.read()
            if frame is None:
                continue
            pose = tracker.process(frame, int(time.monotonic() * 1000))
            if pose is None or pose.mask is None or feet_cut_off(pose.mask):
                continue
            row = floor_row(pose.mask)
            if row is not None:
                rows.append(row)
                frame_h = pose.mask.shape[0]
                if len(rows) % 10 == 0:
                    print(f"  {len(rows)}/{args.frames}")
    except KeyboardInterrupt:
        pass
    finally:
        camera.close()
        tracker.close()

    if len(rows) < 5:
        print("Nem látom a lábfejedet. Ellenőrizd, hogy a teljes alakod a lábfejeddel együtt rajta van-e a képen, "
              "és hogy más ne legyen a képen, aztán próbáld újra.")
        return 1

    row = statistics.median(rows)
    f_px = focal_length_px(cfg.camera)
    feet_m = cfg.mirror.fixed_distance_m - cfg.mirror.feet_to_body_center_m
    tilt = tilt_for_floor_distance(row, frame_h, f_px, height, feet_m)
    spread = max(rows) - min(rows)
    print(f"A talpad a(z) {frame_h} képpont magas kép {row:.0f}. képpontjánál éri a padlót "
          f"({len(rows)} képkockán {spread:.0f} képpontot mozgott).")
    print(f"A kamera {number(abs(tilt), 1)} fokkal {'lefelé' if tilt >= 0 else 'felfelé'} néz.")
    if not -10 <= tilt <= 60:
        print("Ez szokatlan: ellenőrizd a camera_height_m, a mirror.fixed_distance_m és a camera.rotate "
              "beállítást. Nem mentettem el.")
        return 1
    if spread > 0.03 * frame_h:
        print("A lábfejed sokat mozgott a képkockák között; a pontosabb eredményért futtasd újra, mozdulatlanul állva.")
    save_settings(Path(args.config), {"camera_height_m": round(height, 3), "camera_tilt_deg": round(tilt, 1)})
    print(f"A camera_height_m és a camera_tilt_deg elmentve ide: {args.config}. Mostantól a tükör a talp "
          f"alapján számolja a távolságot, ha az ultrahangos szenzor nem ad értéket.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

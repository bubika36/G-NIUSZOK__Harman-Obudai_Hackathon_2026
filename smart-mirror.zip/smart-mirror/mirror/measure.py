"""Height, body widths and leg sizes from the camera image, and the distance
to the person from where their feet touch the floor.

Pure geometry with no camera code, so it can be tested on a laptop.

How it works:
- The person's outline (segmentation mask) gives sizes in pixels.
- Pixels become metres with the pinhole camera rule:
  size_m = size_px * distance_m / focal_length_px
  When the camera's tilt is known, each picture row is turned into an angle
  below the horizon first, so a camera looking down at the person doesn't
  make their legs look shorter than their head.
- Height runs from the top of the outline to the bottom; widths are taken
  across the outline at the chest, waist and hip lines, which are placed
  between the shoulder and hip landmarks.
- Legs: the leg length runs from the hip joints to the floor; the inside leg
  from the crotch (where the gap between the legs ends) to the floor; the
  thigh width is taken just below the crotch. The legs need to be slightly
  apart for the crotch and thighs.
- Distance from the feet: the bottom of the outline is where the feet touch
  the floor. With the camera's height and tilt, its row in the picture gives
  how far away that is.
"""
from __future__ import annotations

import math
import statistics
from dataclasses import dataclass

import numpy as np

from .pose import LEFT_HIP, LEFT_KNEE, LEFT_SHOULDER, RIGHT_HIP, RIGHT_KNEE, RIGHT_SHOULDER, Pose

MASK_THRESHOLD = 0.5
# An outline this close to the picture's edge is probably cut off by it.
EDGE_MARGIN_PX = 2
# The thigh width is taken this far below the crotch, as a fraction of the
# hip-to-knee length.
THIGH_BELOW_CROTCH = 0.08
# Feet this close to the horizon (or above it) can't be on the floor.
MIN_FLOOR_ANGLE_DEG = 3.0
LEG_NAMES = ("leg", "inside_leg", "thigh")


@dataclass
class Geometry:
    """Where the camera is, for turning picture rows and pixels into metres.

    distance_m is the horizontal distance from the camera to the person.
    tilt_deg is how far the camera looks down (0 = straight ahead)."""
    f_px: float
    frame_h: int
    distance_m: float
    tilt_deg: float = 0.0

    def angle_below(self, row: float) -> float:
        """Angle below the horizon of the line from the camera through this row, in radians."""
        return math.radians(self.tilt_deg) + math.atan((row - self.frame_h / 2) / self.f_px)

    def drop_m(self, row: float) -> float:
        """How far below the camera a point of the person seen at this row is."""
        return self.distance_m * math.tan(self.angle_below(row))

    def length_m(self, top_row: float, bottom_row: float) -> float:
        """Vertical length on the person between two rows."""
        return self.drop_m(bottom_row) - self.drop_m(top_row)

    def width_m(self, width_px: float, row: float) -> float:
        """Horizontal width on the person of width_px pixels at this row."""
        tilt = math.radians(self.tilt_deg)
        depth = self.distance_m * math.cos(tilt) + self.drop_m(row) * math.sin(tilt)
        return width_px * depth / self.f_px


# ---------- the outline ----------

def _rows(mask: np.ndarray) -> np.ndarray:
    return np.flatnonzero((mask >= MASK_THRESHOLD).any(axis=1))


def head_cut_off(mask: np.ndarray) -> bool:
    rows = _rows(mask)
    return rows.size > 0 and rows[0] <= EDGE_MARGIN_PX


def feet_cut_off(mask: np.ndarray) -> bool:
    rows = _rows(mask)
    return rows.size > 0 and rows[-1] >= mask.shape[0] - 1 - EDGE_MARGIN_PX


def cut_off(mask: np.ndarray) -> bool:
    """True when the outline touches the top or bottom of the picture: the head
    or feet are outside it, so the height would be measured to the frame's edge."""
    return head_cut_off(mask) or feet_cut_off(mask)


def outline_height_px(mask: np.ndarray) -> float | None:
    """Top of the head to the bottom of the feet. Pose landmarks stop at the
    eyes and ears, so the outline is the only way to find the top of the head."""
    rows = _rows(mask)
    if rows.size == 0:
        return None
    return float(rows[-1] - rows[0] + 1)


def floor_row(mask: np.ndarray) -> float | None:
    """The bottom edge of the outline: where the feet touch the floor."""
    rows = _rows(mask)
    return float(rows[-1] + 1) if rows.size else None


def _pair_y(pose: Pose, a: int, b: int) -> float | None:
    """Average height of a left/right landmark pair, using only the visible ones."""
    ys = [pose.points[i, 1] for i in (a, b) if pose.visible(i)]
    return float(np.mean(ys)) if ys else None


def body_lines(pose: Pose, lines: dict[str, float]) -> dict[str, float] | None:
    """Image row of each measurement line (chest, waist, hip)."""
    shoulder_y = _pair_y(pose, LEFT_SHOULDER, RIGHT_SHOULDER)
    hip_y = _pair_y(pose, LEFT_HIP, RIGHT_HIP)
    if shoulder_y is None or hip_y is None or hip_y <= shoulder_y:
        return None
    return {name: shoulder_y + t * (hip_y - shoulder_y) for name, t in lines.items()}


def torso_center_x(pose: Pose) -> float | None:
    xs = [pose.points[i, 0] for i in (LEFT_SHOULDER, RIGHT_SHOULDER, LEFT_HIP, RIGHT_HIP)
          if pose.visible(i)]
    return float(np.mean(xs)) if xs else None


def run_width_px(mask: np.ndarray, row: float, center_x: float, band: int = 2) -> float | None:
    """Width of the person's outline across one image row, measured outwards
    from center_x. Uses the median of a few neighbouring rows."""
    h, w = mask.shape
    c = int(round(center_x))
    if not 0 <= c < w:
        return None
    widths = []
    for r in range(int(round(row)) - band, int(round(row)) + band + 1):
        if not 0 <= r < h:
            continue
        inside = mask[r] >= MASK_THRESHOLD
        if not inside[c]:
            continue
        outside_left = np.flatnonzero(~inside[:c])
        outside_right = np.flatnonzero(~inside[c:])
        left = outside_left[-1] + 1 if outside_left.size else 0
        right = c + outside_right[0] - 1 if outside_right.size else w - 1
        if left <= EDGE_MARGIN_PX or right >= w - 1 - EDGE_MARGIN_PX:
            continue  # the body runs off the side of the picture
        widths.append(right - left + 1)
    return float(np.median(widths)) if widths else None


# ---------- legs ----------

def crotch_row(pose: Pose, mask: np.ndarray) -> float | None:
    """The top of the gap between the legs. Follows the line halfway between
    the legs up from the knees until it meets the body. None when the legs
    touch at the knees or the hips and knees can't be seen."""
    if not all(pose.visible(i) for i in (LEFT_HIP, RIGHT_HIP, LEFT_KNEE, RIGHT_KNEE)):
        return None
    hip = (pose.points[LEFT_HIP] + pose.points[RIGHT_HIP]) / 2
    knee = (pose.points[LEFT_KNEE] + pose.points[RIGHT_KNEE]) / 2
    if knee[1] - hip[1] < 10:
        return None
    h, w = mask.shape
    inside = mask >= MASK_THRESHOLD
    top = None
    for r in range(min(int(knee[1]), h - 1), max(int(hip[1]), -1), -1):
        t = (r - hip[1]) / (knee[1] - hip[1])
        c = int(round(hip[0] + t * (knee[0] - hip[0])))
        if not 1 <= c < w - 1 or inside[r, c - 1:c + 2].any():
            break
        top = r
    return float(top) if top is not None else None


def leg_sizes(pose: Pose, mask: np.ndarray, geo: Geometry) -> dict[str, float | None]:
    """Leg length (hip joints to the floor), inside leg (crotch to the floor)
    and thigh width, in metres; None for any that can't be seen."""
    sizes: dict[str, float | None] = dict.fromkeys(LEG_NAMES)
    floor = floor_row(mask)
    hip_y = _pair_y(pose, LEFT_HIP, RIGHT_HIP)
    if floor is None or hip_y is None or floor <= hip_y:
        return sizes
    sizes["leg"] = geo.length_m(hip_y, floor)
    crotch = crotch_row(pose, mask)
    if crotch is None:
        return sizes
    sizes["inside_leg"] = geo.length_m(crotch, floor)
    widths = []
    for hip, knee in ((LEFT_HIP, LEFT_KNEE), (RIGHT_HIP, RIGHT_KNEE)):
        (hx, hy), (kx, ky) = pose.points[hip], pose.points[knee]
        if ky - hy < 10:
            continue
        row = crotch + THIGH_BELOW_CROTCH * (ky - hy)
        t = (row - hy) / (ky - hy)
        px = run_width_px(mask, row, hx + t * (kx - hx), band=1)
        if px is not None:
            widths.append(geo.width_m(px, row))
    if widths:
        sizes["thigh"] = float(np.mean(widths))
    return sizes


# ---------- one frame, then a burst of frames ----------

def measure_pose(pose: Pose | None, f_px: float, distance_m: float,
                 lines: dict[str, float], tilt_deg: float = 0.0) -> dict | None:
    """Height, widths and leg sizes from one frame, in metres. None when the
    person isn't fully in the picture."""
    if pose is None or pose.mask is None or cut_off(pose.mask):
        return None
    rows = body_lines(pose, lines)
    center_x = torso_center_x(pose)
    if rows is None or center_x is None:
        return None
    geo = Geometry(f_px, pose.mask.shape[0], distance_m, tilt_deg)
    widths = {}
    for name, row in rows.items():
        px = run_width_px(pose.mask, row, center_x)
        widths[name] = geo.width_m(px, row) if px is not None else None
    outline = _rows(pose.mask)
    return {
        "height_m": geo.length_m(float(outline[0]), float(outline[-1] + 1)),
        "widths_m": widths,
        "legs_m": leg_sizes(pose, pose.mask, geo),
    }


def median_measurements(results: list[dict | None], min_valid: int = 3) -> dict | None:
    """Combine a burst of single-frame measurements into one, by median.
    The median ignores frames where the person moved or tracking slipped."""
    valid = [r for r in results if r]
    if len(valid) < min_valid:
        return None

    def med(values):
        values = [v for v in values if v is not None]
        return statistics.median(values) if len(values) >= min_valid else None

    names = valid[0]["widths_m"].keys()
    return {
        "height_m": med(r["height_m"] for r in valid),
        "widths_m": {n: med(r["widths_m"].get(n) for r in valid) for n in names},
        "legs_m": {n: med((r.get("legs_m") or {}).get(n) for r in valid) for n in LEG_NAMES},
        "frames": len(valid),
    }


def to_centimetres(measurement: dict) -> dict:
    """The final result shown on screen and saved: rounded centimetres."""
    def cm(value):
        return round(value * 100, 1) if value is not None else None

    result = {
        "height_cm": cm(measurement.get("height_m")),
        "width_cm": {name: cm(v) for name, v in measurement["widths_m"].items()},
    }
    if "legs_m" in measurement:
        result["legs_cm"] = {name: cm(v) for name, v in measurement["legs_m"].items()}
    return result


# ---------- distance from the feet ----------

def floor_distance_m(row: float, frame_h: int, f_px: float, camera_height_m: float,
                     tilt_deg: float) -> float | None:
    """Horizontal distance from the camera to the floor point seen at this row."""
    angle = math.radians(tilt_deg) + math.atan((row - frame_h / 2) / f_px)
    if angle < math.radians(MIN_FLOOR_ANGLE_DEG):
        return None
    return camera_height_m / math.tan(angle)


def tilt_for_floor_distance(row: float, frame_h: int, f_px: float, camera_height_m: float,
                            distance_m: float) -> float:
    """The camera tilt, in degrees, at which the floor seen at this row is
    distance_m away. Used to calibrate with someone standing on the floor mark."""
    return math.degrees(math.atan2(camera_height_m, distance_m) - math.atan((row - frame_h / 2) / f_px))


def distance_from_feet(pose: Pose | None, f_px: float, camera_height_m: float, tilt_deg: float,
                       feet_to_body_center_m: float) -> float | None:
    """Horizontal distance to the middle of the person's body, from where
    their feet touch the floor. None when the feet can't be seen."""
    if pose is None or pose.mask is None or feet_cut_off(pose.mask):
        return None
    row = floor_row(pose.mask)
    if row is None:
        return None
    d = floor_distance_m(row, pose.mask.shape[0], f_px, camera_height_m, tilt_deg)
    return d + feet_to_body_center_m if d is not None else None

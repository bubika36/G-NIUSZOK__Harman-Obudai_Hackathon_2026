"""Shared Hungarian text for the mirror and the touchscreen."""
from __future__ import annotations

import math

# Names of the measurements, as shown on both screens.
LABELS = {
    "height": "Magasság",
    "chest": "Mellkas",
    "waist": "Derék",
    "hip": "Csípő",
    "leg": "Lábhossz",          # hip joints to the floor
    "thigh": "Comb",
}


def whole(value: float) -> str:
    """A measurement rounded to the nearest whole number (halves round up): 175,5 -> 176."""
    return str(math.floor(value + 0.5))


def number(value: float, decimals: int | None = None) -> str:
    """A number written the Hungarian way, with a decimal comma: 175,3."""
    text = f"{value:.{decimals}f}" if decimals is not None else f"{value:g}"
    return text.replace(".", ",")


def distance_advice(distance_m: float | None, target_m: float, tolerance_m: float) -> tuple[str, bool]:
    """What the top of the mirror says about where the person stands, and
    whether it's right. distance_m is None when the feet can't be seen."""
    if distance_m is None:
        return "Lépj hátrébb, hogy a lábfejed is látsszon!", False
    shown = f"Távolság: {number(distance_m, 2)} m"
    off = distance_m - target_m
    if abs(off) <= tolerance_m:
        return f"{shown} – jó helyen állsz!", True
    step = max(5, round(abs(off) * 100 / 5) * 5)   # in 5 cm steps
    if off < 0:
        return f"{shown} – lépj hátrébb kb. {step} cm-t!", False
    return f"{shown} – lépj közelebb kb. {step} cm-t!", False

"""Where each arm is: in front of the body, behind it, or beside it.

MediaPipe's 3D body points say how far each joint is from the camera. An
elbow well in front of the body (an arm across the chest, or reaching
forward) puts the sleeve in front of the shirt; an elbow well behind it puts
the sleeve behind. A wrist well behind the body (hands behind the back) hides
the forearm behind the clothes; otherwise the person's own forearms and
hands go over the clothes, as they're outside the garment. "In front" and
"behind" are from the camera's point of view, so it also works when the
person turns their back to the mirror.

The depths are smoothed over a few frames, and an arm has to come further
forward to count as "in front" than it has to go back to stop counting, so
the sleeves don't flicker.

show_arms() copies the person's real arm below the sleeve, forearm and hand
from the camera picture back over the drawn garments.
"""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import numpy as np

from .pose import (
    LEFT_ELBOW,
    LEFT_HIP,
    LEFT_INDEX,
    LEFT_PINKY,
    LEFT_SHOULDER,
    LEFT_THUMB,
    LEFT_WRIST,
    RIGHT_ELBOW,
    RIGHT_HIP,
    RIGHT_INDEX,
    RIGHT_PINKY,
    RIGHT_SHOULDER,
    RIGHT_THUMB,
    RIGHT_WRIST,
    Pose,
)

FRONT, BACK = "front", "back"
# How far in front of (or behind) the middle of the body a joint has to come
# to count as in front (behind), and how far back it has to go to stop, in metres.
ENTER_M, LEAVE_M = 0.12, 0.08
SMOOTHING = 0.5

SIDES = {
    "left": (LEFT_SHOULDER, LEFT_ELBOW, LEFT_WRIST, LEFT_PINKY, LEFT_INDEX, LEFT_THUMB),
    "right": (RIGHT_SHOULDER, RIGHT_ELBOW, RIGHT_WRIST, RIGHT_PINKY, RIGHT_INDEX, RIGHT_THUMB),
}

# The real arm that's copied back, as fractions of the shoulder-to-hip length.
# A little narrower than a real arm, so the person's own shirt doesn't show
# around it.
SLEEVE_END = 0.46       # where the bare arm starts: just past the sleeve's cuff
UPPER_ARM_WIDTH = 0.17
ELBOW_WIDTH = 0.15
WRIST_WIDTH = 0.10
HAND_WIDTH = 0.15
THUMB_RADIUS = 0.045
FINGERS = 0.9           # fingers reach this much past the knuckles, relative to wrist-to-knuckles
FEATHER_PX = 2


@dataclass
class ArmPlace:
    sleeve: str | None = None    # FRONT, BACK or None (beside the body): from the elbow
    forearm: str | None = None   # the same, from the wrist


def _classify(previous: str | None, depth: float) -> str | None:
    """depth: metres from the middle of the body, negative towards the camera."""
    if previous == FRONT and depth < -LEAVE_M:
        return FRONT
    if previous == BACK and depth > LEAVE_M:
        return BACK
    if depth < -ENTER_M:
        return FRONT
    if depth > ENTER_M:
        return BACK
    return None


class ArmTracker:
    """Keeps track of where each arm is. Call update() with each newly tracked pose."""

    def __init__(self, smoothing: float = SMOOTHING):
        self.smoothing = smoothing
        self._depth: dict[tuple[str, str], float] = {}
        self.places: dict[str, ArmPlace] = {}

    def update(self, pose: Pose | None) -> dict[str, ArmPlace]:
        if pose is None or pose.world is None:
            self.reset()
            return self.places
        z = pose.world[:, 2]
        body = float(np.mean(z[[LEFT_SHOULDER, RIGHT_SHOULDER, LEFT_HIP, RIGHT_HIP]]))
        places = {}
        for side, (_, elbow, wrist, *_) in SIDES.items():
            previous = self.places.get(side, ArmPlace())
            values = {}
            for part, joint in (("sleeve", elbow), ("forearm", wrist)):
                if not pose.visible(joint):
                    values[part] = getattr(previous, part)   # out of sight: keep what it was
                    continue
                depth = float(z[joint]) - body
                key = (side, part)
                if key in self._depth:
                    depth = (1 - self.smoothing) * self._depth[key] + self.smoothing * depth
                self._depth[key] = depth
                values[part] = _classify(getattr(previous, part), depth)
            places[side] = ArmPlace(**values)
        self.places = places
        return places

    def reset(self) -> None:
        self._depth.clear()
        self.places = {}


# ---------- copying the real arms back over the garments ----------

def _segment(mask: np.ndarray, a, b, width_a: float, width_b: float) -> None:
    """A limb from a to b, width_a wide at a and width_b at b, with round ends."""
    a, b = np.float64(a), np.float64(b)
    d = b - a
    n = np.linalg.norm(d)
    if n >= 1:
        side = np.array([-d[1], d[0]]) / n
        quad = np.array([a + side * width_a / 2, b + side * width_b / 2,
                         b - side * width_b / 2, a - side * width_a / 2])
        cv2.fillConvexPoly(mask, np.round(quad).astype(np.int32), 255, cv2.LINE_AA)
    for point, width in ((a, width_a), (b, width_b)):
        cv2.circle(mask, tuple(int(round(v)) for v in point), max(1, int(round(width / 2))), 255, -1,
                   cv2.LINE_AA)


def _arm_segments(pose: Pose, places: dict[str, ArmPlace]) -> dict[str, list]:
    """For each arm, the parts of the person's own arm to show over the
    garments: (from, to, width at from, width at to) in pixels."""
    top = (pose.points[LEFT_SHOULDER] + pose.points[RIGHT_SHOULDER]) / 2
    bottom = (pose.points[LEFT_HIP] + pose.points[RIGHT_HIP]) / 2
    torso = float(np.linalg.norm(bottom - top))
    segments: dict[str, list] = {}
    if torso < 10:
        return segments
    for side, (shoulder, elbow, wrist, pinky, index, thumb) in SIDES.items():
        place = places.get(side, ArmPlace())
        if not (pose.visible(shoulder) and pose.visible(elbow)):
            continue
        parts = segments.setdefault(side, [])
        s, e = pose.points[shoulder].astype(np.float64), pose.points[elbow].astype(np.float64)
        upper = e - s
        length = float(np.linalg.norm(upper))
        # the bare upper arm, from just below the sleeve to the elbow
        if place.sleeve != BACK and length > 1:
            start = s + upper / length * min(SLEEVE_END * torso, 0.92 * length)
            if np.linalg.norm(e - start) > 1:
                parts.append((start, e, UPPER_ARM_WIDTH * torso, ELBOW_WIDTH * torso))
        if place.forearm == BACK or not pose.visible(wrist):
            continue
        w = pose.points[wrist].astype(np.float64)
        parts.append((e, w, ELBOW_WIDTH * torso, WRIST_WIDTH * torso))
        if pose.visible(pinky) and pose.visible(index):
            p, i = pose.points[pinky].astype(np.float64), pose.points[index].astype(np.float64)
            knuckles = (p + i) / 2
            hand = max(float(np.linalg.norm(i - p)) * 1.3, HAND_WIDTH * torso)
            parts.append((w, knuckles, WRIST_WIDTH * torso, hand))
            parts.append((knuckles, knuckles + (knuckles - w) * FINGERS, hand, hand * 0.8))
        if pose.visible(thumb):
            parts.append((w, pose.points[thumb].astype(np.float64), WRIST_WIDTH * torso * 0.6,
                          THUMB_RADIUS * 2 * torso))
    return segments


def arm_mask(shape: tuple[int, int], pose: Pose, places: dict[str, ArmPlace]) -> np.ndarray:
    """Where the person's own arms should show over the garments, 0-255, for the whole picture."""
    mask = np.zeros(shape, np.uint8)
    for parts in _arm_segments(pose, places).values():
        for a, b, wa, wb in parts:
            _segment(mask, a, b, wa, wb)
    return mask


def show_arms(frame: np.ndarray, original: np.ndarray, pose: Pose, places: dict[str, ArmPlace]) -> None:
    """Copies the person's own arms (below the sleeves), forearms and hands
    from the camera picture back over the garments drawn on `frame`, except
    the parts that are behind the body. Each arm is done in its own small
    box of the picture, which keeps it fast."""
    h, w = frame.shape[:2]
    pad = 2 * FEATHER_PX + 2
    for parts in _arm_segments(pose, places).values():
        if not parts:
            continue
        ends = np.array([p for a, b, _, _ in parts for p in (a, b)])
        reach = max(max(wa, wb) for _, _, wa, wb in parts) / 2 + pad
        x0, y0 = np.maximum(np.floor(ends.min(axis=0) - reach).astype(int), 0)
        x1, y1 = np.minimum(np.ceil(ends.max(axis=0) + reach).astype(int) + 1, [w, h])
        if x1 <= x0 or y1 <= y0:
            continue
        mask = np.zeros((y1 - y0, x1 - x0), np.uint8)
        origin = np.array([x0, y0], np.float64)
        for a, b, wa, wb in parts:
            _segment(mask, a - origin, b - origin, wa, wb)
        alpha = cv2.GaussianBlur(mask, (2 * FEATHER_PX + 1, 2 * FEATHER_PX + 1), 0).astype(np.float32) * (1 / 255)
        if pose.mask is not None and pose.mask.shape == (h, w):
            alpha *= np.clip(pose.mask[y0:y1, x0:x1], 0, 1)   # only the person, never the background
        a = alpha[:, :, None]
        region = frame[y0:y1, x0:x1].astype(np.float32)
        frame[y0:y1, x0:x1] = (region * (1 - a) + original[y0:y1, x0:x1].astype(np.float32) * a + 0.5
                               ).astype(np.uint8)

"""How closely the person stands in the pose the measurement needs.

The pose: the whole body in view, facing the camera, standing upright, arms
held away from the body (25-55 degrees out from the sides, like an A),
elbows and knees straight, feet a little apart. Arms against the body would
be counted in the chest and waist widths, and the legs need a gap between
them for the thigh.

match_pose() gives a score from 0 to 1, the score of each check (for
colouring the pose figure on the mirror), and a hint, in Hungarian, for the
first thing to fix.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

from .measure import cut_off
from .pose import (
    LEFT_ANKLE,
    LEFT_ELBOW,
    LEFT_HIP,
    LEFT_KNEE,
    LEFT_SHOULDER,
    LEFT_WRIST,
    NOSE,
    RIGHT_ANKLE,
    RIGHT_ELBOW,
    RIGHT_HIP,
    RIGHT_KNEE,
    RIGHT_SHOULDER,
    RIGHT_WRIST,
    Pose,
)

KEY_POINTS = (NOSE, LEFT_SHOULDER, RIGHT_SHOULDER, LEFT_ELBOW, RIGHT_ELBOW, LEFT_WRIST, RIGHT_WRIST,
              LEFT_HIP, RIGHT_HIP, LEFT_KNEE, RIGHT_KNEE, LEFT_ANKLE, RIGHT_ANKLE)
SIDES = {
    "left": (LEFT_SHOULDER, LEFT_ELBOW, LEFT_WRIST, LEFT_HIP, LEFT_KNEE, LEFT_ANKLE),
    "right": (RIGHT_SHOULDER, RIGHT_ELBOW, RIGHT_WRIST, RIGHT_HIP, RIGHT_KNEE, RIGHT_ANKLE),
}

# Target ranges, and how far outside them a check falls to zero.
ARM_ANGLE = (25.0, 55.0, 12.0)       # upper arm out from the side of the body, degrees
ELBOW_BEND = (20.0, 30.0)            # bent at most this much, then falling to zero over this much
KNEE_BEND = (15.0, 25.0)
LEAN = (8.0, 15.0)                   # leaning sideways
FEET_APART = (1.2, 2.6, 0.6, 1.0)    # ankles apart, in hip widths: low, high, falloff below, above
FACING = (20.0, 30.0)                # turned away from the camera, degrees

# How much each check counts. The arms count most: arms against the body
# spoil the widths. Being in view and facing the camera multiply the score.
WEIGHTS = {"arms": 4.0, "feet": 2.0, "elbows": 1.0, "knees": 1.0, "upright": 1.0}
GOOD = 0.8          # a check below this gets a hint
IN_VIEW_GOOD = 0.95

HINTS = {
    "in_view": "Állj úgy, hogy teljes alakban látsszon, fejtől talpig.",
    "facing": "Fordulj szembe a kamerával.",
    "arms_out": "Emeld el a karjaidat a testedtől, mint a képen.",
    "arms_down": "Engedd lejjebb a karjaidat, mint a képen.",
    "feet_apart": "Állj kis terpeszbe.",
    "feet_closer": "Kisebb terpeszben állj.",
    "elbows": "Nyújtsd ki a karjaidat.",
    "knees": "Egyenesítsd ki a lábaidat.",
    "upright": "Állj egyenesen.",
}


@dataclass
class PoseMatch:
    score: float                                   # 0..1
    parts: dict[str, float] = field(default_factory=dict)
    hint: str | None = None                        # None when nothing needs fixing


def _within(value: float, low: float, high: float, below: float, above: float) -> float:
    """1 inside [low, high], falling to 0 over `below` under it and `above` over it."""
    if value < low:
        return max(0.0, 1 - (low - value) / below) if below > 0 else 0.0
    if value > high:
        return max(0.0, 1 - (value - high) / above) if above > 0 else 0.0
    return 1.0


def _angle(a, b) -> float:
    """Angle between two vectors, in degrees."""
    a, b = np.asarray(a, np.float64), np.asarray(b, np.float64)
    na, nb = np.linalg.norm(a), np.linalg.norm(b)
    if na < 1e-6 or nb < 1e-6:
        return 180.0
    return math.degrees(math.acos(float(np.clip(np.dot(a, b) / (na * nb), -1, 1))))


def match_pose(pose: Pose | None, yaw: float | None) -> PoseMatch:
    """How well the pose matches; yaw is the turn angle from turn.estimate_yaw."""
    if pose is None:
        return PoseMatch(0.0, {}, HINTS["in_view"])
    p = pose.points.astype(np.float64)
    # Cubed, so that two or more body points out of view already fail the pose.
    in_view = (sum(pose.visible(i) for i in KEY_POINTS) / len(KEY_POINTS)) ** 3
    if pose.mask is not None and cut_off(pose.mask):
        in_view *= 0.5
    facing = _within(abs(yaw), 0, FACING[0], 0, FACING[1]) if yaw is not None else 0.5

    down = (p[LEFT_HIP] + p[RIGHT_HIP]) / 2 - (p[LEFT_SHOULDER] + p[RIGHT_SHOULDER]) / 2
    parts = {"in_view": in_view, "facing": facing,
             "upright": _within(_angle(down, (0, 1)), 0, LEAN[0], 0, LEAN[1])}
    arm_angles = {}
    for side, (shoulder, elbow, wrist, hip, knee, ankle) in SIDES.items():
        upper = p[elbow] - p[shoulder]
        arm_angles[side] = _angle(upper, down)
        parts[f"arm_{side}"] = _within(arm_angles[side], ARM_ANGLE[0], ARM_ANGLE[1], ARM_ANGLE[2], ARM_ANGLE[2])
        parts[f"elbow_{side}"] = _within(_angle(upper, p[wrist] - p[elbow]), 0, ELBOW_BEND[0], 0, ELBOW_BEND[1])
        parts[f"knee_{side}"] = _within(_angle(p[knee] - p[hip], p[ankle] - p[knee]), 0, KNEE_BEND[0], 0,
                                        KNEE_BEND[1])
    hip_width = float(np.linalg.norm(p[LEFT_HIP] - p[RIGHT_HIP]))
    apart = float(np.linalg.norm(p[LEFT_ANKLE] - p[RIGHT_ANKLE])) / max(hip_width, 1e-6)
    parts["feet"] = _within(apart, *FEET_APART)
    parts["arms"] = min(parts["arm_left"], parts["arm_right"])
    parts["elbows"] = min(parts["elbow_left"], parts["elbow_right"])
    parts["knees"] = min(parts["knee_left"], parts["knee_right"])

    weighted = sum(w * parts[name] for name, w in WEIGHTS.items()) / sum(WEIGHTS.values())
    return PoseMatch(weighted * in_view * facing, parts, _hint(parts, arm_angles, apart))


def _hint(parts: dict[str, float], arm_angles: dict[str, float], apart: float) -> str | None:
    if parts["in_view"] < IN_VIEW_GOOD:
        return HINTS["in_view"]
    if parts["facing"] < GOOD:
        return HINTS["facing"]
    if parts["arms"] < GOOD:
        return HINTS["arms_out"] if min(arm_angles.values()) < ARM_ANGLE[0] else HINTS["arms_down"]
    if parts["feet"] < GOOD:
        return HINTS["feet_apart"] if apart < FEET_APART[0] else HINTS["feet_closer"]
    for name in ("elbows", "knees", "upright"):
        if parts[name] < GOOD:
            return HINTS[name]
    return None

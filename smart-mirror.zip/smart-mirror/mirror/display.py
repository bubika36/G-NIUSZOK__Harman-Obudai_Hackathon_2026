"""Opening a full-screen window on a chosen screen (monitor or touchscreen)."""
from __future__ import annotations


def open_window(pygame, display_index: int, fullscreen: bool, windowed_size: tuple[int, int]):
    """Full screen on screen number `display_index`, or a normal window for
    testing. Falls back to the last screen if that number doesn't exist."""
    if not fullscreen:
        return pygame.display.set_mode(windowed_size, pygame.RESIZABLE)
    sizes = pygame.display.get_desktop_sizes()
    index = min(display_index, len(sizes) - 1)
    screen = pygame.display.set_mode(sizes[index], pygame.FULLSCREEN, display=index)
    pygame.mouse.set_visible(False)
    return screen


def list_displays(pygame) -> list[str]:
    return [f"display_index {i}: {w}x{h}" for i, (w, h) in enumerate(pygame.display.get_desktop_sizes())]

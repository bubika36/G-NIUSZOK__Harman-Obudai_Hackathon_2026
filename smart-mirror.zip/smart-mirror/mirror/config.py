"""Settings, loaded from config.json.

Every value has a default, so config.json only needs the values you change.
"""
from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass, field, fields, is_dataclass
from pathlib import Path


@dataclass
class CameraConfig:
    # "picamera2" for the Pi camera, a number like "0" for a USB webcam,
    # or a path to a video or image file for testing without a camera.
    source: str = "picamera2"
    width: int = 640
    height: int = 480
    # Degrees clockwise to turn each frame so the person stands upright.
    # The camera is mounted turned 90° for a portrait image.
    rotate: int = 90
    calibration_file: str = "camera_calibration.json"
    # Horizontal field of view of the sensor. Only used without a calibration
    # file. Camera Module 2: 62.2, Camera Module 3: 66, OV5647 (v1): 53.5.
    hfov_deg: float = 62.2


@dataclass
class PoseConfig:
    model_path: str = "models/pose_landmarker_lite.task"
    # Track every Nth frame. The picture still updates on every frame.
    track_every: int = 1
    min_confidence: float = 0.5


@dataclass
class BodyLines:
    """Where each width is measured, between the shoulder line (0.0)
    and the hip line (1.0). Tune these against tape-measured people."""
    chest: float = 0.25
    waist: float = 0.65
    hip: float = 1.0

    def as_dict(self) -> dict[str, float]:
        return asdict(self)


@dataclass
class MirrorConfig:
    # Which screen shows the mirror: the HDMI monitor or projector.
    # Check with: python run_mirror.py --list-displays
    display_index: int = 0
    fullscreen: bool = True
    garments_dir: str = "garments"
    # Ultrasonic sensor pins (BCM numbers). Set both to null to use
    # fixed_distance_m instead.
    ultrasonic_trigger_pin: int | None = 23
    ultrasonic_echo_pin: int | None = 24
    # Distance from the camera to the line on the floor where people stand:
    # the best distance. The top of the mirror tells people to step closer
    # or further back when they're more than distance_tolerance_m off it
    # (measured from their feet; needs calibrate_floor.py).
    fixed_distance_m: float = 2.4
    distance_tolerance_m: float = 0.15
    # The sensor measures to the front of the body; the outline the camera
    # sees is closer to the body's centre.
    sensor_to_body_center_m: float = 0.10
    # Distance from the feet, used when the ultrasonic sensor gives no reading.
    # camera_height_m: floor to the camera lens, measured with a tape.
    # camera_tilt_deg: how far the camera looks down (0 = straight ahead);
    # calibrate_floor.py measures it. With both set, the measurements also
    # allow for the tilt. Leave them null to use fixed_distance_m instead.
    camera_height_m: float | None = None
    camera_tilt_deg: float | None = None
    # The bottom of the outline is the tips of the toes; the middle of the
    # body is about this much further back.
    feet_to_body_center_m: float = 0.12
    measure_frames: int = 15
    # After tapping Measure, the mirror shows the pose to stand in, and
    # measures once the person's pose matches it by at least pose_match
    # (0-1) for pose_hold_s seconds. The guide gives up after pose_timeout_s.
    pose_match: float = 0.75
    pose_hold_s: float = 1.0
    pose_timeout_s: float = 120
    results_file: str = "measurements.jsonl"


@dataclass
class PanelConfig:
    # Start the touchscreen control panel together with the mirror.
    enabled: bool = True
    # Which screen is the 7" touchscreen.
    display_index: int = 1
    fullscreen: bool = True
    # Local ports between the mirror and the panel (this Pi only).
    command_port: int = 5056
    state_port: int = 5057


@dataclass
class Config:
    camera: CameraConfig = field(default_factory=CameraConfig)
    pose: PoseConfig = field(default_factory=PoseConfig)
    lines: BodyLines = field(default_factory=BodyLines)
    mirror: MirrorConfig = field(default_factory=MirrorConfig)
    panel: PanelConfig = field(default_factory=PanelConfig)


# Settings that older config.json files may still have; they're ignored.
RETIRED = {"mirror.measure_countdown_s", "sizes"}


def _merge(obj, values: dict, path: str = "") -> None:
    known = {f.name for f in fields(obj)}
    for key, value in values.items():
        if f"{path}{key}" in RETIRED:
            continue
        if key not in known:
            raise ValueError(f"Ismeretlen beállítás a config.json-ban: {path}{key}")
        current = getattr(obj, key)
        if is_dataclass(current):
            if not isinstance(value, dict):
                raise ValueError(f"A(z) {path}{key} beállításnak szakasznak kell lennie ({{...}})")
            _merge(current, value, f"{path}{key}.")
        else:
            setattr(obj, key, value)


def load_config(path: str | Path | None) -> Config:
    cfg = Config()
    if path and Path(path).exists():
        with open(path, encoding="utf-8") as fh:
            _merge(cfg, json.load(fh))
    if cfg.camera.rotate not in (0, 90, 180, 270):
        raise ValueError("A camera.rotate értéke csak 0, 90, 180 vagy 270 lehet")
    return cfg


def frame_size(cam: CameraConfig) -> tuple[int, int]:
    """(width, height) of the frames after rotation."""
    if cam.rotate in (90, 270):
        return cam.height, cam.width
    return cam.width, cam.height


def focal_length_px(cam: CameraConfig) -> float:
    """Focal length in pixels for the frames the pipeline sees.

    Uses the calibration file from calibrate_camera.py when there is one,
    otherwise works it out from the field of view (less accurate).
    """
    calib = Path(cam.calibration_file)
    if calib.exists():
        with open(calib, encoding="utf-8") as fh:
            data = json.load(fh)
        stored_long_side = max(data["frame_size"])
        return float(data["f_px"]) * max(frame_size(cam)) / stored_long_side
    return (cam.width / 2) / math.tan(math.radians(cam.hfov_deg) / 2)

"""Reads the camera and runs body tracking in a background thread."""
from __future__ import annotations

import threading
import time

from .camera import Camera
from .pose import Pose, PoseTracker


class TrackerLoop(threading.Thread):
    """Keeps the newest frame and pose. Other threads read them with latest(),
    or wait for a burst of fresh poses with collect_poses()."""

    def __init__(self, camera: Camera, tracker: PoseTracker, track_every: int = 1):
        super().__init__(daemon=True)
        self.camera = camera
        self.tracker = tracker
        self.track_every = max(1, int(track_every))
        self.fps = 0.0
        self._cond = threading.Condition()
        self._frame = None
        self._pose: Pose | None = None
        self._seq = 0
        self._fresh = False      # True when _pose was tracked on _frame
        self._collectors = 0     # while > 0, track every frame
        self._running = True

    def run(self) -> None:
        n = 0
        window_start, window_frames = time.monotonic(), 0
        while self._running:
            frame = self.camera.read()
            if frame is None:
                time.sleep(0.01)
                continue
            with self._cond:
                every = 1 if self._collectors else self.track_every
            fresh = n % every == 0
            pose = self._pose
            if fresh:
                pose = self.tracker.process(frame, int(time.monotonic() * 1000))
            n += 1
            with self._cond:
                self._frame, self._pose, self._fresh = frame, pose, fresh
                self._seq += 1
                self._cond.notify_all()

            window_frames += 1
            elapsed = time.monotonic() - window_start
            if elapsed >= 2.0:
                self.fps = window_frames / elapsed
                window_start, window_frames = time.monotonic(), 0

    def latest(self):
        """(frame, pose, seq). The pose can be a few frames old."""
        with self._cond:
            return self._frame, self._pose, self._seq

    def collect_poses(self, count: int, timeout: float) -> list[Pose | None]:
        """Wait for `count` freshly tracked frames. Entries are None when
        nobody was found in that frame."""
        deadline = time.monotonic() + timeout
        poses: list[Pose | None] = []
        with self._cond:
            self._collectors += 1
            try:
                seen = self._seq
                while len(poses) < count:
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        break
                    self._cond.wait_for(lambda: self._seq != seen, remaining)
                    if self._seq != seen and self._fresh:
                        poses.append(self._pose)
                    seen = self._seq
            finally:
                self._collectors -= 1
        return poses

    def stop(self) -> None:
        self._running = False

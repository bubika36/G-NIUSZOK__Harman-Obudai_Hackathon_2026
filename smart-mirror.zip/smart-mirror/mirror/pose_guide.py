"""The pose guide on the mirror: a figure standing in the pose the
measurement needs, each part coloured by how well the person's matches
(green, amber, red), with the match percentage and what to change.

Left and right are as seen in the mirror: the person's own left arm is on
the left of the screen.
"""
from __future__ import annotations

GREEN = (96, 200, 132)
AMBER = (240, 180, 90)
RED = (226, 76, 80)
NEUTRAL = (235, 235, 235)
GOOD, FAIR = 0.8, 0.4

# The figure, in a box 1 wide and 1.1 tall: arms 35 degrees out from the
# sides, legs 7 degrees apart (ankles about 1.8 hip widths apart).
HEAD = ((0.5, 0.11), 0.075)
TORSO = [(0.37, 0.26), (0.63, 0.26), (0.60, 0.63), (0.40, 0.63)]
LIMBS = {
    "body": [((0.5, 0.17), (0.5, 0.27))],
    "arm_left": [((0.37, 0.27), (0.261, 0.426)), ((0.261, 0.426), (0.158, 0.573))],
    "arm_right": [((0.63, 0.27), (0.739, 0.426)), ((0.739, 0.426), (0.842, 0.573))],
    "leg_left": [((0.43, 0.60), (0.401, 0.833)), ((0.401, 0.833), (0.373, 1.066)),
                 ((0.373, 1.066), (0.33, 1.075))],
    "leg_right": [((0.57, 0.60), (0.599, 0.833)), ((0.599, 0.833), (0.627, 1.066)),
                  ((0.627, 1.066), (0.67, 1.075))],
}
LIMB_WIDTH = 0.06
FIGURE_HEIGHT = 1.1


def part_scores(parts: dict[str, float]) -> dict[str, float | None]:
    """How well each drawn part of the figure matches, from posecheck's checks."""
    if not parts:
        return dict.fromkeys(LIMBS)

    def worst(*names):
        return min(parts.get(n, 0.0) for n in names)

    return {
        "body": worst("in_view", "facing", "upright"),
        "arm_left": worst("arm_left", "elbow_left"),
        "arm_right": worst("arm_right", "elbow_right"),
        "leg_left": worst("feet", "knee_left"),
        "leg_right": worst("feet", "knee_right"),
    }


def colour(score: float | None) -> tuple[int, int, int]:
    if score is None:
        return NEUTRAL
    return GREEN if score >= GOOD else AMBER if score >= FAIR else RED


def wrap(font, text: str, width: int, max_lines: int) -> list[str]:
    lines, line = [], ""
    for word in text.split():
        candidate = f"{line} {word}".strip()
        if font.size(candidate)[0] <= width or not line:
            line = candidate
        else:
            lines.append(line)
            line = word
    if line:
        lines.append(line)
    return lines[:max_lines]


def draw_pose_guide(pygame, screen, pose: dict | None, hint: str, threshold: float, top: int = 12) -> None:
    """Draws the guide in the top-right corner of the screen, big enough to
    read from the floor line. `pose` is {"score": 0..1, "parts": {...}} from
    the measurement thread, or None before the first tracked frame."""
    sw, sh = screen.get_size()
    box_w = max(150, int(min(sw * 0.36, sh * 0.42)))
    pad = box_w // 14
    inner = box_w - 2 * pad
    figure_h = int(inner * FIGURE_HEIGHT)
    bar_h = max(8, box_w // 16)
    font_pct = pygame.font.SysFont(None, box_w // 5)
    font_hint = pygame.font.SysFont(None, max(16, box_w // 10))
    hint_lines = wrap(font_hint, hint, inner, 4)
    box_h = (pad + figure_h + pad + bar_h + pad // 2 + font_pct.get_linesize()
             + len(hint_lines) * font_hint.get_linesize() + pad)
    x0, y0 = sw - box_w - 12, top

    backdrop = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
    pygame.draw.rect(backdrop, (0, 0, 0, 170), backdrop.get_rect(), border_radius=pad)
    screen.blit(backdrop, (x0, y0))

    def at(point):
        return int(x0 + pad + point[0] * inner), int(y0 + pad + point[1] * inner)

    parts = (pose or {}).get("parts") or {}
    scores = part_scores(parts)
    width = max(3, int(LIMB_WIDTH * inner))
    body = colour(scores["body"])
    pygame.draw.polygon(screen, body, [at(p) for p in TORSO])
    for p in TORSO[:2]:
        pygame.draw.circle(screen, body, at(p), width // 2)
    pygame.draw.circle(screen, body, at(HEAD[0]), int(HEAD[1] * inner))
    for name, segments in LIMBS.items():
        c = colour(scores[name])
        for a, b in segments:
            pygame.draw.line(screen, c, at(a), at(b), width)
            pygame.draw.circle(screen, c, at(a), width // 2)
            pygame.draw.circle(screen, c, at(b), width // 2)

    score = (pose or {}).get("score") or 0.0
    y = y0 + pad + figure_h + pad
    bar = pygame.Rect(x0 + pad, y, inner, bar_h)
    pygame.draw.rect(screen, (70, 70, 70), bar, border_radius=bar_h // 2)
    filled = bar.copy()
    filled.w = int(inner * min(max(score, 0.0), 1.0))
    if filled.w > 0:
        pygame.draw.rect(screen, GREEN if score >= threshold else AMBER, filled, border_radius=bar_h // 2)
    tick_x = bar.x + int(inner * threshold)
    pygame.draw.line(screen, (255, 255, 255), (tick_x, bar.y - 4), (tick_x, bar.bottom + 4), 2)
    y = bar.bottom + pad // 2

    pct = font_pct.render(f"{round(score * 100)}%", True, (255, 255, 255))
    screen.blit(pct, (x0 + (box_w - pct.get_width()) // 2, y))
    y += font_pct.get_linesize()
    for line in hint_lines:
        text = font_hint.render(line, True, (230, 230, 230))
        screen.blit(text, (x0 + (box_w - text.get_width()) // 2, y))
        y += font_hint.get_linesize()


def draw_banner(pygame, screen, text: str, ok: bool, top: int = 12) -> int:
    """A line of text centred at the top of the mirror, big enough to read
    from the floor line: green when all is well, amber otherwise. Returns
    the y just below it."""
    sw, sh = screen.get_size()
    font = pygame.font.SysFont(None, max(30, min(sh // 36, sw // 20)))
    label = font.render(text, True, GREEN if ok else AMBER)
    pad = label.get_height() // 4
    box = pygame.Rect(0, 0, label.get_width() + 4 * pad, label.get_height() + 2 * pad)
    box.midtop = (sw // 2, top)
    backdrop = pygame.Surface(box.size, pygame.SRCALPHA)
    pygame.draw.rect(backdrop, (0, 0, 0, 180), backdrop.get_rect(), border_radius=pad)
    screen.blit(backdrop, box.topleft)
    screen.blit(label, (box.x + 2 * pad, box.y + pad))
    return box.bottom


def draw_measuring(pygame, screen) -> None:
    """ "Mérés" (measuring) in the middle of the mirror."""
    sw, sh = screen.get_size()
    size = sh // 10
    label = pygame.font.SysFont(None, size).render("Mérés", True, (255, 255, 255))
    radius = max(label.get_width(), label.get_height()) // 2 + size // 6
    disc = pygame.Surface((radius * 2, radius * 2), pygame.SRCALPHA)
    pygame.draw.circle(disc, (0, 0, 0, 150), (radius, radius), radius)
    screen.blit(disc, (sw // 2 - radius, sh // 2 - radius))
    screen.blit(label, (sw // 2 - label.get_width() // 2, sh // 2 - label.get_height() // 2))

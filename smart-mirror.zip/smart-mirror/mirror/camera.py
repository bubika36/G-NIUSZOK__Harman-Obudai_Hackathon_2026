"""Frames from the Pi camera, a USB webcam, or a file (for testing)."""
from __future__ import annotations

import time
from pathlib import Path

import cv2
import numpy as np

from .config import CameraConfig

_ROTATIONS = {
    0: None,
    90: cv2.ROTATE_90_CLOCKWISE,
    180: cv2.ROTATE_180,
    270: cv2.ROTATE_90_COUNTERCLOCKWISE,
}
_IMAGE_SUFFIXES = {".jpg", ".jpeg", ".png", ".bmp"}


def full_view_mode(modes: list[dict] | None, out_size: tuple[int, int]) -> dict | None:
    """The sensor mode to use: the smallest one that still sees the whole
    sensor and is at least as big as the output.

    Small modes are often cropped. The Camera Module 2's 640x480 mode only uses
    the middle 1280x960 of its 3280x2464 sensor, which zooms in about 2.5x and
    throws the measurements off. Its 1640x1232 mode sees everything, and the
    Pi's image processor scales it down to 640x480 at no cost to the CPU.
    """
    usable = [m for m in modes or [] if "crop_limits" in m and "size" in m]
    if not usable:
        return None

    def area(mode: dict) -> int:
        _, _, w, h = mode["crop_limits"]
        return w * h

    widest = max(area(m) for m in usable)
    full = [m for m in usable if area(m) >= 0.95 * widest]
    big_enough = [m for m in full if m["size"][0] >= out_size[0] and m["size"][1] >= out_size[1]]
    return min(big_enough or full, key=lambda m: m["size"][0] * m["size"][1])


class Camera:
    """Returns BGR frames, already rotated so the person stands upright."""

    def __init__(self, cfg: CameraConfig):
        self.cfg = cfg
        self._rotation = _ROTATIONS[cfg.rotate]
        self._picam = None
        self._cap = None
        self._still = None
        self._is_file = False

        source = str(cfg.source)
        if source == "picamera2":
            from picamera2 import Picamera2  # only installed on the Pi

            self._picam = Picamera2()
            self._picam.configure(self._full_view_configuration(cfg))
            self._picam.start()
        elif Path(source).suffix.lower() in _IMAGE_SUFFIXES:
            image = cv2.imread(source)
            if image is None:
                raise FileNotFoundError(f"Nem olvasható a kép: {source}")
            self._still = cv2.resize(image, (cfg.width, cfg.height))
        else:
            self._is_file = not source.isdigit()
            self._cap = cv2.VideoCapture(int(source) if source.isdigit() else source)
            if not self._cap.isOpened():
                raise RuntimeError(f"Nem nyitható meg a kameraforrás: {source}")
            self._cap.set(cv2.CAP_PROP_FRAME_WIDTH, cfg.width)
            self._cap.set(cv2.CAP_PROP_FRAME_HEIGHT, cfg.height)

    def _full_view_configuration(self, cfg: CameraConfig):
        # "RGB888" arrives in B, G, R order, which is what OpenCV expects.
        main = {"size": (cfg.width, cfg.height), "format": "RGB888"}
        mode = full_view_mode(self._picam.sensor_modes, (cfg.width, cfg.height))
        if mode is None:
            print("Kamera: nem sikerült kiolvasni a szenzor módjait; a kamera alapértelmezett nézetét használom.")
            return self._picam.create_video_configuration(main=main)
        w, h = mode["size"]
        print(f"Kamera: {w}x{h} szenzormód, amely a teljes szenzort látja")
        try:
            return self._picam.create_video_configuration(
                main=main, sensor={"output_size": mode["size"], "bit_depth": mode["bit_depth"]})
        except (TypeError, KeyError):  # older picamera2 without the sensor option
            return self._picam.create_video_configuration(main=main, raw={"size": mode["size"]})

    def read(self) -> np.ndarray | None:
        if self._picam is not None:
            frame = self._picam.capture_array()
            if frame.ndim == 3 and frame.shape[2] == 4:
                frame = frame[:, :, :3]
        elif self._still is not None:
            time.sleep(1 / 30)  # behave like a 30 fps camera
            frame = self._still.copy()
        else:
            ok, frame = self._cap.read()
            if not ok and self._is_file:  # loop test videos
                self._cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
                ok, frame = self._cap.read()
            if not ok:
                return None
            if frame.shape[1] != self.cfg.width or frame.shape[0] != self.cfg.height:
                frame = cv2.resize(frame, (self.cfg.width, self.cfg.height))
            if self._is_file:
                time.sleep(1 / 30)
        if self._rotation is not None:
            frame = cv2.rotate(frame, self._rotation)
        return np.ascontiguousarray(frame)

    def close(self) -> None:
        if self._picam is not None:
            self._picam.stop()
        if self._cap is not None:
            self._cap.release()

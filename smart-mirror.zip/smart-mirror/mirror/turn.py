"""Which way the person is turned, from MediaPipe's 3D body points.

The angle (yaw) is in degrees: 0 = facing the camera, +90 = their left side
towards the camera, -90 = their right side, 180 = their back.
"""
from __future__ import annotations

import math

import numpy as np

from .pose import LEFT_EYE, LEFT_SHOULDER, NOSE, RIGHT_EYE, RIGHT_SHOULDER, Pose

# Below this, the face counts as hidden: the person has their back to us.
FACE_HIDDEN = 0.3


def wrap(angle: float) -> float:
    """Into the range -180 < angle <= 180."""
    angle = (angle + 180.0) % 360.0 - 180.0
    return 180.0 if angle == -180.0 else angle


def estimate_yaw(pose: Pose | None) -> float | None:
    if pose is None or pose.world is None:
        return None
    if not (pose.visible(LEFT_SHOULDER) or pose.visible(RIGHT_SHOULDER)):
        return None
    left, right = pose.world[LEFT_SHOULDER], pose.world[RIGHT_SHOULDER]
    across = float(left[0] - right[0])   # > 0 when the left shoulder is on the picture's right
    nearer = float(right[2] - left[2])   # > 0 when the left shoulder is nearer the camera
    if abs(across) < 1e-6 and abs(nearer) < 1e-6:
        return None
    yaw = math.degrees(math.atan2(nearer, across))
    # MediaPipe tends to see everyone as facing the camera. A hidden face
    # gives a turned back away.
    face = max(pose.visibility[i] for i in (NOSE, LEFT_EYE, RIGHT_EYE))
    if face < FACE_HIDDEN and abs(yaw) < 90:
        yaw = 180 - yaw if yaw >= 0 else -180 - yaw
    return wrap(yaw)


class YawTracker:
    """Smooths the turn angle over a few frames, so the shirt doesn't flicker
    between views."""

    def __init__(self, smoothing: float = 0.35):
        self.smoothing = smoothing
        self._direction: np.ndarray | None = None

    def update(self, pose: Pose | None) -> float | None:
        yaw = estimate_yaw(pose)
        if yaw is not None:
            new = np.array([math.cos(math.radians(yaw)), math.sin(math.radians(yaw))])
            if self._direction is None:
                self._direction = new
            else:
                self._direction = (1 - self.smoothing) * self._direction + self.smoothing * new
        return self.yaw

    @property
    def yaw(self) -> float | None:
        if self._direction is None or not np.any(self._direction):
            return None
        return wrap(math.degrees(math.atan2(self._direction[1], self._direction[0])))

    def reset(self) -> None:
        self._direction = None

"""What the person is wearing: at most one top and one bottom."""
from __future__ import annotations


class Outfit:
    """Indexes into the garment list for the top and the bottom being worn.
    Starts with the first of each, so a new visitor is fully dressed."""

    def __init__(self, kinds: list[str]):
        self.kinds = kinds
        self.top = self._first("top")
        self.bottom = self._first("bottom")
        self.visible = True

    def _first(self, kind: str) -> int | None:
        return next((i for i, k in enumerate(self.kinds) if k == kind), None)

    def select(self, index: int) -> None:
        """Put on this garment, in place of the one of the same kind. Choosing
        the one already being worn takes it off."""
        if not 0 <= index < len(self.kinds):
            return
        kind = self.kinds[index]
        if getattr(self, kind) == index and self.visible:
            setattr(self, kind, None)
        else:
            setattr(self, kind, index)
        self.visible = True

    def step(self, kind: str, step: int) -> None:
        """The next (or previous) garment of one kind. Bottoms also go
        through "none", so the person's own trousers can show."""
        choices: list[int | None] = [i for i, k in enumerate(self.kinds) if k == kind]
        if not choices:
            return
        if kind == "bottom":
            choices.append(None)
        current = getattr(self, kind)
        position = choices.index(current) if current in choices else -1
        setattr(self, kind, choices[(position + step) % len(choices)])
        self.visible = True

    def toggle(self) -> None:
        self.visible = not self.visible

    @property
    def worn(self) -> list[int]:
        """The garments being worn, in drawing order: bottom first, so the
        shirt hangs over the trousers."""
        return [i for i in (self.bottom, self.top) if i is not None]

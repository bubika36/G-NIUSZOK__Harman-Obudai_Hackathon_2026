"""Body tracking with MediaPipe Pose Landmarker."""
from __future__ import annotations

from dataclasses import dataclass

import cv2
import mediapipe as mp
import numpy as np

from .config import PoseConfig

# MediaPipe landmark numbers. "Left" means the person's own left.
NOSE = 0
LEFT_EYE, RIGHT_EYE = 2, 5
LEFT_SHOULDER, RIGHT_SHOULDER = 11, 12
LEFT_ELBOW, RIGHT_ELBOW = 13, 14
LEFT_WRIST, RIGHT_WRIST = 15, 16
LEFT_PINKY, RIGHT_PINKY = 17, 18     # knuckles at the base of the little finger
LEFT_INDEX, RIGHT_INDEX = 19, 20     # and of the index finger
LEFT_THUMB, RIGHT_THUMB = 21, 22
LEFT_HIP, RIGHT_HIP = 23, 24
LEFT_KNEE, RIGHT_KNEE = 25, 26
LEFT_ANKLE, RIGHT_ANKLE = 27, 28
LEFT_HEEL, RIGHT_HEEL = 29, 30
LEFT_FOOT, RIGHT_FOOT = 31, 32


@dataclass
class Pose:
    points: np.ndarray       # (33, 2) pixel x, y in the frame
    visibility: np.ndarray   # (33,) 0..1
    mask: np.ndarray | None  # (H, W) float32, 1 where the person is
    # (33, 3) estimated 3D positions in metres, centred between the hips:
    # x to the right of the picture, y down, z away from the camera.
    world: np.ndarray | None = None

    def visible(self, index: int, threshold: float = 0.5) -> bool:
        return bool(self.visibility[index] >= threshold)


class PoseTracker:
    def __init__(self, cfg: PoseConfig):
        vision = mp.tasks.vision
        options = vision.PoseLandmarkerOptions(
            base_options=mp.tasks.BaseOptions(model_asset_path=cfg.model_path),
            running_mode=vision.RunningMode.VIDEO,
            num_poses=1,
            min_pose_detection_confidence=cfg.min_confidence,
            min_pose_presence_confidence=cfg.min_confidence,
            min_tracking_confidence=cfg.min_confidence,
            output_segmentation_masks=True,
        )
        self._landmarker = vision.PoseLandmarker.create_from_options(options)
        self._last_ts = -1

    def process(self, frame_bgr: np.ndarray, timestamp_ms: int) -> Pose | None:
        # Video mode needs strictly increasing timestamps.
        ts = max(int(timestamp_ms), self._last_ts + 1)
        self._last_ts = ts
        rgb = cv2.cvtColor(frame_bgr, cv2.COLOR_BGR2RGB)
        image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
        result = self._landmarker.detect_for_video(image, ts)
        if not result.pose_landmarks:
            return None

        h, w = frame_bgr.shape[:2]
        landmarks = result.pose_landmarks[0]
        points = np.array([[lm.x * w, lm.y * h] for lm in landmarks], dtype=np.float32)
        visibility = np.array(
            [lm.visibility if lm.visibility is not None else 1.0 for lm in landmarks],
            dtype=np.float32,
        )
        mask = None
        if result.segmentation_masks:
            mask = np.array(result.segmentation_masks[0].numpy_view(), dtype=np.float32)
            if mask.ndim == 3:
                mask = mask[:, :, 0]
        world = None
        if result.pose_world_landmarks:
            world = np.array([[lm.x, lm.y, lm.z] for lm in result.pose_world_landmarks[0]],
                             dtype=np.float32)
        return Pose(points, visibility, mask, world)

    def close(self) -> None:
        self._landmarker.close()

"""Garments on the mirror: tops (shirts) and bottoms (trousers and shorts).

Tops: the body of the shirt seen from several angles, plus sleeves that
follow the arms. The mirror picks the two views nearest to the way the
person is turned and blends them, fitted between the middle of the shoulders
and the middle of the hips. The sleeves are one picture of a sleeve hanging
straight down, bent to fit each arm: its top edge stays sewn into the
shirt's armhole while its cuff wraps the upper arm. From the side each
sleeve is simply turned along the upper arm, the one nearer the camera drawn
in front of the shirt.

Bottoms: the part from the waist to the crotch is drawn like the body of a
shirt (views every few degrees, fitted to the same shoulder-to-hip line, so
both garments grow and shrink together). Each leg is one picture of a
straight trouser leg, bent at the knee to run from the hip joint through
the knee to the ankle, so the legs walk, kneel and kick with the person.
The leg nearer the camera is drawn over the other one.

See garments/README.md for the format of garments/garments.json.
"""
from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

import cv2
import numpy as np

from .arms import BACK, FRONT
from .pose import (
    LEFT_ANKLE,
    LEFT_ELBOW,
    LEFT_HIP,
    LEFT_KNEE,
    LEFT_SHOULDER,
    RIGHT_ANKLE,
    RIGHT_ELBOW,
    RIGHT_HIP,
    RIGHT_KNEE,
    RIGHT_SHOULDER,
    Pose,
)
from .turn import wrap

KINDS = ("top", "bottom")
LEVELS = 4                 # each picture is kept at full, 1/2, 1/4 and 1/8 size
SIDE_ON = 35               # beyond this turn, the near sleeve goes in front of the shirt
SEGMENTS = 8               # a bent sleeve is drawn as this many strips
# Near a bent joint (the knee), this much of each part is drawn as its own
# strip, so the bend's slight stretch stays close to the joint.
JOINT_ZONE = 0.25

# Sleeve geometry, as fractions of the shoulder-to-hip length
ARMHOLE_TOP = (0.08, 0.0)       # shoulder seam: above the joint
ARMHOLE_BOTTOM = (0.22, -0.05)  # armpit: below the joint, and inwards (under the shirt)
SLEEVE_LENGTH = 0.42
CUFF_HALF_WIDTH = 0.125
MIN_WEIGHT = 0.04          # views blended in at less than this are skipped
# Cross-fade only in the middle part of the gap between two views, so most
# angles show one clean view instead of two prints on top of each other.
FADE_START, FADE_END = 0.35, 0.65
DEFAULT_SHOULDER_WIDTH = 0.64
DEFAULT_HIP_WIDTH = 0.40
# How far down the shoulder-to-hip axis a view's width is read: across the
# chest for tops, across the hip joints for bottoms.
WIDTH_AT = {"top": 0.33, "bottom": 1.0}
# A bent knee widens the leg on the outside of the bend; at most this much.
MAX_KNEE_WIDENING = 1.6


@dataclass
class Piece:
    """A picture with an axis: from `top` to `bottom`, in picture pixels.
    A trouser leg also has a `knee`, where it bends."""
    image: np.ndarray      # BGRA
    top: np.ndarray
    bottom: np.ndarray
    knee: np.ndarray | None = None

    def box(self) -> np.ndarray:
        """Corners of the opaque part: top-left, top-right, bottom-right, bottom-left."""
        ys, xs = np.nonzero(self.image[:, :, 3] > 16)
        if xs.size == 0:
            h, w = self.image.shape[:2]
            return np.float32([[0, 0], [w, 0], [w, h], [0, h]])
        x0, x1, y0, y1 = xs.min(), xs.max() + 1, ys.min(), ys.max() + 1
        return np.float32([[x0, y0], [x1, y0], [x1, y1], [x0, y1]])

    @property
    def length(self) -> float:
        return float(np.linalg.norm(self.bottom - self.top))


@dataclass
class View:
    yaw: float
    levels: list[Piece]    # the same picture at full, 1/2, 1/4 ... size
    width: float = 1.0     # width across the chest (or hips), as a fraction of the axis length


@dataclass
class Garment:
    name: str
    views: list[View]      # sorted by yaw
    sleeve: list[Piece] | None
    thumbnail: np.ndarray  # BGRA, for the touchscreen
    # Distance between the shoulder joints the shirt was made for, as a
    # fraction of the shoulder-to-hip length.
    shoulder_width: float = DEFAULT_SHOULDER_WIDTH
    kind: str = "top"      # "top" or "bottom"
    leg: list[Piece] | None = None
    # Distance between the hip joints the trousers were made for, as a
    # fraction of the shoulder-to-hip length.
    hip_width: float = DEFAULT_HIP_WIDTH


# ---------- loading ----------

def _read_bgra(path: Path) -> np.ndarray:
    image = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if image is None:
        raise FileNotFoundError(f"nem olvasható: {path.name}")
    if image.ndim != 3 or image.shape[2] != 4:
        raise ValueError(f"{path.name}: átlátszó hátterű PNG kell")
    return image


def _levels(piece: Piece) -> list[Piece]:
    levels = [piece]
    for _ in range(LEVELS - 1):
        prev = levels[-1]
        if min(prev.image.shape[:2]) < 16:
            break
        knee = prev.knee / 2 if prev.knee is not None else None
        levels.append(Piece(cv2.pyrDown(prev.image), prev.top / 2, prev.bottom / 2, knee))
    return levels


def chest_width(piece: Piece, at: float = WIDTH_AT["top"]) -> float:
    """How wide the garment is at `at` of the way down its axis (a third of
    the way, across the chest, by default), as a fraction of the axis length."""
    row = piece.top + (piece.bottom - piece.top) * at
    y = int(np.clip(round(float(row[1])), 0, piece.image.shape[0] - 1))
    opaque = np.flatnonzero(piece.image[y, :, 3] > 128)
    if opaque.size == 0:
        return 1.0
    return float(opaque[-1] - opaque[0] + 1) / piece.length


def _view(folder: Path, item: dict, kind: str) -> View:
    piece = _piece(folder, item)
    return View(wrap(float(item["yaw"])), _levels(piece), chest_width(piece, WIDTH_AT[kind]))


def _piece(folder: Path, item: dict) -> Piece:
    return Piece(_read_bgra(folder / item["image"]),
                 np.float32(item["top"]), np.float32(item["bottom"]))


def _leg(folder: Path, item: dict) -> Piece:
    """A trouser leg runs top (hip joint) -> knee -> bottom (ankle). A shorts
    leg has no bottom: its axis ends at the knee, below the picture."""
    image = _read_bgra(folder / item["image"])
    top, knee = np.float32(item["top"]), np.float32(item["knee"])
    if "bottom" in item:
        return Piece(image, top, np.float32(item["bottom"]), knee)
    return Piece(image, top, knee)


def load_garments(folder: str | Path, pictures: bool = True) -> list[Garment]:
    """Reads garments.json. With pictures=False only the names and thumbnails
    are loaded (for the touchscreen), but every garment is still checked the
    same way, so both lists stay in the same order."""
    folder = Path(folder)
    index = folder / "garments.json"
    if not index.exists():
        return []
    garments = []
    for item in json.loads(index.read_text(encoding="utf-8")):
        try:
            kind = item.get("kind", "top")
            if kind not in KINDS:
                raise ValueError(f"a kind értéke csak {' vagy '.join(KINDS)} lehet")
            if not item["views"]:
                raise ValueError("nincs egy nézete sem")
            sleeve = leg = None
            if pictures:
                views = sorted((_view(folder, v, kind) for v in item["views"]), key=lambda v: v.yaw)
                if "sleeve" in item:
                    sleeve = _levels(_piece(folder, item["sleeve"]))
                if "leg" in item:
                    leg = _levels(_leg(folder, item["leg"]))
            else:
                extra = [item.get(part, {}).get("image") for part in ("sleeve", "leg")]
                for path in [v["image"] for v in item["views"]] + extra:
                    if path and not (folder / path).exists():
                        raise FileNotFoundError(f"nem olvasható: {Path(path).name}")
                views = []
            if "thumbnail" in item:
                thumbnail = _read_bgra(folder / item["thumbnail"])
            else:
                front = min(item["views"], key=lambda v: abs(wrap(float(v["yaw"]))))
                thumbnail = _read_bgra(folder / front["image"])
            garments.append(Garment(item["name"], views, sleeve, thumbnail,
                                    float(item.get("shoulder_width", DEFAULT_SHOULDER_WIDTH)),
                                    kind, leg, float(item.get("hip_width", DEFAULT_HIP_WIDTH))))
        except (KeyError, ValueError, FileNotFoundError) as exc:
            print(f"Kihagyott ruha: {item.get('name', '?')!r}: {exc}")
    return garments


# ---------- geometry ----------

def pick_views(yaws: list[float], yaw: float) -> list[tuple[int, float]]:
    """The views to blend for this turn angle: (index, weight) pairs, the
    weights adding up to 1. Blends the nearest view on each side."""
    if len(yaws) == 1:
        return [(0, 1.0)]
    below = above = None   # (index, angular distance)
    for i, view_yaw in enumerate(yaws):
        d = wrap(yaw - view_yaw)
        if d >= 0 and (below is None or d < below[1]):
            below = (i, d)
        if d <= 0 and (above is None or -d < above[1]):
            above = (i, -d)
    if below is None or above is None or below[0] == above[0]:
        nearest = min(range(len(yaws)), key=lambda i: abs(wrap(yaw - yaws[i])))
        return [(nearest, 1.0)]
    span = below[1] + above[1]
    towards_above = _smoothstep(below[1] / span)
    return [(below[0], 1 - towards_above), (above[0], towards_above)]


def _smoothstep(x: float) -> float:
    t = min(max((x - FADE_START) / (FADE_END - FADE_START), 0.0), 1.0)
    return t * t * (3 - 2 * t)


def axis_transform(src_top, src_bottom, dst_top, dst_bottom, width_scale: float) -> np.ndarray:
    """2x3 affine matrix taking the source axis onto the destination axis:
    stretched along it to fit, and scaled by width_scale across it."""
    src_top, src_bottom = np.float64(src_top), np.float64(src_bottom)
    dst_top, dst_bottom = np.float64(dst_top), np.float64(dst_bottom)
    s = src_bottom - src_top
    length = np.linalg.norm(s)
    u = s / length
    p = np.array([-u[1], u[0]])
    d = dst_bottom - dst_top
    ud = d / np.linalg.norm(d)
    pd = np.array([-ud[1], ud[0]])
    m = np.outer(d / length, u) + width_scale * np.outer(pd, p)
    offset = dst_top - m @ src_top
    return np.hstack([m, offset[:, None]]).astype(np.float32)


def _level(levels: list[Piece], scale: float) -> tuple[Piece, float]:
    """The smallest copy that is still at least as big as needed, and the
    scale to apply to it. Shrinking a picture by more than half in one go
    makes thin lines shimmer."""
    i = 0
    while i + 1 < len(levels) and scale <= 0.5 ** (i + 1):
        i += 1
    return levels[i], scale / 0.5 ** i


# ---------- drawing ----------

def _composite(frame: np.ndarray, layers: list[tuple[np.ndarray, np.ndarray, float]]) -> None:
    """Draws the layers (image, matrix, weight) onto the frame in one go; the
    weights cross-fade layers that are blended views of the same thing. Where
    any of them is solid, the result is solid, so a blend never turns
    see-through."""
    if len(layers) == 1 and _is_shift(layers[0][1]):
        _blend_at(frame, layers[0][0], int(layers[0][1][0, 2]), int(layers[0][1][1, 2]))
        return
    fh, fw = frame.shape[:2]
    boxes = []
    for image, matrix, _ in layers:
        h, w = image.shape[:2]
        corners = cv2.transform(np.float32([[0, 0], [w, 0], [w, h], [0, h]]).reshape(-1, 1, 2), matrix)
        boxes.append(corners.reshape(-1, 2))
    allc = np.vstack(boxes)
    x0, y0 = np.maximum(np.floor(allc.min(axis=0)).astype(int), 0)
    x1, y1 = np.minimum(np.ceil(allc.max(axis=0)).astype(int), [fw, fh])
    if x1 <= x0 or y1 <= y0:
        return
    size = (int(x1 - x0), int(y1 - y0))
    colour = np.zeros((size[1], size[0], 3), np.float32)
    weighted = np.zeros((size[1], size[0], 1), np.float32)
    alpha = np.zeros((size[1], size[0], 1), np.float32)
    for image, matrix, weight in layers:
        shifted = matrix.copy()
        shifted[:, 2] -= (x0, y0)
        warped = cv2.warpAffine(image, shifted, size, flags=cv2.INTER_LINEAR,
                                borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
        a = warped[:, :, 3:4].astype(np.float32) / 255.0
        colour += warped[:, :, :3] * (a * weight)
        weighted += a * weight
        np.maximum(alpha, a, out=alpha)
    colour /= np.maximum(weighted, 1e-6)
    region = frame[y0:y1, x0:x1].astype(np.float32)
    frame[y0:y1, x0:x1] = np.clip(region * (1 - alpha) + colour * alpha, 0, 255).astype(np.uint8)


def _is_shift(matrix: np.ndarray) -> bool:
    """True when the matrix only moves the picture by whole pixels."""
    return (np.array_equal(matrix[:, :2], np.eye(2, dtype=matrix.dtype))
            and np.array_equal(matrix[:, 2], np.round(matrix[:, 2])))


def _blend_at(frame: np.ndarray, image: np.ndarray, x: int, y: int) -> None:
    """Draws a BGRA picture onto the frame with its top-left corner at (x, y)."""
    fh, fw = frame.shape[:2]
    h, w = image.shape[:2]
    x0, y0, x1, y1 = max(x, 0), max(y, 0), min(x + w, fw), min(y + h, fh)
    if x1 <= x0 or y1 <= y0:
        return
    src = image[y0 - y:y1 - y, x0 - x:x1 - x]
    a = src[:, :, 3:4].astype(np.float32) * (1 / 255)
    region = frame[y0:y1, x0:x1]
    region[:] = np.clip(region * (1 - a) + src[:, :, :3] * a + 0.5, 0, 255).astype(np.uint8)


def _midpoint(pose: Pose, a: int, b: int) -> np.ndarray | None:
    if not (pose.visible(a) or pose.visible(b)):
        return None
    return (pose.points[a] + pose.points[b]) / 2


def _torso_axis(pose: Pose):
    """(middle of the shoulders, middle of the hips, distance between them), or None."""
    top = _midpoint(pose, LEFT_SHOULDER, RIGHT_SHOULDER)
    bottom = _midpoint(pose, LEFT_HIP, RIGHT_HIP)
    if top is None or bottom is None:
        return None
    torso = float(np.linalg.norm(bottom - top))
    if torso < 10:
        return None
    return top, bottom, torso


def _width_fit(pose: Pose, a: int, b: int, torso: float, facing: float, made_for: float) -> float:
    """How much wider (or narrower) to draw the garment so it matches the
    person's shoulders (or hips) when they face the camera."""
    if facing <= 0.5 or not (pose.visible(a) and pose.visible(b)):
        return 1.0
    span = float(np.linalg.norm(pose.points[a] - pose.points[b]))
    ratio = span / torso / facing / made_for
    return 1 + (float(np.clip(ratio, 0.85, 1.2)) - 1) * facing


def _view_layers(garment: Garment, top: np.ndarray, bottom: np.ndarray, torso: float,
                 yaw: float, width_fit: float) -> list:
    """The one or two views for this turn angle, fitted to the torso axis.
    When two are blended, both are stretched to the width in between, so
    their outlines line up and only the print fades from one to the other."""
    picked = [(garment.views[i], w) for i, w in pick_views([v.yaw for v in garment.views], yaw)
              if w >= MIN_WEIGHT]
    total = sum(w for _, w in picked)
    blended_width = sum(view.width * w for view, w in picked) / total
    layers = []
    for view, weight in picked:
        scale = torso / view.levels[0].length
        piece, s = _level(view.levels, scale)
        width_scale = s * width_fit * blended_width / view.width
        layers.append((piece.image, axis_transform(piece.top, piece.bottom, top, bottom, width_scale),
                       weight / total))
    return layers


def render_garment(frame: np.ndarray, garment: Garment, pose: Pose, yaw: float | None,
                   arms: dict | None = None) -> bool:
    """Draws the garment onto the person, in place. False when the shoulders
    or hips can't be seen. Draw bottoms before tops, so shirts hang over the
    trousers. `arms` says which arms are in front of or behind the body
    (arms.ArmTracker); without it, the sleeves go behind the shirt, or the
    nearer one in front when the person stands side-on."""
    axis = _torso_axis(pose)
    if axis is None:
        return False
    yaw = 0.0 if yaw is None else yaw
    if garment.kind == "bottom":
        _render_bottom(frame, garment, pose, yaw, *axis)
    else:
        _render_top(frame, garment, pose, yaw, *axis, arms or {})
    return True


def _render_top(frame, garment: Garment, pose: Pose, yaw: float, top, bottom, torso, arms: dict) -> None:
    facing = abs(np.cos(np.radians(yaw)))   # 1 from the front or back, 0 from the side
    width_fit = _width_fit(pose, LEFT_SHOULDER, RIGHT_SHOULDER, torso, facing, garment.shoulder_width)
    body_layers = _view_layers(garment, top, bottom, torso, yaw, width_fit)

    behind, in_front = [], []
    if garment.sleeve:
        sleeve_scale = torso / garment.views[0].levels[0].length
        down = (bottom - top) / torso
        for side, shoulder, elbow in (("left", LEFT_SHOULDER, LEFT_ELBOW), ("right", RIGHT_SHOULDER, RIGHT_ELBOW)):
            if not (pose.visible(shoulder) and pose.visible(elbow)):
                continue
            s_point, e_point = pose.points[shoulder], pose.points[elbow]
            arm = e_point - s_point
            arm_len = float(np.linalg.norm(arm))
            if arm_len < 5:
                continue
            place = arms.get(side)
            placed = place.sleeve if place is not None else None
            piece, s = _level(garment.sleeve, sleeve_scale)
            if facing >= 0.4 and placed != FRONT:
                layer = _bent_sleeve(piece, s_point, arm / arm_len, arm_len, top, down, torso)
            else:
                # Side-on, or the arm in front of the body (across the chest,
                # or reaching forward): turn the sleeve along the arm. It keeps
                # its length unless the arm points at the camera; then it stops
                # before the elbow.
                length = min(garment.sleeve[0].length * sleeve_scale, 0.85 * arm_len)
                layer = (piece.image, axis_transform(piece.top, piece.bottom, s_point,
                                                     s_point + arm / arm_len * length, s), 1.0)
            if placed == FRONT:
                in_front.append(layer)
            elif placed == BACK:
                behind.append(layer)
            else:
                (in_front if _nearer_side(pose, shoulder, yaw) else behind).append(layer)

    for layer in behind:
        _composite(frame, [layer])
    if body_layers:
        _composite(frame, body_layers)
    for layer in in_front:
        _composite(frame, [layer])


def _render_bottom(frame, garment: Garment, pose: Pose, yaw: float, top, bottom, torso) -> None:
    facing = abs(np.cos(np.radians(yaw)))
    width_fit = _width_fit(pose, LEFT_HIP, RIGHT_HIP, torso, facing, garment.hip_width)
    waist_layers = _view_layers(garment, top, bottom, torso, yaw, width_fit)

    legs = []
    if garment.leg:
        scale = torso / garment.views[0].levels[0].length
        for hip, knee, ankle, other_hip in ((LEFT_HIP, LEFT_KNEE, LEFT_ANKLE, RIGHT_HIP),
                                            (RIGHT_HIP, RIGHT_KNEE, RIGHT_ANKLE, LEFT_HIP)):
            layer = _leg_layer(garment.leg, pose, hip, knee, ankle, other_hip, scale)
            if layer is not None:
                depth = float(pose.world[hip][2]) if pose.world is not None else 0.0
                legs.append((depth, layer))
    # The far leg first, then the near one, then the waist over both.
    for _, layer in sorted(legs, key=lambda item: -item[0]):
        _composite(frame, [layer])
    if waist_layers:
        _composite(frame, waist_layers)


def _leg_layer(levels: list[Piece], pose: Pose, hip: int, knee: int, ankle: int, other_hip: int,
               scale: float):
    """One trouser leg, bent along hip -> knee -> ankle. A layer for _composite, or None."""
    if not (pose.visible(hip) and pose.visible(knee)):
        return None
    h_point, k_point = pose.points[hip].astype(np.float64), pose.points[knee].astype(np.float64)
    thigh = k_point - h_point
    if np.linalg.norm(thigh) < 5:
        return None
    piece, s = _level(levels, scale)
    if piece.knee is None:   # shorts: the leg's axis ends at the knee
        src, dst = [piece.top, piece.bottom], [h_point, k_point]
    else:
        if pose.visible(ankle):
            a_point = pose.points[ankle].astype(np.float64)
        else:  # ankle out of view: carry on straight
            shin = np.linalg.norm(piece.bottom - piece.knee) * s
            a_point = k_point + thigh / np.linalg.norm(thigh) * shin
        src, dst = [piece.top, piece.knee, piece.bottom], [h_point, k_point, a_point]
    # The picture shows the leg's outer side on its right. Turn it so that
    # side faces away from the other leg.
    side = h_point - pose.points[other_hip]
    flip = float(thigh[1] * side[0] - thigh[0] * side[1]) < 0
    return _bent_limb(piece.image, src, dst, s, flip)


def _bent_limb(image: np.ndarray, src: list, dst: list, across: float, flip: bool):
    """Bends a picture of a straight limb along the body's joints.

    src: the joints in the picture, straight down its middle (top, [knee,] end).
    dst: where they are on the person. Each part between two joints is
    stretched to fit along the body and scaled by `across` across it. At a
    bent joint, the strips meet on the line halfway between the two parts, so
    the limb bends without a gap or a crease.
    Returns a layer for _composite, or None."""
    ys = np.flatnonzero((image[:, :, 3] > 16).any(axis=1))
    if ys.size == 0:
        return None
    src = [np.float64(p) for p in src]
    dst = [np.float64(p) for p in dst]
    joints_y = [float(p[1]) for p in src]
    if any(b - a < 1 for a, b in zip(joints_y, joints_y[1:])):
        return None
    lengths = [np.linalg.norm(b - a) for a, b in zip(dst, dst[1:])]
    if min(lengths) < 1:
        return None
    dirs = [(b - a) / n for a, b, n in zip(dst, dst[1:], lengths)]
    sign = -1.0 if flip else 1.0
    # Picture right maps to this side of each part (for a part pointing down, the picture's right).
    normals = [sign * np.array([d[1], -d[0]]) for d in dirs]

    cx = float(src[0][0])
    w = image.shape[1]
    y_start, y_end = float(ys[0]), float(ys[-1] + 1)

    # The rows where the strips meet. Each straight part is one strip, except
    # next to a joint, where a short strip takes up the bend.
    rows = [y_start]
    bounds = [y_start] + joints_y[1:-1] + [y_end]
    for i, (a, b) in enumerate(zip(bounds, bounds[1:])):
        if b <= a:
            continue
        if i > 0:                      # starts at a joint
            rows.append(a + JOINT_ZONE * (b - a))
        if i < len(bounds) - 2:        # ends at a joint
            rows.append(b - JOINT_ZONE * (b - a))
        rows.append(b)
    rows = sorted(set(rows))

    def place(y: float):
        part = 0
        while part + 1 < len(dirs) and y > joints_y[part + 1]:
            part += 1
        t = (y - joints_y[part]) / (joints_y[part + 1] - joints_y[part])
        point = dst[part] + t * (dst[part + 1] - dst[part])
        normal = normals[part]
        if part + 1 < len(dirs) and abs(y - joints_y[part + 1]) < 1e-6:   # at a joint
            mitre = normals[part] + normals[part + 1]
            if np.linalg.norm(mitre) > 0.2:
                mitre /= np.linalg.norm(mitre)
                normal = mitre / max(float(np.dot(mitre, normals[part])), 1 / MAX_KNEE_WIDENING)
        return point, normal

    src_edges, dst_edges = [], []
    for y in rows:
        point, normal = place(y)
        src_edges.append((np.float32([0, y]), np.float32([w, y])))
        dst_edges.append((point - normal * cx * across, point + normal * (w - cx) * across))

    corners = np.array([p for edge in dst_edges for p in edge])
    origin = np.floor(corners.min(axis=0)) - 2
    size = np.ceil(corners.max(axis=0) - origin).astype(int) + 3
    canvas = np.zeros((size[1], size[0], 4), np.uint8)
    for (s0, d0), (s1, d1) in zip(zip(src_edges, dst_edges), zip(src_edges[1:], dst_edges[1:])):
        s_quad = [s0[0], s0[1], s1[1], s1[0]]
        d_quad = [d0[0] - origin, d0[1] - origin, d1[1] - origin, d1[0] - origin]
        for tri in ((0, 1, 2), (0, 2, 3)):
            _warp_triangle(image, np.float32([s_quad[k] for k in tri]),
                           np.float32([d_quad[k] for k in tri]), canvas)
    place_matrix = np.float32([[1, 0, origin[0]], [0, 1, origin[1]]])
    return canvas, place_matrix, 1.0


def _warp_triangle(image: np.ndarray, s_tri: np.ndarray, d_tri: np.ndarray, canvas: np.ndarray) -> None:
    """Copies one triangle of the picture onto the canvas, stretched to fit.
    Only the triangle's own small box is warped, which keeps it fast."""
    e1, e2 = d_tri[1] - d_tri[0], d_tri[2] - d_tri[0]
    if abs(float(e1[0] * e2[1] - e1[1] * e2[0])) < 1.0:
        return   # folded flat: nothing to draw
    ch, cw = canvas.shape[:2]
    x0, y0 = np.maximum(np.floor(d_tri.min(axis=0)).astype(int), 0)
    x1, y1 = np.minimum(np.ceil(d_tri.max(axis=0)).astype(int) + 1, [cw, ch])
    if x1 <= x0 or y1 <= y0:
        return
    local = d_tri - np.float32([x0, y0])
    matrix = cv2.getAffineTransform(s_tri, local)
    warped = cv2.warpAffine(image, matrix, (int(x1 - x0), int(y1 - y0)), flags=cv2.INTER_LINEAR,
                            borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0, 0))
    mask = np.zeros((y1 - y0, x1 - x0), np.uint8)
    cv2.fillConvexPoly(mask, np.round(local).astype(np.int32), 1)
    np.copyto(canvas[y0:y1, x0:x1], warped, where=mask[:, :, None].astype(bool))


def _bent_sleeve(piece: Piece, shoulder: np.ndarray, arm_dir: np.ndarray, arm_len: float,
                 top: np.ndarray, down: np.ndarray, torso: float):
    """The sleeve bent into a four-cornered shape: its top edge along the
    armhole, its cuff across the upper arm. Returns a layer for _composite."""
    across = np.array([-down[1], down[0]])
    outwards = across if float(np.dot(shoulder - top, across)) >= 0 else -across
    # The quarter turn that takes "down" to "outwards": applied to the arm, it
    # gives the side of the arm that continues the shoulder seam.
    turn = 1.0 if np.allclose(outwards, across) else -1.0
    seam_side = turn * np.array([-arm_dir[1], arm_dir[0]])

    seam = shoulder - down * ARMHOLE_TOP[0] * torso + outwards * ARMHOLE_TOP[1] * torso
    armpit = shoulder + down * ARMHOLE_BOTTOM[0] * torso + outwards * ARMHOLE_BOTTOM[1] * torso
    cuff = shoulder + arm_dir * min(SLEEVE_LENGTH * torso, 0.9 * arm_len)
    half = CUFF_HALF_WIDTH * torso
    dst = np.float32([seam, armpit, cuff - seam_side * half, cuff + seam_side * half])
    src = piece.box()   # top-left = seam end of the top edge, top-right = armpit end

    origin = np.floor(dst.min(axis=0)) - 2
    size = np.ceil(dst.max(axis=0) - origin).astype(int) + 3
    canvas = np.zeros((size[1], size[0], 4), np.uint8)

    for i in range(SEGMENTS):
        v0, v1 = i / SEGMENTS, (i + 1) / SEGMENTS
        # strip corners: seam side and armpit side, at v0 and v1 along the sleeve
        s_strip = [src[0] + (src[3] - src[0]) * v0, src[1] + (src[2] - src[1]) * v0,
                   src[1] + (src[2] - src[1]) * v1, src[0] + (src[3] - src[0]) * v1]
        d_strip = [dst[0] + (dst[3] - dst[0]) * v0, dst[1] + (dst[2] - dst[1]) * v0,
                   dst[1] + (dst[2] - dst[1]) * v1, dst[0] + (dst[3] - dst[0]) * v1]
        for tri in ((0, 1, 2), (0, 2, 3)):
            _warp_triangle(piece.image, np.float32([s_strip[k] for k in tri]),
                           np.float32([d_strip[k] for k in tri]) - origin, canvas)
    place = np.float32([[1, 0, origin[0]], [0, 1, origin[1]]])
    return canvas, place, 1.0


def _nearer_side(pose: Pose, shoulder: int, yaw: float) -> bool:
    """True for the arm nearer the camera when the person stands side-on."""
    if abs(yaw) < SIDE_ON or abs(yaw) > 180 - SIDE_ON:
        return False
    if pose.world is not None:
        other = RIGHT_SHOULDER if shoulder == LEFT_SHOULDER else LEFT_SHOULDER
        return bool(pose.world[shoulder][2] < pose.world[other][2])
    return (shoulder == LEFT_SHOULDER) == (yaw > 0)

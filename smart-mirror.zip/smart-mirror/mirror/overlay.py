"""The tracking skeleton, drawn over the mirror image to check tracking."""
from __future__ import annotations

import cv2
import numpy as np

from .pose import Pose

SKELETON = [
    (11, 12), (11, 13), (13, 15), (12, 14), (14, 16),
    (11, 23), (12, 24), (23, 24),
    (23, 25), (25, 27), (27, 29), (29, 31),
    (24, 26), (26, 28), (28, 30), (30, 32),
]


def draw_skeleton(frame: np.ndarray, pose: Pose | None, lines: dict[str, float] | None = None) -> None:
    if pose is None:
        return
    pts = pose.points.astype(int)
    for a, b in SKELETON:
        if pose.visible(a) and pose.visible(b):
            cv2.line(frame, tuple(pts[a]), tuple(pts[b]), (80, 220, 255), 2, cv2.LINE_AA)
    for i in range(11, 33):
        if pose.visible(i):
            cv2.circle(frame, tuple(pts[i]), 3, (255, 255, 255), -1, cv2.LINE_AA)
    if lines:
        for row in lines.values():
            cv2.line(frame, (0, int(row)), (frame.shape[1], int(row)), (0, 200, 0), 1)

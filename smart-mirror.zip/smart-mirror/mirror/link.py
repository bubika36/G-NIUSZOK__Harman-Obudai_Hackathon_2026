"""The local link between the mirror and the touchscreen control panel.

Both run on the same Pi and talk over UDP on 127.0.0.1:
- panel -> mirror: one command per packet, e.g. "measure", "select 3"
- mirror -> panel: the mirror's state as JSON, a few times per second

UDP keeps the two programs independent: either can start, stop or crash
without the other waiting on it.
"""
from __future__ import annotations

import json
import socket

HOST = "127.0.0.1"

COMMANDS = ("measure", "cancel", "next", "prev", "bottom", "select", "garment", "skeleton", "quit")


class Receiver:
    """Non-blocking UDP receiver; call poll() from a loop."""

    def __init__(self, port: int):
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sock.bind((HOST, port))
        self.sock.setblocking(False)

    def poll(self) -> list[bytes]:
        packets = []
        while True:
            try:
                data, _ = self.sock.recvfrom(65535)
            except (BlockingIOError, InterruptedError):
                return packets
            packets.append(data)

    def close(self) -> None:
        self.sock.close()


class Sender:
    def __init__(self, port: int):
        self.port = port
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

    def send(self, data: bytes) -> None:
        try:
            self.sock.sendto(data, (HOST, self.port))
        except OSError:
            pass  # nobody listening; that's fine

    def send_command(self, command: str) -> None:
        self.send(command.encode("utf-8"))

    def send_state(self, state: dict) -> None:
        self.send(json.dumps(state).encode("utf-8"))

    def close(self) -> None:
        self.sock.close()


def parse_command(data: bytes) -> tuple[str, int | None] | None:
    """b"select 3" -> ("select", 3); b"measure" -> ("measure", None).
    Returns None for anything unknown."""
    parts = data.decode("utf-8", "ignore").strip().lower().split()
    if not parts or parts[0] not in COMMANDS:
        return None
    if parts[0] == "select":
        if len(parts) != 2 or not parts[1].isdigit():
            return None
        return "select", int(parts[1])
    return parts[0], None

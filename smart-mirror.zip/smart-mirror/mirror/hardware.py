"""The ultrasonic distance sensor on the Pi's GPIO pins.

The sensor is pinged in a background thread, so the mirror never waits for
it. read() answers at once: the median of the last second's echoes, or None
when there are too few (nobody in front, sensor unplugged, soft clothing
swallowing the sound). Without gpiozero or the sensor, read() is always None
and the floor-mark distance is used instead.
"""
from __future__ import annotations

import statistics
import threading
import time
from collections import deque

SPEED_OF_SOUND_M_S = 343.0


class DistanceReader:
    MAX_RANGE_M = 4.0
    FRESH_S = 1.0        # echoes older than this don't count
    MIN_ECHOES = 3       # need at least this many fresh echoes for a reading
    PAUSE_S = 0.08       # between pings, so the last ping's echo has died out
    ECHO_TIMEOUT_S = 0.06

    def __init__(self, trigger_pin: int | None, echo_pin: int | None):
        self._echoes: deque[tuple[float, float]] = deque(maxlen=20)
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._echo_done = threading.Event()
        self._rise = None
        self._width_s = None
        self._trigger = None
        if trigger_pin is None or echo_pin is None:
            return
        try:
            from gpiozero import DigitalOutputDevice, InputDevice

            self._trigger = DigitalOutputDevice(trigger_pin)
            self._echo = InputDevice(echo_pin, pull_up=False)
            self._ticks_diff = self._echo.pin_factory.ticks_diff
            pin = self._echo.pin
            pin.edges = "both"
            pin.bounce = None
            pin.when_changed = self._echo_changed
        except Exception as exc:  # no GPIO (laptop) or a wiring/pin problem
            print(f"Az ultrahangos szenzor nem érhető el ({exc}); a távolság a talpból vagy a beállított "
                  f"fix értékből jön.")
            self._trigger = None
            return
        threading.Thread(target=self._ping_forever, daemon=True).start()

    def _echo_changed(self, ticks, state) -> None:
        """Called by gpiozero on each edge of the echo pin, with its timestamp."""
        if state:
            self._rise = ticks
        elif self._rise is not None:
            self._width_s = self._ticks_diff(ticks, self._rise)
            self._rise = None
            self._echo_done.set()

    def _ping(self) -> None:
        self._trigger.on()
        time.sleep(0.00001)  # the sensor needs a pulse of at least 10 µs
        self._trigger.off()

    def _ping_forever(self) -> None:
        while not self._stop.is_set():
            self._rise = None
            self._width_s = None
            self._echo_done.clear()
            self._ping()
            if self._echo_done.wait(self.ECHO_TIMEOUT_S) and self._width_s is not None:
                distance = self._width_s * SPEED_OF_SOUND_M_S / 2
                # A sensor that hears nothing still answers, with a pulse of
                # about 38 ms (6.5 m); anything past 4 m counts as no echo.
                if 0.02 <= distance <= self.MAX_RANGE_M:
                    with self._lock:
                        self._echoes.append((time.monotonic(), distance))
            self._stop.wait(self.PAUSE_S)

    def read(self) -> float | None:
        """Metres from the sensor to the person, or None without recent echoes.
        Never waits."""
        now = time.monotonic()
        with self._lock:
            recent = [d for t, d in self._echoes if now - t <= self.FRESH_S]
        if len(recent) < self.MIN_ECHOES:
            return None
        return statistics.median(recent)

    def close(self) -> None:
        self._stop.set()

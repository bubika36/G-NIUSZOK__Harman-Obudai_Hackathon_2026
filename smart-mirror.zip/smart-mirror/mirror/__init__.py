"""Smart mirror: camera, body tracking, measurement and garment code."""

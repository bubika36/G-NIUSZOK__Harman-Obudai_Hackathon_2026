#!/usr/bin/env python3
"""Touchscreen control panel for the smart mirror, on the Pi's 7" screen.

Pick a top and a bottom, turn the clothes or skeleton on and off, and start
a measurement. Measure counts down first, so there's time to walk from the
touchscreen to the floor mark.

run_mirror.py starts this automatically. To run it on its own:
    python control_panel.py [--windowed]
"""
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from dataclasses import dataclass
from datetime import datetime

os.environ.setdefault("PYGAME_HIDE_SUPPORT_PROMPT", "1")

import cv2  # noqa: E402
import pygame  # noqa: E402

from mirror.config import load_config  # noqa: E402
from mirror.display import open_window  # noqa: E402
from mirror.link import Receiver, Sender  # noqa: E402
from mirror.garments import load_garments  # noqa: E402
from mirror.text import LABELS, number, whole  # noqa: E402

BG = (17, 21, 25)
SURFACE = (30, 36, 41)
SURFACE_DOWN = (46, 54, 60)
LINE = (54, 64, 71)
TEXT = (232, 238, 240)
MUTED = (147, 163, 170)
ACCENT = (43, 179, 192)
ACCENT_DOWN = (30, 138, 148)
ON_ACCENT = (6, 22, 26)
DANGER = (226, 76, 80)
DANGER_DOWN = (180, 56, 60)
GOOD = (96, 200, 132)
WARN = (240, 180, 90)

STALE_AFTER_S = 2.0    # no update from the mirror for this long = not running
EXIT_CONFIRM_S = 3.0   # time to tap Exit a second time


@dataclass
class Button:
    rect: pygame.Rect
    action: str
    label: str = ""
    kind: str = "normal"  # normal, primary, danger, toggle, tile
    enabled: bool = True
    value: int | None = None


TABS = (("top", "Felsők"), ("bottom", "Nadrágok"))


def garment_thumbnails(folder: str) -> list[tuple[str, pygame.Surface, str]]:
    """The same garments, in the same order, as the mirror loads:
    (name, picture, kind)."""
    thumbs = []
    for garment in load_garments(folder, pictures=False):
        rgba = cv2.cvtColor(garment.thumbnail, cv2.COLOR_BGRA2RGBA)
        h, w = rgba.shape[:2]
        surface = pygame.image.frombuffer(rgba.tobytes(), (w, h), "RGBA").convert_alpha()
        thumbs.append((garment.name, surface, garment.kind))
    return thumbs


class Panel:
    def __init__(self, size: tuple[int, int], thumbs: list[tuple[str, pygame.Surface, str]], send):
        self.send = send
        self.thumbs = thumbs
        self.kinds = [kind for _, _, kind in thumbs]
        # Tops and bottoms get a tab each, when there are both.
        self.tabbed = len(set(self.kinds)) > 1
        self.tab = "top" if "top" in self.kinds or not self.kinds else self.kinds[0]
        self.state: dict = {}
        self.state_at = 0.0
        self.page = 0
        self.buttons: list[Button] = []
        self.pressed: Button | None = None
        self.exit_armed_until = 0.0
        self.quit_requested = False
        self._last_worn: list[int] | None = None
        self._scaled_thumbs: dict[tuple[int, int, int], pygame.Surface] = {}
        self.resize(size)

    # ---------- state and input ----------

    def resize(self, size: tuple[int, int]) -> None:
        self.w, self.h = size
        self.portrait = self.h > self.w
        base = (480, 800) if self.portrait else (800, 480)
        self.s = min(self.w / base[0], self.h / base[1])
        px = lambda n: max(10, int(n * self.s))  # noqa: E731
        self.font_title = pygame.font.SysFont("dejavusans", px(24), bold=True)
        self.font = pygame.font.SysFont("dejavusans", px(19))
        self.font_small = pygame.font.SysFont("dejavusans", px(15))
        self.font_button = pygame.font.SysFont("dejavusans", px(22), bold=True)
        self.font_toggle = pygame.font.SysFont("dejavusans", px(19), bold=True)
        self.font_number = pygame.font.SysFont("dejavusans", px(24), bold=True)
        self.font_big = pygame.font.SysFont("dejavusans", px(30), bold=True)
        self._scaled_thumbs.clear()

    @property
    def connected(self) -> bool:
        return time.monotonic() - self.state_at < STALE_AFTER_S and not self.state.get("stopped")

    def update_state(self, state: dict) -> None:
        self.state, self.state_at = state, time.monotonic()
        worn = list(state.get("worn") or [])
        if self._last_worn is not None:
            # Follow changes made on the keyboard: show the newly worn garment.
            for index in worn:
                if index not in self._last_worn and 0 <= index < len(self.kinds):
                    self.show(index)
        self._last_worn = worn

    def show(self, index: int) -> None:
        """Switch to the tab and page with this garment on it."""
        if self.tabbed:
            self.tab = self.kinds[index]
        listed = self.listed
        if index in listed:
            self.page = listed.index(index) // self.per_page

    @property
    def listed(self) -> list[int]:
        """The garments on the current tab, as indexes into the full list."""
        if not self.tabbed:
            return list(range(len(self.thumbs)))
        return [i for i, kind in enumerate(self.kinds) if kind == self.tab]

    def press(self, pos) -> None:
        self.pressed = next((b for b in self.buttons if b.enabled and b.rect.collidepoint(pos)), None)

    def release(self, pos) -> None:
        button, self.pressed = self.pressed, None
        if button is not None and button.rect.collidepoint(pos):
            self.activate(button)

    def activate(self, button: Button) -> None:
        if button.action == "page_prev":
            self.page = max(0, self.page - 1)
        elif button.action == "page_next":
            self.page = min(self.pages - 1, self.page + 1)
        elif button.action == "exit":
            if time.monotonic() < self.exit_armed_until:
                self.send("quit")
                self.quit_requested = True
            else:
                self.exit_armed_until = time.monotonic() + EXIT_CONFIRM_S
        elif button.action == "tab":
            self.tab, self.page = TABS[button.value][0], 0
        elif button.action == "select":
            self.send(f"select {button.value}")
            # Show the choice at once; the mirror confirms on its next update.
            # Tapping what's being worn takes it off; anything else replaces
            # the garment of the same kind.
            index, worn = button.value, list(self.state.get("worn") or [])
            if index in worn and self.state.get("show_garment", True):
                worn.remove(index)
            else:
                worn = [i for i in worn if self.kinds[i] != self.kinds[index]] + [index]
            self.state = dict(self.state, worn=worn, show_garment=True)
            self._last_worn = worn
        else:
            self.send(button.action)

    # ---------- layout ----------

    @property
    def grid_shape(self) -> tuple[int, int]:
        return (2, 2) if self.portrait else (3, 2)  # columns, rows

    @property
    def per_page(self) -> int:
        cols, rows = self.grid_shape
        return cols * rows

    @property
    def pages(self) -> int:
        return max(1, -(-len(self.listed) // self.per_page))

    def layout(self) -> dict[str, pygame.Rect]:
        s, w, h = self.s, self.w, self.h
        pad = int(14 * s)
        bar = int(58 * s)
        measure_h = int(92 * s)
        toggle_h = int(56 * s)
        pager_h = int(52 * s) if self.pages > 1 else 0
        tabs_h = int(44 * s) if self.tabbed else 0
        r = {"bar": pygame.Rect(0, 0, w, bar)}
        if self.portrait:
            x, width, y = pad, w - 2 * pad, bar + pad
            r["tabs"] = pygame.Rect(x, y, width, tabs_h)
            y += tabs_h + (pad // 2 if tabs_h else 0)
            grid_h = int(h * 0.40) - tabs_h
            r["grid"] = pygame.Rect(x, y, width, grid_h)
            y += grid_h
            r["pager"] = pygame.Rect(x, y, width, pager_h)
            y += pager_h + pad
            r["toggles"] = pygame.Rect(x, y, width, toggle_h)
            y += toggle_h + pad
            r["measure"] = pygame.Rect(x, h - pad - measure_h, width, measure_h)
            r["card"] = pygame.Rect(x, y, width, r["measure"].top - pad - y)
        else:
            split = int(w * 0.57)
            left = pygame.Rect(pad, bar + pad, split - int(1.5 * pad), h - bar - 2 * pad)
            right = pygame.Rect(split + pad // 2, bar + pad, w - split - int(1.5 * pad), h - bar - 2 * pad)
            r["tabs"] = pygame.Rect(left.x, left.y, left.w, tabs_h)
            grid_top = left.y + tabs_h + (pad // 2 if tabs_h else 0)
            r["grid"] = pygame.Rect(left.x, grid_top, left.w, left.bottom - pager_h - grid_top)
            r["pager"] = pygame.Rect(left.x, r["grid"].bottom, left.w, pager_h)
            r["toggles"] = pygame.Rect(right.x, right.y, right.w, toggle_h)
            r["measure"] = pygame.Rect(right.x, right.bottom - measure_h, right.w, measure_h)
            top = r["toggles"].bottom + pad
            r["card"] = pygame.Rect(right.x, top, right.w, r["measure"].top - pad - top)
        return r

    # ---------- drawing ----------

    def draw(self, screen: pygame.Surface) -> None:
        self.buttons = []
        screen.fill(BG)
        r = self.layout()
        self.draw_bar(screen, r["bar"])
        if self.tabbed:
            self.draw_tabs(screen, r["tabs"])
        self.draw_grid(screen, r["grid"])
        if self.pages > 1:
            self.draw_pager(screen, r["pager"])
        self.draw_toggles(screen, r["toggles"])
        self.draw_card(screen, r["card"])
        self.draw_measure(screen, r["measure"])

    def draw_bar(self, screen, rect) -> None:
        pygame.draw.rect(screen, SURFACE, rect)
        pygame.draw.line(screen, LINE, (rect.left, rect.bottom - 1), (rect.right, rect.bottom - 1))
        pad = int(14 * self.s)
        title = self.font_title.render("ChangAR", True, TEXT)
        screen.blit(title, (pad, rect.centery - title.get_height() // 2))

        armed = time.monotonic() < self.exit_armed_until
        exit_w = int((170 if armed else 74) * self.s)
        exit_rect = pygame.Rect(rect.right - pad - exit_w, rect.y + int(9 * self.s), exit_w, rect.h - int(18 * self.s))
        self.add_button(screen, Button(exit_rect, "exit", "Koppints újra" if armed else "Kilépés",
                                       "danger" if armed else "normal"), font=self.font_small)

        if not self.connected:
            chips = [("A tükör nem fut", WARN)]
        else:
            st = self.state
            chips = [("Valaki a képen", GOOD) if st.get("person") else ("Senki sincs a képen", MUTED)]
            if st.get("distance_m") is not None:
                via = " (talp alapján)" if st.get("distance_source") == "feet" else ""
                chips.append((f"Távolság: {number(st['distance_m'], 2)} m{via}", TEXT))
        x = exit_rect.left - pad
        for text, colour in chips:
            label = self.font_small.render(text, True, colour)
            x -= label.get_width()
            if x < title.get_width() + 2 * pad:
                break
            if colour in (GOOD, WARN, MUTED):
                dot = int(5 * self.s)
                pygame.draw.circle(screen, colour, (x - dot - 4, rect.centery), dot)
                screen.blit(label, (x, rect.centery - label.get_height() // 2))
                x -= 2 * dot + 4
            else:
                screen.blit(label, (x, rect.centery - label.get_height() // 2))
            x -= pad

    def draw_tabs(self, screen, rect) -> None:
        gap = int(10 * self.s)
        half = (rect.w - gap) // 2
        for i, (kind, label) in enumerate(TABS):
            tab = pygame.Rect(rect.x + i * (half + gap), rect.y, half, rect.h)
            self.add_button(screen, Button(tab, "tab", label, "toggle" if kind == self.tab else "normal",
                                           value=i), font=self.font_toggle)

    def draw_grid(self, screen, rect) -> None:
        if not self.thumbs:
            self.text_block(screen, rect, "Még nincs ruha. Tegyél PNG képeket és garments.json fájlt a garments mappába.",
                            MUTED)
            return
        cols, rows = self.grid_shape
        gap = int(10 * self.s)
        tile_w = (rect.w - gap * (cols - 1)) // cols
        tile_h = (rect.h - gap * (rows - 1)) // rows
        worn = set(self.state.get("worn") or []) if self.state.get("show_garment", True) else set()
        first = self.page * self.per_page
        for slot, index in enumerate(self.listed[first:first + self.per_page]):
            col, row = slot % cols, slot // cols
            tile = pygame.Rect(rect.x + col * (tile_w + gap), rect.y + row * (tile_h + gap), tile_w, tile_h)
            self.add_button(screen, Button(tile, "select", kind="tile", value=index))
            name, image, _ = self.thumbs[index]
            label = self.fit(self.font_small, name, tile.w - gap)
            text = self.font_small.render(label, True, TEXT)
            label_h = text.get_height() + gap
            area = tile.inflate(-2 * gap, -2 * gap)
            area.h -= label_h
            thumb = self.scaled_thumb(index, image, area.size)
            screen.blit(thumb, thumb.get_rect(center=area.center))
            screen.blit(text, (tile.centerx - text.get_width() // 2, tile.bottom - label_h))
            if index in worn:
                pygame.draw.rect(screen, ACCENT, tile, max(3, int(4 * self.s)), border_radius=self.radius)

    def draw_pager(self, screen, rect) -> None:
        gap = int(10 * self.s)
        bw = int(84 * self.s)
        row = pygame.Rect(rect.x, rect.y + gap, rect.w, rect.h - gap)
        self.add_button(screen, Button(pygame.Rect(row.x, row.y, bw, row.h), "page_prev", "‹",
                                       enabled=self.page > 0))
        self.add_button(screen, Button(pygame.Rect(row.right - bw, row.y, bw, row.h), "page_next", "›",
                                       enabled=self.page < self.pages - 1))
        text = self.font_small.render(f"{self.page + 1}. oldal / {self.pages}", True, MUTED)
        screen.blit(text, text.get_rect(center=row.center))

    def draw_toggles(self, screen, rect) -> None:
        gap = int(10 * self.s)
        half = (rect.w - gap) // 2
        on_g = self.state.get("show_garment", True)
        on_s = self.state.get("show_skeleton", False)
        enabled = self.connected
        self.add_button(screen, Button(pygame.Rect(rect.x, rect.y, half, rect.h), "garment",
                                       f"Ruha: {'be' if on_g else 'ki'}", "toggle" if on_g else "normal",
                                       enabled=enabled), font=self.font_toggle)
        self.add_button(screen, Button(pygame.Rect(rect.x + half + gap, rect.y, half, rect.h), "skeleton",
                                       f"Csontváz: {'be' if on_s else 'ki'}", "toggle" if on_s else "normal",
                                       enabled=enabled), font=self.font_toggle)

    def draw_card(self, screen, rect) -> None:
        if rect.h <= 0:
            return
        pygame.draw.rect(screen, SURFACE, rect, border_radius=self.radius)
        pad = int(14 * self.s)
        inner = rect.inflate(-2 * pad, -2 * pad)
        result = self.state.get("result") if self.connected else None
        y = inner.y
        stamp_w = 0
        if result and result.get("time"):
            when = datetime.strptime(result["time"], "%Y-%m-%d %H:%M:%S").strftime("%H:%M")
            stamp = self.font_small.render(when, True, MUTED)
            stamp_w = stamp.get_width() + pad
            screen.blit(stamp, (inner.right - stamp.get_width(), y))
        heading = "UTOLSÓ MÉRÉS"
        if result:
            long = f"{heading} (cm, szélesség elölről)"
            heading = long if self.font_small.size(long)[0] <= inner.w - stamp_w else f"{heading} (cm)"
        title = self.font_small.render(heading, True, MUTED)
        screen.blit(title, (inner.x, y))
        y += title.get_height() + pad // 2

        status = self.state.get("status", "") if self.connected else "Várakozás a tükör indulására..."
        status_lines = self.wrap(self.font_small, status, inner.w, 2)
        status_h = len(status_lines) * self.font_small.get_linesize()
        rows_bottom = inner.bottom - status_h - pad // 2

        if result:
            widths = result.get("width_cm") or {}
            columns = [[(LABELS["height"], result.get("height_cm"))]
                       + [(LABELS[n], widths.get(n)) for n in ("chest", "waist", "hip")]]
            legs = result.get("legs_cm") or {}
            second = [(LABELS[n], legs.get(n)) for n in ("leg", "thigh") if n in legs]
            if second:
                columns.append(second)
            self.draw_numbers(screen, pygame.Rect(inner.x, y, inner.w, rows_bottom - y), columns)
        else:
            hint = ("Még nincs mérés. Koppints a Mérés gombra, majd állj a padlón lévő vonalra, "
                    "és vedd fel a tükörben látható pózt.")
            for line in self.wrap(self.font, hint, inner.w, 3):
                screen.blit(self.font.render(line, True, TEXT), (inner.x, y))
                y += self.font.get_linesize()

        y = inner.bottom - status_h
        for line in status_lines:
            screen.blit(self.font_small.render(line, True, MUTED), (inner.x, y))
            y += self.font_small.get_linesize()

    @staticmethod
    def shown_value(value) -> str:
        """A measurement in whole centimetres, or "-"."""
        return whole(value) if value else "-"

    def draw_numbers(self, screen, rect, columns: list[list[tuple[str, float | None]]]) -> None:
        """Label and value rows, in side-by-side columns, in the biggest font that fits."""
        gap = int(14 * self.s)
        col_w = (rect.w - gap * (len(columns) - 1)) // len(columns)
        line_h = rect.h // max(len(col) for col in columns)
        cells = [(name, self.shown_value(value)) for col in columns for name, value in col]
        choices = [(self.font_big, self.font), (self.font_number, self.font),
                   (self.font, self.font_small), (self.font_small, self.font_small)]
        number_font, label_font = next(
            ((nf, lf) for nf, lf in choices
             if nf.get_linesize() <= line_h
             and all(lf.size(n)[0] + nf.size(v)[0] + gap // 2 <= col_w for n, v in cells)),
            choices[-1])
        for c, col in enumerate(columns):
            x = rect.x + c * (col_w + gap)
            y = rect.y
            for name, value in col:
                shown = number_font.render(self.shown_value(value), True, TEXT)
                room = col_w - shown.get_width() - gap // 2
                label = label_font.render(self.fit(label_font, name, room), True, MUTED)
                screen.blit(label, (x, y + (shown.get_height() - label.get_height()) // 2))
                screen.blit(shown, (x + col_w - shown.get_width(), y))
                y += line_h

    def draw_measure(self, screen, rect) -> None:
        phase = self.state.get("phase", "idle") if self.connected else "offline"
        if phase == "pose":
            score = (self.state.get("pose") or {}).get("score")
            label = f"Mégse  ({round(score * 100)}%)" if score is not None else "Mégse"
            button = Button(rect, "cancel", label, "danger")
        elif phase == "measuring":
            button = Button(rect, "none", "Mérés...", "primary", enabled=False)
        else:
            button = Button(rect, "measure", "Mérés", "primary", enabled=phase == "idle")
        self.add_button(screen, button, font=self.font_big)

    # ---------- helpers ----------

    @property
    def radius(self) -> int:
        return max(6, int(12 * self.s))

    def add_button(self, screen, button: Button, font=None) -> None:
        self.buttons.append(button)
        down = self.pressed is not None and self.pressed.rect == button.rect
        if button.kind == "primary":
            fill, fg = (ACCENT_DOWN if down else ACCENT), ON_ACCENT
        elif button.kind == "danger":
            fill, fg = (DANGER_DOWN if down else DANGER), TEXT
        elif button.kind == "toggle":
            fill, fg = (ACCENT_DOWN if down else SURFACE), ACCENT
        else:
            fill, fg = (SURFACE_DOWN if down else SURFACE), TEXT
        if not button.enabled:
            fill, fg = SURFACE, LINE if button.kind != "primary" else MUTED
        pygame.draw.rect(screen, fill, button.rect, border_radius=self.radius)
        if button.kind == "toggle" and button.enabled:
            pygame.draw.rect(screen, ACCENT, button.rect, max(2, int(2 * self.s)), border_radius=self.radius)
        if button.label:
            font = font or self.font_button
            text = font.render(self.fit(font, button.label, button.rect.w - 8), True, fg)
            screen.blit(text, text.get_rect(center=button.rect.center))

    def scaled_thumb(self, index: int, image: pygame.Surface, size: tuple[int, int]) -> pygame.Surface:
        key = (index, *size)
        if key not in self._scaled_thumbs:
            iw, ih = image.get_size()
            scale = min(size[0] / iw, size[1] / ih)
            target = (max(1, int(iw * scale)), max(1, int(ih * scale)))
            self._scaled_thumbs[key] = pygame.transform.smoothscale(image, target)
        return self._scaled_thumbs[key]

    @staticmethod
    def fit(font, text: str, width: int) -> str:
        if font.size(text)[0] <= width:
            return text
        while text and font.size(text + "...")[0] > width:
            text = text[:-1]
        return text + "..."

    def wrap(self, font, text: str, width: int, max_lines: int) -> list[str]:
        lines, line = [], ""
        for word in text.split():
            candidate = f"{line} {word}".strip()
            if font.size(candidate)[0] <= width:
                line = candidate
            else:
                lines.append(line)
                line = word
        if line:
            lines.append(line)
        if len(lines) > max_lines:
            lines = lines[:max_lines]
            lines[-1] = self.fit(font, lines[-1] + " ...", width)
        return [self.fit(font, ln, width) for ln in lines]

    def text_block(self, screen, rect, text: str, colour) -> None:
        y = rect.y
        for line in self.wrap(self.font, text, rect.w, 4):
            screen.blit(self.font.render(line, True, colour), (rect.x, y))
            y += self.font.get_linesize()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", default="config.json")
    parser.add_argument("--windowed", action="store_true", help="a window instead of full screen")
    args = parser.parse_args()
    cfg = load_config(args.config)

    try:
        receiver = Receiver(cfg.panel.state_port)
    except OSError:
        print(f"A(z) {cfg.panel.state_port} port foglalt: talán már fut egy másik vezérlőpanel?")
        return 1
    sender = Sender(cfg.panel.command_port)

    pygame.display.init()
    pygame.font.init()
    pygame.display.set_caption("ChangAR vezérlőpanel")
    screen = open_window(pygame, cfg.panel.display_index, cfg.panel.fullscreen and not args.windowed, (800, 480))
    panel = Panel(screen.get_size(), garment_thumbnails(cfg.mirror.garments_dir), sender.send_command)
    clock = pygame.time.Clock()

    running = True
    while running and not panel.quit_requested:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.VIDEORESIZE:
                panel.resize(screen.get_size())
            elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                panel.press(event.pos)  # touches arrive as mouse clicks
            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                panel.release(event.pos)
            elif event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE and args.windowed:
                running = False
        for packet in receiver.poll():
            try:
                panel.update_state(json.loads(packet))
            except ValueError:
                pass
        panel.draw(screen)
        pygame.display.flip()
        clock.tick(30)

    receiver.close()
    sender.close()
    pygame.quit()
    return 0


if __name__ == "__main__":
    sys.exit(main())

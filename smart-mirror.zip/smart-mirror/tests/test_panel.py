"""The touchscreen panel and the commands it sends, without a real screen."""
import os
import time

os.environ["SDL_VIDEODRIVER"] = "dummy"

import pygame  # noqa: E402
import pytest  # noqa: E402

from control_panel import Panel  # noqa: E402
from mirror.link import Receiver, Sender, parse_command  # noqa: E402


@pytest.fixture(scope="module", autouse=True)
def screen():
    pygame.init()
    yield pygame.display.set_mode((800, 480))
    pygame.quit()


def make_panel(screen, garments=8, state=None, kinds=None):
    kinds = kinds or ["top"] * garments
    thumbs = [(f"Garment {i}", pygame.Surface((40, 60), pygame.SRCALPHA), kind) for i, kind in enumerate(kinds)]
    sent = []
    panel = Panel(screen.get_size(), thumbs, sent.append)
    panel.update_state(state or {"phase": "idle", "status": "Ready", "worn": [0],
                                 "show_garment": True, "show_skeleton": False})
    panel.draw(screen)
    return panel, sent


def tap(panel, screen, button):
    panel.press(button.rect.center)
    panel.release(button.rect.center)
    panel.draw(screen)


def find(panel, action, value=None):
    return next(b for b in panel.buttons if b.action == action and (value is None or b.value == value))


def test_tap_measure_sends_measure(screen):
    panel, sent = make_panel(screen)
    tap(panel, screen, find(panel, "measure"))
    assert sent == ["measure"]


def test_measure_becomes_cancel_during_the_pose_guide(screen):
    panel, sent = make_panel(screen, state={"phase": "pose", "pose": {"score": 0.62}, "status": ""})
    button = find(panel, "cancel")
    assert button.label == "Mégse  (62%)"
    tap(panel, screen, button)
    assert sent == ["cancel"]


def test_measure_disabled_while_measuring(screen):
    panel, sent = make_panel(screen, state={"phase": "measuring", "status": ""})
    button = next(b for b in panel.buttons if b.label == "Mérés...")
    assert not button.enabled
    panel.press(button.rect.center)
    panel.release(button.rect.center)
    assert sent == []


def test_tap_garment_selects_it(screen):
    panel, sent = make_panel(screen)
    tap(panel, screen, find(panel, "select", value=2))
    assert sent == ["select 2"]
    assert panel.state["worn"] == [2]


TOPS_AND_BOTTOMS = ["top", "top", "top", "bottom", "bottom"]


def test_tabs_split_tops_and_bottoms(screen):
    panel, sent = make_panel(screen, kinds=TOPS_AND_BOTTOMS,
                             state={"phase": "idle", "status": "", "worn": [3, 0], "show_garment": True})
    assert [b.value for b in panel.buttons if b.action == "select"] == [0, 1, 2]
    tap(panel, screen, find(panel, "tab", value=1))
    assert [b.value for b in panel.buttons if b.action == "select"] == [3, 4]
    assert sent == []


def test_choosing_a_bottom_keeps_the_top(screen):
    panel, sent = make_panel(screen, kinds=TOPS_AND_BOTTOMS,
                             state={"phase": "idle", "status": "", "worn": [3, 0], "show_garment": True})
    tap(panel, screen, find(panel, "tab", value=1))
    tap(panel, screen, find(panel, "select", value=4))
    assert sent == ["select 4"]
    assert sorted(panel.state["worn"]) == [0, 4]


def test_tapping_what_is_worn_takes_it_off(screen):
    panel, sent = make_panel(screen, kinds=TOPS_AND_BOTTOMS,
                             state={"phase": "idle", "status": "", "worn": [3, 0], "show_garment": True})
    tap(panel, screen, find(panel, "select", value=0))
    assert panel.state["worn"] == [3]


def test_panel_follows_keyboard_changes(screen):
    panel, _ = make_panel(screen, kinds=TOPS_AND_BOTTOMS,
                          state={"phase": "idle", "status": "", "worn": [0], "show_garment": True})
    panel.update_state({"phase": "idle", "status": "", "worn": [4, 0], "show_garment": True})
    assert panel.tab == "bottom"


def test_numbers_have_a_decimal_comma():
    from mirror.text import number
    assert number(175.3) == "175,3"
    assert number(79.0) == "79"
    assert number(2.3149, 2) == "2,31"


def test_result_card_shows_legs(screen):
    result = {"time": "2026-11-14 10:00:00", "height_cm": 175.3,
              "width_cm": {"chest": 32.1, "waist": 28.0, "hip": 33.4},
              "legs_cm": {"leg": 88.5, "inside_leg": 79.0, "thigh": None}}
    assert [Panel.shown_value(v) for v in (175.3, 88.5, None)] == ["175", "89", "-"]
    for size in ((800, 480), (480, 800)):
        surface = pygame.Surface(size)
        panel, _ = make_panel(screen, state={"phase": "idle", "status": "Done.", "worn": [0], "result": result})
        panel.resize(size)
        panel.draw(surface)   # no exceptions, and everything inside the screen
        for b in panel.buttons:
            assert pygame.Rect((0, 0), size).contains(b.rect)


def test_paging_shows_next_garments(screen):
    panel, sent = make_panel(screen, garments=8)  # 6 per page in landscape
    assert panel.pages == 2
    tap(panel, screen, find(panel, "page_next"))
    shown = [b.value for b in panel.buttons if b.action == "select"]
    assert shown == [6, 7]
    assert sent == []


def test_dragging_off_a_button_does_nothing(screen):
    panel, sent = make_panel(screen)
    button = find(panel, "measure")
    panel.press(button.rect.center)
    panel.release((0, 0))
    assert sent == []


def test_exit_needs_two_taps(screen):
    panel, sent = make_panel(screen)
    tap(panel, screen, find(panel, "exit"))
    assert sent == [] and not panel.quit_requested
    tap(panel, screen, find(panel, "exit"))
    assert sent == ["quit"] and panel.quit_requested


def test_no_updates_means_mirror_not_running(screen):
    panel, _ = make_panel(screen)
    panel.state_at = time.monotonic() - 10
    panel.draw(screen)
    assert not find(panel, "measure").enabled


def test_portrait_layout_fits(screen):
    panel, _ = make_panel(screen)
    panel.resize((480, 800))
    panel.draw(pygame.Surface((480, 800)))
    for b in panel.buttons:
        assert pygame.Rect(0, 0, 480, 800).contains(b.rect), b


def test_commands_travel_over_udp():
    receiver = Receiver(0)
    port = receiver.sock.getsockname()[1]
    Sender(port).send_command("select 4")
    time.sleep(0.05)
    assert [parse_command(p) for p in receiver.poll()] == [("select", 4)]
    receiver.close()


@pytest.mark.parametrize("raw, expected", [
    (b"measure", ("measure", None)),
    (b" Next \n", ("next", None)),
    (b"select 12", ("select", 12)),
    (b"select x", None),
    (b"reboot", None),
    (b"", None),
])
def test_parse_command(raw, expected):
    assert parse_command(raw) == expected


def test_pose_guide_colours_the_wrong_arm():
    from mirror.pose_guide import RED, GREEN, draw_pose_guide
    surface = pygame.Surface((1440, 2560))
    parts = {"in_view": 1, "facing": 1, "upright": 1, "feet": 1, "knee_left": 1, "knee_right": 1,
             "arm_left": 0.0, "elbow_left": 1, "arm_right": 1, "elbow_right": 1}
    draw_pose_guide(pygame, surface, {"score": 0.55, "parts": parts}, "Emeld el a karjaidat.", 0.75, top=60)
    box_w = int(min(1440 * 0.36, 2560 * 0.42))
    pad = box_w // 14
    inner = box_w - 2 * pad
    x0 = 1440 - box_w - 12

    def pixel(point):
        return tuple(surface.get_at((int(x0 + pad + point[0] * inner), int(60 + pad + point[1] * inner))))[:3]

    assert pixel((0.261, 0.426)) == RED      # the person's left arm: the left of the mirror
    assert pixel((0.739, 0.426)) == GREEN
    draw_pose_guide(pygame, pygame.Surface((600, 800)), None, "Állj a vonalra.", 0.75)   # before any pose

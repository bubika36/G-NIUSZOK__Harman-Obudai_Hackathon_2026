"""Garment views, sleeves and the turn angle."""
import math
from pathlib import Path

import numpy as np
import pytest

from mirror.garments import (
    Piece,
    _bent_limb,
    _composite,
    _nearer_side,
    axis_transform,
    chest_width,
    load_garments,
    pick_views,
    render_garment,
)
from mirror.outfit import Outfit
from mirror.pose import (
    LEFT_ANKLE,
    LEFT_ELBOW,
    LEFT_HIP,
    LEFT_KNEE,
    LEFT_SHOULDER,
    RIGHT_ELBOW,
    RIGHT_SHOULDER,
    Pose,
)
from mirror.turn import YawTracker, estimate_yaw, wrap

GARMENTS = Path(__file__).parent.parent / "garments"


def person(yaw=0.0, left_arm=-10.0, right_arm=-10.0, face=1.0, left_knee=None):
    """A stand-in person, turned by yaw; arms at an angle from straight down
    (degrees, outwards positive, 90 = horizontal). Legs straight down from
    the hips, or the left knee at a given point."""
    pts = np.zeros((33, 2), np.float32)
    vis = np.ones(33, np.float32)
    world = np.zeros((33, 3), np.float32)
    c, s = math.cos(math.radians(yaw)), math.sin(math.radians(yaw))
    pts[11], pts[12] = (200 + 50 * c, 150), (200 - 50 * c, 150)
    pts[23], pts[24] = (200 + 30 * c, 300), (200 - 30 * c, 300)
    world[11], world[12] = (0.19 * c, -0.5, -0.19 * s), (-0.19 * c, -0.5, 0.19 * s)
    for shoulder, elbow, angle, side in ((11, 13, left_arm, 1), (12, 14, right_arm, -1)):
        a = math.radians(angle)
        pts[elbow] = pts[shoulder] + (side * 100 * math.sin(a), 100 * math.cos(a))
    for hip, knee, ankle in ((23, 25, 27), (24, 26, 28)):
        pts[knee] = pts[hip] + (0, 120)
        pts[ankle] = pts[knee] + (0, 120)
    if left_knee is not None:
        pts[25] = left_knee
        pts[27] = (left_knee[0], left_knee[1] + 120)
    vis[[0, 2, 5]] = face
    return Pose(pts, vis, None, world)


@pytest.fixture(scope="module")
def garments():
    return load_garments(GARMENTS)


# ---------- turn angle ----------

@pytest.mark.parametrize("yaw", [0, 30, 90, -90, -45, 150, 180, -135])
def test_estimate_yaw_round_trip(yaw):
    assert wrap(estimate_yaw(person(yaw, face=1.0 if abs(yaw) <= 90 else 0.0)) - yaw) == pytest.approx(0, abs=0.5)


def test_hidden_face_means_back_turned():
    # MediaPipe often reports a turned back as if the person faced the camera
    assert estimate_yaw(person(0, face=0.05)) == pytest.approx(180)
    assert estimate_yaw(person(30, face=0.05)) == pytest.approx(150)


def test_yaw_tracker_smooths_across_180():
    tracker = YawTracker()
    for yaw in (179, -179, 179, -179, 179):
        tracker.update(person(yaw, face=0.0))
    assert abs(tracker.yaw) == pytest.approx(180, abs=2)


def test_yaw_tracker_keeps_last_angle_without_a_person():
    tracker = YawTracker()
    tracker.update(person(40))
    assert tracker.update(None) == pytest.approx(40)
    tracker.reset()
    assert tracker.yaw is None


# ---------- picking and blending views ----------

def test_pick_views():
    yaws = [-165 + 15 * i for i in range(24)]
    assert pick_views([0.0], 77) == [(0, 1.0)]
    assert pick_views(yaws, 30) == [(yaws.index(30), 1.0)]   # exactly on a view
    halfway = dict(pick_views(yaws, 7.5))
    assert halfway[yaws.index(0)] == pytest.approx(0.5) and halfway[yaws.index(15)] == pytest.approx(0.5)
    near_view = dict(pick_views(yaws, 3))   # close to a view: no cross-fade
    assert near_view[yaws.index(0)] == pytest.approx(1.0)
    wraps = dict(pick_views(yaws, -172.5))  # between 180 and -165
    assert wraps[yaws.index(180)] == pytest.approx(0.5) and wraps[yaws.index(-165)] == pytest.approx(0.5)


def test_axis_transform_maps_the_axis_and_scales_across_it():
    m = axis_transform((10, 0), (10, 100), (50, 50), (150, 50), width_scale=2.0)  # turned 90 degrees
    apply = lambda p: m[:, :2] @ np.float32(p) + m[:, 2]  # noqa: E731
    assert apply((10, 0)) == pytest.approx((50, 50))
    assert apply((10, 100)) == pytest.approx((150, 50))
    assert np.linalg.norm(apply((20, 0)) - apply((10, 0))) == pytest.approx(20)


def test_chest_width():
    image = np.zeros((100, 60, 4), np.uint8)
    image[:, 10:50, 3] = 255
    assert chest_width(Piece(image, np.float32((30, 0)), np.float32((30, 80)))) == pytest.approx(40 / 80)


def test_blended_views_stay_solid():
    frame = np.full((40, 40, 3), 255, np.uint8)
    narrow = np.zeros((40, 40, 4), np.uint8)
    narrow[:, 15:25] = (0, 0, 200, 255)
    wide = np.zeros((40, 40, 4), np.uint8)
    wide[:, 5:35] = (0, 0, 200, 255)
    identity = np.float32([[1, 0, 0], [0, 1, 0]])
    _composite(frame, [(narrow, identity, 0.5), (wide, identity, 0.5)])
    assert tuple(frame[20, 8]) == (0, 0, 200)   # covered by only one view: still solid
    assert tuple(frame[20, 2]) == (255, 255, 255)


# ---------- the demo garments ----------

def test_demo_garments_load(garments):
    assert [g.name for g in garments] == ["Türkiz póló", "Piros csíkos póló", "Fekete póló", "Napsárga póló", "Haaland mez",
                                          "Kék farmer", "Fekete chino", "Szürke jogger", "Keki sort"]
    assert [g.kind for g in garments] == ["top"] * 5 + ["bottom"] * 4
    for g in garments:
        assert len(g.views) == 24
        assert [v.yaw for v in g.views] == sorted(v.yaw for v in g.views)
        assert g.thumbnail.shape[2] == 4
        if g.kind == "top":
            assert g.sleeve is not None and g.leg is None
        else:
            assert g.leg is not None and g.sleeve is None
    shorts = garments[-1]
    assert shorts.leg[0].knee is None              # shorts: no shin part
    assert garments[5].leg[0].knee is not None     # jeans: bend at the knee


def test_thumbnails_only_keeps_the_same_order(garments):
    light = load_garments(GARMENTS, pictures=False)
    assert [g.name for g in light] == [g.name for g in garments]
    assert all(g.views == [] for g in light)


def _coloured(frame, background=225):
    return np.any(frame != background, axis=2)


def test_render_draws_the_shirt_on_the_torso(garments):
    frame = np.full((450, 400, 3), 225, np.uint8)
    assert render_garment(frame, garments[0], person(), 0.0)
    drawn = _coloured(frame)
    assert drawn[220, 200]          # middle of the torso
    assert not drawn[50, 200]       # above the head


def test_sleeve_follows_a_raised_arm(garments):
    down = np.full((450, 400, 3), 225, np.uint8)
    render_garment(down, garments[1], person(left_arm=-10), 0.0)
    up = np.full((450, 400, 3), 225, np.uint8)
    render_garment(up, garments[1], person(left_arm=90), 0.0)   # left arm straight out
    # Out beside the left shoulder (right of the picture), level with it
    assert _coloured(up)[150, 290] and not _coloured(down)[150, 290]


def test_trousers_cover_the_legs_down_to_the_ankles(garments):
    frame = np.full((450, 400, 3), 225, np.uint8)
    assert render_garment(frame, garments[5], person(), 0.0)
    drawn = _coloured(frame)
    assert drawn[300, 200]                      # hips
    assert drawn[420, 230] and drawn[420, 170]  # both legs above the knees
    assert drawn[530 - 100, 230]                # and down past the knees
    frame = np.full((600, 400, 3), 225, np.uint8)
    render_garment(frame, garments[5], person(), 0.0)
    assert _coloured(frame)[530, 230] and not _coloured(frame)[530, 200]   # shins, with a gap between


def test_shorts_stop_above_the_knee(garments):
    frame = np.full((600, 400, 3), 225, np.uint8)
    render_garment(frame, garments[8], person(), 0.0)
    drawn = _coloured(frame)
    assert drawn[340, 230]
    assert not drawn[420, 230]   # the knee is at 420


def test_trouser_leg_follows_a_raised_knee(garments):
    # left knee lifted out to the side (the right of the picture), level with the hip
    up = np.full((600, 500, 3), 225, np.uint8)
    render_garment(up, garments[5], person(left_knee=(350, 300)), 0.0)
    down = np.full((600, 500, 3), 225, np.uint8)
    render_garment(down, garments[5], person(), 0.0)
    assert _coloured(up)[300, 330] and not _coloured(down)[300, 330]   # along the thigh
    assert _coloured(up)[380, 350] and not _coloured(down)[380, 350]   # the shin hangs from the knee
    assert not _coloured(up)[400, 230]   # nothing left where the leg was


def test_bent_limb_keeps_its_width_at_the_bend():
    image = np.zeros((100, 20, 4), np.uint8)
    image[:, :] = (0, 0, 200, 255)
    src = [(10, 0), (10, 50), (10, 100)]
    dst = [(50, 50), (50, 100), (100, 100)]   # down, then a right angle to the right
    canvas, place, _ = _bent_limb(image, src, dst, 1.0, False)
    frame = np.full((200, 200, 3), 255, np.uint8)
    _composite(frame, [(canvas, place, 1.0)])
    drawn = _coloured(frame, 255)
    assert drawn[75, 50] and drawn[100, 75]      # along both parts
    assert drawn[109, 41]                        # the outside corner of the bend is filled
    assert not drawn[75, 65] and not drawn[85, 80]


def test_bottom_without_hips_draws_nothing(garments):
    pose = person()
    pose.visibility[[LEFT_HIP, 24]] = 0.0
    frame = np.full((450, 400, 3), 225, np.uint8)
    assert not render_garment(frame, garments[5], pose, 0.0)


def test_leg_without_the_ankle_carries_on_straight(garments):
    pose = person()
    pose.visibility[LEFT_ANKLE] = 0.0
    frame = np.full((600, 400, 3), 225, np.uint8)
    render_garment(frame, garments[5], pose, 0.0)
    assert _coloured(frame)[500, 230]
    assert LEFT_KNEE == 25


def test_shirt_hangs_over_the_trousers(garments):
    frame = np.full((450, 400, 3), 225, np.uint8)
    outfit = Outfit([g.kind for g in garments])
    for index in outfit.worn:
        render_garment(frame, garments[index], person(), 0.0)
    teal = frame[290, 200].astype(int)
    assert teal[0] > teal[2]                     # the hem of the teal shirt, over the jeans' waist
    jeans = frame[420, 230].astype(int)
    assert jeans[0] > 80 and jeans[2] < 80       # blue legs below it


# ---------- outfit ----------

def test_outfit_starts_dressed_and_swaps_by_kind():
    outfit = Outfit(["top", "top", "bottom", "bottom"])
    assert outfit.worn == [2, 0]                 # bottom first
    outfit.select(1)
    assert outfit.worn == [2, 1]                 # the other top, same trousers
    outfit.select(3)
    assert outfit.worn == [3, 1]


def test_outfit_takes_off_what_is_tapped_again():
    outfit = Outfit(["top", "bottom"])
    outfit.select(1)
    assert outfit.worn == [0]
    outfit.select(1)
    assert outfit.worn == [1, 0]
    outfit.toggle()
    outfit.select(0)                             # clothes were hidden: show them, keep the top
    assert outfit.visible and outfit.worn == [1, 0]


def test_outfit_steps_through_bottoms_and_none():
    outfit = Outfit(["top", "bottom", "top", "bottom"])
    seen = []
    for _ in range(3):
        outfit.step("bottom", 1)
        seen.append(outfit.bottom)
    assert seen == [3, None, 1]
    outfit.step("top", 1)
    assert outfit.top == 2
    outfit.step("top", 1)
    assert outfit.top == 0                       # tops don't go through "none"


def test_no_sleeve_without_the_elbow(garments):
    pose = person(left_arm=90)
    pose.visibility[LEFT_ELBOW] = 0.1
    frame = np.full((450, 400, 3), 225, np.uint8)
    render_garment(frame, garments[1], pose, 0.0)
    assert not _coloured(frame)[150, 290]


def test_near_sleeve_in_front_when_side_on():
    side = person(90)
    assert _nearer_side(side, LEFT_SHOULDER, 90)       # left side towards the camera
    assert not _nearer_side(side, RIGHT_SHOULDER, 90)
    assert not _nearer_side(person(0), LEFT_SHOULDER, 0)   # facing: both behind the shirt
    assert not _nearer_side(person(-90), LEFT_SHOULDER, -90)
    assert _nearer_side(person(-90), RIGHT_SHOULDER, -90)
    assert RIGHT_ELBOW == 14

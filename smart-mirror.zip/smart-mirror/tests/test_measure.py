import math

import numpy as np
import pytest

from mirror.camera import full_view_mode
from mirror.measure import (
    Geometry,
    crotch_row,
    cut_off,
    distance_from_feet,
    floor_distance_m,
    measure_pose,
    median_measurements,
    outline_height_px,
    run_width_px,
    tilt_for_floor_distance,
    to_centimetres,
)
from mirror.pose import LEFT_HIP, LEFT_KNEE, LEFT_SHOULDER, RIGHT_HIP, RIGHT_KNEE, RIGHT_SHOULDER, Pose

LINES = {"chest": 0.25, "waist": 0.65, "hip": 1.0}


def make_person(width_px=100, top=50, bottom=450, shoulder_y=120, hip_y=280, w=400, h=500,
                hide=()):
    """A rectangle 'person' centred in the frame, with one arm held away from the body."""
    mask = np.zeros((h, w), np.float32)
    cx = w // 2
    mask[top:bottom + 1, cx - width_px // 2: cx + width_px // 2] = 1.0
    mask[shoulder_y:hip_y, 20:40] = 1.0  # arm, separated from the torso by a gap
    points = np.zeros((33, 2), np.float32)
    visibility = np.ones(33, np.float32)
    points[LEFT_SHOULDER] = (cx + 40, shoulder_y)
    points[RIGHT_SHOULDER] = (cx - 40, shoulder_y)
    points[LEFT_HIP] = (cx + 30, hip_y)
    points[RIGHT_HIP] = (cx - 30, hip_y)
    for i in hide:
        visibility[i] = 0.0
    return Pose(points, visibility, mask)


def test_run_width_ignores_separate_arm():
    pose = make_person(width_px=100)
    assert run_width_px(pose.mask, 200, 200) == 100


def test_run_width_outside_body_is_none():
    pose = make_person()
    assert run_width_px(pose.mask, 200, 5) is None


def test_outline_height():
    pose = make_person(top=50, bottom=450)
    assert outline_height_px(pose.mask) == 401


def test_measure_pose_scales_by_distance():
    pose = make_person(width_px=100, top=50, bottom=449)
    # 400 px tall at 2 m with f = 500 px -> 1.6 m; 100 px -> 0.4 m
    result = measure_pose(pose, f_px=500, distance_m=2.0, lines=LINES)
    assert result["height_m"] == pytest.approx(1.6)
    assert result["widths_m"]["chest"] == pytest.approx(0.4)


def test_one_hidden_shoulder_and_hip_is_enough():
    pose = make_person(hide=(RIGHT_SHOULDER, RIGHT_HIP))
    result = measure_pose(pose, f_px=500, distance_m=2.0, lines=LINES)
    assert result["widths_m"]["waist"] == pytest.approx(0.4)


def test_measure_pose_needs_shoulders_and_hips():
    pose = make_person(hide=(LEFT_SHOULDER, RIGHT_SHOULDER))
    assert measure_pose(pose, 500, 2.0, LINES) is None
    assert measure_pose(None, 500, 2.0, LINES) is None


def test_median_drops_outliers_and_needs_enough_frames():
    good = {"height_m": 1.70, "widths_m": {"chest": 0.40}}
    bad = {"height_m": 2.40, "widths_m": {"chest": 0.90}}
    combined = median_measurements([good, good, bad, good, None])
    assert combined["height_m"] == pytest.approx(1.70)
    assert combined["widths_m"]["chest"] == pytest.approx(0.40)
    assert combined["frames"] == 4
    assert median_measurements([good, None, None]) is None


def test_to_centimetres():
    result = to_centimetres({"height_m": 1.7534, "widths_m": {"chest": 0.3211, "hip": None}})
    assert result == {"height_cm": 175.3, "width_cm": {"chest": 32.1, "hip": None}}
    legs = to_centimetres({"height_m": 1.7, "widths_m": {}, "legs_m": {"leg": 0.8, "inside_leg": None}})
    assert legs["legs_cm"] == {"leg": 80.0, "inside_leg": None}


# ---------- legs ----------

def make_legged_person(legs_apart=True, w=400, h=500):
    """Torso from 50 down to the crotch at row 300, then two legs to the
    floor (the outline ends on row 449). Hips at row 280, knees at 370."""
    mask = np.zeros((h, w), np.float32)
    mask[50:300, 150:250] = 1.0             # head and torso
    mask[120:280, 20:40] = 1.0              # an arm, away from the body
    if legs_apart:
        mask[300:450, 205:245] = 1.0        # left leg (right of the picture)
        mask[300:450, 155:195] = 1.0        # right leg
    else:
        mask[300:450, 160:240] = 1.0
    points = np.zeros((33, 2), np.float32)
    visibility = np.ones(33, np.float32)
    points[LEFT_SHOULDER], points[RIGHT_SHOULDER] = (240, 120), (160, 120)
    points[LEFT_HIP], points[RIGHT_HIP] = (225, 280), (175, 280)
    points[LEFT_KNEE], points[RIGHT_KNEE] = (225, 370), (175, 370)
    return Pose(points, visibility, mask)


def test_crotch_is_where_the_gap_between_the_legs_ends():
    pose = make_legged_person()
    assert crotch_row(pose, pose.mask) == 300
    together = make_legged_person(legs_apart=False)
    assert crotch_row(together, together.mask) is None


def test_leg_sizes():
    # f = 500 px at 2 m: 1 px = 4 mm
    legs = measure_pose(make_legged_person(), 500, 2.0, LINES)["legs_m"]
    assert legs["leg"] == pytest.approx(170 * 0.004)          # hips (280) to the floor (450)
    assert legs["inside_leg"] == pytest.approx(150 * 0.004)   # crotch (300) to the floor
    assert legs["thigh"] == pytest.approx(40 * 0.004)


def test_legs_together_still_give_the_leg_length():
    legs = measure_pose(make_legged_person(legs_apart=False), 500, 2.0, LINES)["legs_m"]
    assert legs["leg"] == pytest.approx(0.68)
    assert legs["inside_leg"] is None and legs["thigh"] is None


def test_median_combines_legs():
    frames = [measure_pose(make_legged_person(), 500, 2.0, LINES) for _ in range(3)]
    assert median_measurements(frames)["legs_m"]["inside_leg"] == pytest.approx(0.6)


# ---------- camera tilt and distance from the feet ----------

def test_no_tilt_is_the_plain_pinhole_rule():
    geo = Geometry(f_px=500, frame_h=480, distance_m=2.0)
    assert geo.length_m(40, 440) == pytest.approx(400 * 2.0 / 500)
    assert geo.width_m(100, 300) == pytest.approx(100 * 2.0 / 500)


def _row(angle_below_deg, tilt_deg, f_px=500, frame_h=480):
    """The picture row of something this far below the horizon."""
    return frame_h / 2 + f_px * math.tan(math.radians(angle_below_deg - tilt_deg))


def test_tilted_camera_measures_true_height():
    # Camera 2.0 m up, tilted 25 degrees down, person 2.5 m away, 1.70 m tall
    head = _row(math.degrees(math.atan2(2.0 - 1.70, 2.5)), 25)
    feet = _row(math.degrees(math.atan2(2.0, 2.5)), 25)
    geo = Geometry(f_px=500, frame_h=480, distance_m=2.5, tilt_deg=25)
    assert geo.length_m(head, feet) == pytest.approx(1.70)
    # Ignoring the tilt gets it wrong
    assert abs(Geometry(500, 480, 2.5).length_m(head, feet) - 1.70) > 0.05


def test_floor_distance_and_tilt_calibration_agree():
    for distance in (1.5, 2.3, 3.5):
        row = _row(math.degrees(math.atan2(1.9, distance)), 30)
        assert floor_distance_m(row, 480, 500, 1.9, 30) == pytest.approx(distance)
        assert tilt_for_floor_distance(row, 480, 500, 1.9, distance) == pytest.approx(30)
    assert floor_distance_m(10, 480, 500, 1.9, 0) is None   # above the horizon


def test_distance_from_feet():
    pose = make_legged_person()   # outline ends at row 450
    tilt = tilt_for_floor_distance(450, 500, 500, 1.9, 2.2)
    assert distance_from_feet(pose, 500, 1.9, tilt, 0.12) == pytest.approx(2.32)
    cut = make_legged_person(h=450)
    assert distance_from_feet(cut, 500, 1.9, tilt, 0.12) is None   # feet off the bottom


def test_cut_off_feet_are_refused():
    pose = make_person(top=50, bottom=499)  # outline runs to the bottom edge
    assert cut_off(pose.mask)
    assert measure_pose(pose, 500, 2.0, LINES) is None


def test_cut_off_head_is_refused():
    pose = make_person(top=0, bottom=450)
    assert measure_pose(pose, 500, 2.0, LINES) is None


def test_width_running_off_the_side_is_ignored():
    pose = make_person(width_px=400)  # torso as wide as the picture
    assert run_width_px(pose.mask, 200, 200) is None


# Camera Module 2 (IMX219), as Picamera2 lists its modes
IMX219_MODES = [
    {"size": (640, 480), "crop_limits": (1000, 752, 1280, 960), "bit_depth": 10},
    {"size": (1640, 1232), "crop_limits": (0, 0, 3280, 2464), "bit_depth": 10},
    {"size": (1920, 1080), "crop_limits": (680, 692, 1920, 1080), "bit_depth": 10},
    {"size": (3280, 2464), "crop_limits": (0, 0, 3280, 2464), "bit_depth": 10},
]


def test_full_view_mode_skips_cropped_modes():
    assert full_view_mode(IMX219_MODES, (640, 480))["size"] == (1640, 1232)


def test_full_view_mode_needs_mode_info():
    assert full_view_mode([], (640, 480)) is None
    assert full_view_mode([{"size": (640, 480)}], (640, 480)) is None


class _FakePicamera2:
    sensor_modes = IMX219_MODES

    def create_video_configuration(self, main, sensor=None):
        return {"main": main, "sensor": sensor}


class _OldFakePicamera2:  # a Picamera2 version without the sensor option
    sensor_modes = IMX219_MODES

    def create_video_configuration(self, main, raw=None):
        return {"main": main, "raw": raw}


def test_camera_asks_for_the_full_view_mode():
    from types import SimpleNamespace

    from mirror.camera import Camera
    from mirror.config import CameraConfig

    cfg = CameraConfig()
    new = Camera._full_view_configuration(SimpleNamespace(_picam=_FakePicamera2()), cfg)
    assert new["sensor"] == {"output_size": (1640, 1232), "bit_depth": 10}
    assert new["main"]["size"] == (640, 480)
    old = Camera._full_view_configuration(SimpleNamespace(_picam=_OldFakePicamera2()), cfg)
    assert old["raw"] == {"size": (1640, 1232)}

"""Matching the measurement pose, and settings from older config files."""
import json
import math

import numpy as np
import pytest

from mirror.config import Config, load_config
from mirror.pose import (
    LEFT_ANKLE,
    LEFT_ELBOW,
    LEFT_EYE,
    LEFT_HIP,
    LEFT_KNEE,
    LEFT_SHOULDER,
    LEFT_WRIST,
    NOSE,
    RIGHT_ANKLE,
    RIGHT_ELBOW,
    RIGHT_EYE,
    RIGHT_HIP,
    RIGHT_KNEE,
    RIGHT_SHOULDER,
    RIGHT_WRIST,
    Pose,
)
from mirror.posecheck import HINTS, match_pose
from mirror.text import whole


def stand(arms=(35.0, 35.0), feet=1.8, elbow=0.0, yaw=0.0, hidden=(), mask=None):
    """Someone standing upright, facing the camera: shoulders at row 200, hips
    at 400 (80 px apart), ankles at 760. arms: (left, right) degrees out from
    the sides; feet: ankles apart in hip widths; elbow: how bent the elbows are."""
    pts = np.zeros((33, 2), np.float32)
    vis = np.ones(33, np.float32)
    cx = 300.0
    pts[NOSE], pts[LEFT_EYE], pts[RIGHT_EYE] = (cx, 120), (cx + 12, 112), (cx - 12, 112)
    pts[LEFT_SHOULDER], pts[RIGHT_SHOULDER] = (cx + 60, 200), (cx - 60, 200)   # own left: picture right
    pts[LEFT_HIP], pts[RIGHT_HIP] = (cx + 40, 400), (cx - 40, 400)
    for side, angle, shoulder, el, wrist in ((1, arms[0], LEFT_SHOULDER, LEFT_ELBOW, LEFT_WRIST),
                                             (-1, arms[1], RIGHT_SHOULDER, RIGHT_ELBOW, RIGHT_WRIST)):
        a, b = math.radians(angle), math.radians(angle + elbow)
        pts[el] = pts[shoulder] + (side * 110 * math.sin(a), 110 * math.cos(a))
        pts[wrist] = pts[el] + (side * 100 * math.sin(b), 100 * math.cos(b))
    for side, hip, knee, ankle in ((1, LEFT_HIP, LEFT_KNEE, LEFT_ANKLE), (-1, RIGHT_HIP, RIGHT_KNEE, RIGHT_ANKLE)):
        pts[ankle] = (cx + side * feet * 40, 760)
        pts[knee] = (pts[hip] + pts[ankle]) / 2
    vis[list(hidden)] = 0.0
    world = np.zeros((33, 3), np.float32)
    c, s = math.cos(math.radians(yaw)), math.sin(math.radians(yaw))
    world[LEFT_SHOULDER], world[RIGHT_SHOULDER] = (0.19 * c, -0.5, -0.19 * s), (-0.19 * c, -0.5, 0.19 * s)
    return Pose(pts, vis, mask, world)


def test_the_measurement_pose_matches():
    match = match_pose(stand(), 0.0)
    assert match.score > 0.95 and match.hint is None


def test_arms_against_the_body_fail():
    match = match_pose(stand(arms=(3, 3)), 0.0)
    assert match.score < 0.75 and match.hint == HINTS["arms_out"]
    assert match_pose(stand(arms=(3, 35)), 0.0).score < 0.75     # one arm is enough to spoil the widths


def test_arms_too_high_fail():
    match = match_pose(stand(arms=(90, 90)), 0.0)
    assert match.score < 0.75 and match.hint == HINTS["arms_down"]


def test_feet_together_still_pass_but_get_a_hint():
    match = match_pose(stand(feet=0.5), 0.0)
    assert 0.75 <= match.score < 0.85 and match.hint == HINTS["feet_apart"]


def test_bent_elbows_get_a_hint():
    assert match_pose(stand(elbow=70), 0.0).hint == HINTS["elbows"]


def test_turned_away_fails():
    match = match_pose(stand(), 80.0)
    assert match.score < 0.75 and match.hint == HINTS["facing"]


def test_out_of_view_fails():
    match = match_pose(stand(hidden=(LEFT_ANKLE, RIGHT_ANKLE)), 0.0)
    assert match.score < 0.75 and match.hint == HINTS["in_view"]
    mask = np.zeros((800, 600), np.float32)
    mask[100:800, 250:350] = 1.0   # the outline runs off the bottom of the picture
    assert match_pose(stand(mask=mask), 0.0).score < 0.75
    assert match_pose(None, None).score == 0


def test_measurements_are_shown_in_whole_centimetres():
    assert [whole(v) for v in (175.3, 174.5, 34.49, 88.0)] == ["175", "175", "34", "88"]


# ---------- settings ----------

def test_old_countdown_setting_is_ignored(tmp_path):
    path = tmp_path / "config.json"
    path.write_text(json.dumps({"mirror": {"measure_countdown_s": 5, "fixed_distance_m": 2.5}}))
    assert load_config(path).mirror.fixed_distance_m == 2.5
    assert Config().mirror.fixed_distance_m == 2.4


def test_old_size_chart_is_ignored(tmp_path):
    path = tmp_path / "config.json"
    path.write_text(json.dumps({"sizes": {"top_chest_cm": [86, 94, 102, 110, 118]}}))
    load_config(path)
    path.write_text(json.dumps({"mirror": {"no_such_setting": 1}}))
    with pytest.raises(ValueError):   # anything else unknown is still an error
        load_config(path)


def test_distance_advice():
    from mirror.text import distance_advice
    assert distance_advice(2.42, 2.4, 0.15) == ("Távolság: 2,42 m – jó helyen állsz!", True)
    assert distance_advice(2.08, 2.4, 0.15) == ("Távolság: 2,08 m – lépj hátrébb kb. 30 cm-t!", False)
    assert distance_advice(2.71, 2.4, 0.15) == ("Távolság: 2,71 m – lépj közelebb kb. 30 cm-t!", False)
    assert distance_advice(None, 2.4, 0.15)[1] is False
    assert Config().mirror.fixed_distance_m == 2.4

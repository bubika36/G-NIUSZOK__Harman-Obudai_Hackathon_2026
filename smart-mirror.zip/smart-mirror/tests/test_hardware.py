"""The ultrasonic sensor reader, on gpiozero's simulated pins."""
import threading
import time

import pytest

gpiozero = pytest.importorskip("gpiozero")
from gpiozero import Device  # noqa: E402
from gpiozero.pins.mock import MockFactory  # noqa: E402

from mirror.hardware import SPEED_OF_SOUND_M_S, DistanceReader  # noqa: E402

TRIG, ECHO = 23, 24


@pytest.fixture(autouse=True)
def mock_pins():
    Device.pin_factory = MockFactory()
    yield Device.pin_factory
    Device.pin_factory.reset()


def answer_pings(reader, distance_m):
    """Make the simulated sensor answer each ping with an echo for distance_m.
    Set reader.silent = True to stop answering."""
    echo_pin = Device.pin_factory.pin(ECHO)
    width = 2 * distance_m / SPEED_OF_SOUND_M_S
    original_off = reader._trigger.off
    reader.silent = False

    def off_and_echo():
        original_off()
        if reader.silent:
            return

        def pulse():
            time.sleep(0.0005)
            echo_pin.drive_high()
            time.sleep(width)
            echo_pin.drive_low()

        threading.Thread(target=pulse, daemon=True).start()

    reader._trigger.off = off_and_echo


def test_measures_distance():
    reader = DistanceReader(TRIG, ECHO)
    answer_pings(reader, 2.0)
    time.sleep(0.8)
    assert reader.read() == pytest.approx(2.0, abs=0.25)
    reader.close()


def test_no_echo_never_waits():
    reader = DistanceReader(TRIG, ECHO)  # nothing answers
    time.sleep(0.4)
    started = time.monotonic()
    assert reader.read() is None
    assert time.monotonic() - started < 0.05
    reader.close()


def test_old_echoes_expire():
    reader = DistanceReader(TRIG, ECHO)
    answer_pings(reader, 1.5)
    time.sleep(0.8)
    assert reader.read() is not None
    reader.silent = True  # the person walks away
    time.sleep(reader.FRESH_S + 0.3)
    assert reader.read() is None
    reader.close()


def test_out_of_range_counts_as_no_echo():
    reader = DistanceReader(TRIG, ECHO)
    answer_pings(reader, 6.5)  # what the sensor sends when it hears nothing
    time.sleep(0.8)
    assert reader.read() is None
    reader.close()


def test_without_pins():
    reader = DistanceReader(None, None)
    assert reader.read() is None

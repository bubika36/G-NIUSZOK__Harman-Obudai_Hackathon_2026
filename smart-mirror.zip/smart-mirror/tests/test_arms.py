"""Sleeves and the person's own arms in front of or behind the body."""
import numpy as np

from mirror.arms import BACK, FRONT, ArmPlace, ArmTracker, arm_mask, show_arms
from mirror.garments import Garment, Piece, View, _levels, chest_width, render_garment
from mirror.pose import LEFT_ELBOW, LEFT_WRIST, RIGHT_ELBOW, RIGHT_WRIST
from tests.test_garments import person


def with_depth(pose, left_elbow=0.0, left_wrist=0.0, right_elbow=0.0, right_wrist=0.0):
    """Sets how far each elbow and wrist is from the body (metres, negative = nearer the camera)."""
    pose.world[[11, 12, 23, 24], 2] = 0.0
    for joint, z in ((LEFT_ELBOW, left_elbow), (LEFT_WRIST, left_wrist),
                     (RIGHT_ELBOW, right_elbow), (RIGHT_WRIST, right_wrist)):
        pose.world[joint, 2] = z
    return pose


def test_arm_in_front_behind_and_beside():
    places = ArmTracker().update(with_depth(person(), left_elbow=-0.25, left_wrist=-0.3, right_wrist=0.25))
    assert places["left"] == ArmPlace(sleeve=FRONT, forearm=FRONT)
    assert places["right"] == ArmPlace(sleeve=None, forearm=BACK)


def test_arm_doesnt_flicker_at_the_edge():
    tracker = ArmTracker(smoothing=1.0)   # no smoothing: only the gap between enter and leave
    assert tracker.update(with_depth(person(), left_elbow=-0.13))["left"].sleeve == FRONT
    assert tracker.update(with_depth(person(), left_elbow=-0.10))["left"].sleeve == FRONT   # still in front
    assert tracker.update(with_depth(person(), left_elbow=-0.06))["left"].sleeve is None
    assert tracker.update(with_depth(person(), left_elbow=-0.10))["left"].sleeve is None    # not yet again


def test_hidden_joint_keeps_its_place_and_nobody_resets():
    tracker = ArmTracker()
    tracker.update(with_depth(person(), left_elbow=-0.3))
    pose = with_depth(person(), left_elbow=0.3)
    pose.visibility[LEFT_ELBOW] = 0.1
    assert tracker.update(pose)["left"].sleeve == FRONT
    assert tracker.update(None) == {}


def two_colour_shirt() -> Garment:
    """A red shirt body with blue sleeves, to tell them apart."""
    body = np.zeros((300, 200, 4), np.uint8)
    body[20:300, 20:180] = (0, 0, 200, 255)
    piece = Piece(body, np.float32((100, 40)), np.float32((100, 280)))
    sleeve = np.zeros((100, 60, 4), np.uint8)
    sleeve[:, :] = (200, 0, 0, 255)
    return Garment("test", [View(0.0, _levels(piece), chest_width(piece))],
                   _levels(Piece(sleeve, np.float32((30, 0)), np.float32((30, 100)))), body)


def test_sleeve_goes_in_front_of_the_shirt_for_an_arm_across_the_chest():
    pose = person()
    pose.points[LEFT_ELBOW] = (200, 230)   # the left elbow in front of the middle of the chest
    shirt = two_colour_shirt()
    across = np.full((400, 400, 3), 255, np.uint8)
    render_garment(across, shirt, pose, 0.0, {"left": ArmPlace(sleeve=FRONT)})
    assert tuple(across[190, 225]) == (200, 0, 0)       # blue sleeve over the red shirt
    behind = np.full((400, 400, 3), 255, np.uint8)
    render_garment(behind, shirt, pose, 0.0, {})
    assert tuple(behind[190, 225]) == (0, 0, 200)       # without it, the shirt covers the sleeve


def test_real_forearm_shows_over_the_clothes_unless_behind():
    pose = person(left_arm=60)                  # left elbow out to the side, at (337, 200)
    pose.points[LEFT_WRIST] = (220, 260)       # and the forearm across the body
    pose.visibility[17:23] = 0.0               # no hand points in this stand-in
    pose.mask = np.ones((400, 400), np.float32)
    original = np.full((400, 400, 3), (0, 160, 0), np.uint8)       # the camera picture: green
    middle = (pose.points[LEFT_ELBOW] + pose.points[LEFT_WRIST]) / 2
    x, y = int(middle[0]), int(middle[1])
    for place, expected in ((ArmPlace(forearm=FRONT), (0, 160, 0)), (ArmPlace(forearm=None), (0, 160, 0)),
                            (ArmPlace(forearm=BACK), (0, 0, 200))):
        drawn = np.full((400, 400, 3), (0, 0, 200), np.uint8)     # the clothes: red
        show_arms(drawn, original, pose, {"left": place})
        assert tuple(drawn[y, x]) == expected, place
    assert RIGHT_ELBOW == 14 and RIGHT_WRIST == 16


def test_arms_never_bring_back_the_background():
    pose = person()
    pose.mask = np.zeros((400, 400), np.float32)   # nobody there, according to the outline
    drawn = np.full((400, 400, 3), (0, 0, 200), np.uint8)
    show_arms(drawn, np.zeros_like(drawn), pose, {})
    assert (drawn == (0, 0, 200)).all()
    assert arm_mask((400, 400), pose, {}).any()   # though the arms themselves were found

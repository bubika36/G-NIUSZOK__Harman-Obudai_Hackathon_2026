"""The pose phase before a measurement, with a stand-in camera."""
import threading
import time

from mirror.config import Config
from run_mirror import Measurer, MirrorState
from tests.test_posecheck import stand


class FakeLoop:
    """Hands out a freshly tracked pose every time, like the tracker would."""

    def __init__(self, **pose):
        self.pose = pose

    def latest(self):
        return None, stand(**self.pose), 0


class NoSensor:
    def read(self):
        return None


def measurer(**pose) -> Measurer:
    cfg = Config()
    cfg.camera.calibration_file = "/nonexistent/calibration.json"
    cfg.mirror.pose_hold_s = 0.15
    cfg.mirror.pose_timeout_s = 1.0
    return Measurer(cfg, FakeLoop(**pose), NoSensor(), MirrorState())


def test_measuring_starts_once_the_pose_is_held():
    m = measurer()
    start = time.monotonic()
    assert m.wait_for_pose()
    assert time.monotonic() - start >= 0.15
    assert m.state.pose["score"] > 0.95 and m.state.status == "Remek, maradj így!"


def test_the_guide_stays_until_the_pose_is_right():
    m = measurer(arms=(3, 3))
    assert not m.wait_for_pose()   # gives up after pose_timeout_s
    assert m.state.pose["score"] < 0.75
    assert "Nem sikerült" in m.state.status


def test_cancel_stops_the_guide():
    m = measurer(arms=(3, 3))
    m.cfg.mirror.pose_timeout_s = 30
    outcome = []
    thread = threading.Thread(target=lambda: outcome.append(m.wait_for_pose()))
    thread.start()
    time.sleep(0.2)
    m.cancel()
    thread.join(timeout=2)
    assert outcome == [False] and "megszakítva" in m.state.status

#!/usr/bin/env python3
"""Measure the camera's focal length with a printed chessboard.

Run it once, with the camera mounted the way it will be used.
Hold the chessboard in front of the camera and move and tilt it slowly;
a photo is kept every second when the board is found. The result goes to
camera.calibration_file (camera_calibration.json by default).

Print a chessboard with 10 x 7 squares (9 x 6 inner corners), for example
from https://github.com/opencv/opencv/blob/4.x/doc/pattern.png, and glue
it to something flat. The square size doesn't matter for the focal length.

Run:  python calibrate_camera.py --config config.json [--show]
"""
from __future__ import annotations

import argparse
import json
import sys
import time

import cv2
import numpy as np

from mirror.camera import Camera
from mirror.config import load_config


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--config", default="config.json")
    parser.add_argument("--camera-source")
    parser.add_argument("--corners", default="9x6", help="inner corners, columns x rows")
    parser.add_argument("--shots", type=int, default=15)
    parser.add_argument("--show", action="store_true", help="show the camera image (needs a screen)")
    args = parser.parse_args()

    cfg = load_config(args.config)
    if args.camera_source:
        cfg.camera.source = args.camera_source
    cols, rows = (int(v) for v in args.corners.lower().split("x"))
    grid = np.zeros((cols * rows, 3), np.float32)
    grid[:, :2] = np.mgrid[0:cols, 0:rows].T.reshape(-1, 2)

    camera = Camera(cfg.camera)
    object_points, image_points = [], []
    last_shot, size = 0.0, None
    print(f"Mutasd a sakktáblát a kamerának. {args.shots} fotót készítek...")
    try:
        while len(image_points) < args.shots:
            frame = camera.read()
            if frame is None:
                continue
            gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
            size = gray.shape[::-1]
            found, corners = cv2.findChessboardCorners(
                gray, (cols, rows),
                cv2.CALIB_CB_ADAPTIVE_THRESH | cv2.CALIB_CB_NORMALIZE_IMAGE | cv2.CALIB_CB_FAST_CHECK)
            if found and time.monotonic() - last_shot > 1.0:
                corners = cv2.cornerSubPix(gray, corners, (11, 11), (-1, -1),
                                           (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 30, 0.001))
                object_points.append(grid)
                image_points.append(corners)
                last_shot = time.monotonic()
                print(f"  fotó {len(image_points)}/{args.shots}")
            if args.show:
                view = frame.copy()
                cv2.drawChessboardCorners(view, (cols, rows), corners, found)
                cv2.imshow("calibration (q to stop)", view)
                if cv2.waitKey(1) & 0xFF == ord("q"):
                    break
    except KeyboardInterrupt:
        pass
    finally:
        camera.close()
        cv2.destroyAllWindows()

    if len(image_points) < 5:
        print("Nincs elég fotó a sakktábláról; legalább 5 kell.")
        return 1
    rms, matrix, _, _, _ = cv2.calibrateCamera(object_points, image_points, size, None, None)
    f_px = float((matrix[0, 0] + matrix[1, 1]) / 2)
    data = {"f_px": f_px, "fx": float(matrix[0, 0]), "fy": float(matrix[1, 1]),
            "frame_size": list(size), "rms_error_px": float(rms), "photos": len(image_points)}
    with open(cfg.camera.calibration_file, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2)
    print(f"Fókusztávolság: {f_px:.1f} képpont (hiba: {rms:.2f} képpont), elmentve ide: {cfg.camera.calibration_file}")
    if rms > 1.0:
        print("A hiba nagy: készíts több fotót, jobb fényben, és tartsd a táblát egyenesen, síkban.")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Smart mirror

Code for the hackathon smart mirror: one Raspberry Pi 4 (2 GB) with one
camera. It shows the person mirrored on a monitor or projector wearing the
chosen top and trousers, measures their height, body widths and legs, and is
controlled from the Pi's 7" touchscreen.

```
camera ─ CSI ─► Raspberry Pi 4 ─ micro HDMI ─► monitor / projector (mirror view)
ultrasonic ─ GPIO ─►    │
                        └──── DSI ─► 7" touchscreen (control panel)
```

## Files

| File | What it does |
|---|---|
| `run_mirror.py` | The mirror. Starts the control panel too. |
| `control_panel.py` | The touchscreen panel: garments, toggles, Measure |
| `calibrate_camera.py` | Measures the camera's focal length with a printed chessboard |
| `calibrate_floor.py` | Measures the camera's tilt, for the distance from the feet |
| `make_demo_garments.py` | Draws the demo clothes into `garments/`: four T-shirts and four trousers/shorts (24 views each, sleeves or legs, thumbnails) |
| `config.example.json` | Settings; copy it to `config.json` |
| `mirror/` | Shared code: camera, body tracking, measurement maths, garments, screens |
| `tests/` | Tests that run on a laptop, no camera or screen needed |

## Garments

There are tops (T-shirts) and bottoms (jeans, chinos, joggers and shorts), one
of each worn at a time, the shirt hanging over the trousers. They turn with
the person: each has a picture every 15 degrees, and the mirror picks the one
that matches how far they've turned (using MediaPipe's 3D body points). The
sleeves are separate pieces that follow the upper arms, and each trouser leg
runs from the hip through the knee to the ankle, bending at the knee, so the
legs walk, kneel and kick with the person. From the same 3D body points the
mirror works out whether each arm is in front of the body or behind it: an
arm across the chest, or reaching forward, puts its sleeve in front of the
shirt, and the person's own forearms and hands are shown over the clothes,
unless they're behind the back (`mirror/arms.py`). Turn the skeleton on to
see the turn angle at the top of the mirror. To add your own garments, see
`garments/README.md`.

## The control panel

The screens and messages are in Hungarian (this README and the code are in
English). The 7" touchscreen shows:

- **Felsők** (tops) and **Nadrágok** (bottoms) tabs: tap a garment to put it on; it replaces the
  one of the same kind. Tap the one being worn to take it off (to show the
  person's own trousers, say). Arrows page through more than six.
- **Ruha: be/ki** (clothes on/off) and **Csontváz: be/ki** (skeleton on/off). The skeleton is useful to check that tracking works.
- **Utolsó mérés** (last measurement): height; chest, waist and hip widths;
  leg length and thigh width, in whole centimetres, with the time.
- **Mérés** (measure): the mirror shows a figure in the pose to stand in
  (arms held away from the body, feet a little apart, facing the camera),
  with a percentage for how well the person matches it and a tip for what to
  change. Each part of the figure turns green, amber or red. Measuring starts
  by itself once the pose matches at least 75% (`mirror.pose_match`) for a
  second (`mirror.pose_hold_s`), so there's no rush to walk from the
  touchscreen to the line. Meanwhile the button turns into **Mégse** (cancel)
  with the percentage; the guide gives up after two minutes (`mirror.pose_timeout_s`).
- **Top bar:** whether a person is in view, and how far away they are, which
  helps with standing on the mark: from the ultrasonic sensor, or "(talp alapján)"
  when it comes from where their feet touch the floor (see below). **Kilépés** (exit)
  closes the mirror; tap it twice to confirm.

The panel works in landscape (800 × 480) and portrait. If the mirror isn't
running, it says so and greys out its buttons.

The mirror and the panel are two programs that talk over the Pi's own
network (UDP on 127.0.0.1, ports 5056 and 5057). Either can be restarted
without the other.

## Set up the Pi

1. Flash **Raspberry Pi OS (Legacy, 64-bit)**, with desktop (not Lite, not
   Full), using Raspberry Pi Imager: it's under "Raspberry Pi OS (other)".
   That's Bookworm with Python 3.11. The newer OS has Python 3.13, which the
   last MediaPipe version that runs on a Pi 4 doesn't support. The preloaded
   SD card has the 32-bit OS, which can't run the body tracking at all.
   Set the hostname, user, Wi-Fi and SSH in Imager's settings. Check with
   `dpkg --print-architecture` (`arm64`) and `python3 --version` (3.11).
2. Connect the camera ribbon and the touchscreen, then check the camera:
   `rpicam-hello --list-cameras`
3. Copy this folder to the Pi, then:
   ```bash
   cd smart-mirror
   python3 -m venv --system-site-packages ~/mirror-venv
   ~/mirror-venv/bin/pip install -r requirements.txt
   cp config.example.json config.json
   ```
   `--system-site-packages` lets the program use the Pi's own `picamera2`
   and `gpiozero`; they can't be installed with pip. `requirements.txt` pins
   the versions that work on a Pi 4; a red pip warning about `types-seaborn`
   or `jax` is harmless.
   The body tracking model is already in `models/`. If it's missing, download it:
   ```bash
   wget -O models/pose_landmarker_lite.task https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_lite/float16/latest/pose_landmarker_lite.task
   ```
4. Set `camera.hfov_deg` in `config.json` to match your camera (Camera Module 2:
   62.2, Camera Module 3: 66, the older OV5647 module: 53.5), then calibrate it (below).
   The mirror always uses the camera's full view; it prints the sensor mode
   it picked when it starts.
5. Find which screen is which:
   ```bash
   SDL_VIDEODRIVER=wayland WAYLAND_DISPLAY=wayland-0 ~/mirror-venv/bin/python run_mirror.py --list-displays
   ```
   The touchscreen is the 800 × 480 (or 720 × 1280) one. Put its number in
   `panel.display_index`, and the monitor's number in `mirror.display_index`.

## Place the camera

- Mount it with the lens at about 1.1–1.2 m, turned 90° for a portrait image
  (`camera.rotate: 90`; use 270 if the image is upside down), level if you
  can. If it sits higher, on top of the monitor for example, tilt it down
  until head and feet are in view and run `calibrate_floor.py` (below), so
  the measurements allow for the tilt.
- Put a masking-tape line on the floor 2.4 m in front of it (the default, and
  the best distance), where the whole body, head to feet, is in view. Measure
  from the lens to the line and enter it as `mirror.fixed_distance_m`. It's
  used whenever the ultrasonic sensor has no reading, and by `calibrate_floor.py`.
- Once `calibrate_floor.py` has run, the top of the mirror shows how far away
  the person is, from their feet, and tells them to step back or closer
  (in Hungarian) when they're more than 15 cm (`mirror.distance_tolerance_m`)
  off the line.
- Mount the ultrasonic sensor next to the camera, facing the line.

## Wiring

The HC-SR04 runs on 5 V, so its Echo signal (5 V) goes through a voltage
divider to bring it down to 3.3 V for the Pi:

| Part | Pi pin (physical) | Setting |
|---|---|---|
| Ultrasonic VCC | pin 4 (5 V) | |
| Ultrasonic Trig | pin 16 (GPIO 23) | `mirror.ultrasonic_trigger_pin: 23` |
| Ultrasonic Echo | 1 kΩ from Echo to a joint; 2 kΩ from the joint to GND; the joint to pin 18 (GPIO 24) | `mirror.ultrasonic_echo_pin: 24` |
| Ultrasonic GND | pin 6 | |

Never connect Echo straight to a Pi pin. No 2 kΩ resistor: two 1 kΩ in a
row. If pin 18 gives no signal, use pin 22 (GPIO 25) and set
`ultrasonic_echo_pin` to 25. Pin 2 (5 V) and a GND pin (pin 14) power the
touchscreen. Without the sensor, set both ultrasonic pins to `null`: the
distance then comes from the feet, or the floor mark.

## Calibrate the camera

Print a chessboard with 9 × 6 inner corners (10 × 7 squares), glue it to card, and run:

```bash
~/mirror-venv/bin/python calibrate_camera.py
```

Stop the mirror first: only one program can use the camera at a time. If
there's no printer, show the chessboard full screen on a laptop or tablet.
Move and tilt the board slowly in front of the camera until 15 photos are
taken. The result goes to `camera_calibration.json` and replaces the
`hfov_deg` estimate. Calibrate again whenever the camera's view changes
(another camera, another resolution, or a code update that changes its mode).

## Distance from the feet

Without the ultrasonic sensor, the mirror can tell how far away someone is
from where their feet touch the floor in the picture, once it knows the
camera's height and tilt. It also uses the tilt to correct every measurement.

1. Measure the height of the camera lens above the floor with a tape, for example 1.95 m.
2. Stop the mirror, then run:
   ```bash
   ~/mirror-venv/bin/python calibrate_floor.py --camera-height 1.95
   ```
3. Stand on the floor line, facing the camera, whole body in view, until it
   says it's done (10 seconds to get there, then a few seconds standing still).

It saves `mirror.camera_height_m` and `mirror.camera_tilt_deg` in
`config.json`. The mirror then uses, in order: the ultrasonic sensor, the
feet, the floor-mark distance. Run it again if the camera is moved or tilted.

## Run

From the `smart-mirror` folder, over SSH or in a terminal on the Pi:

```bash
SDL_VIDEODRIVER=wayland WAYLAND_DISPLAY=wayland-0 ~/mirror-venv/bin/python run_mirror.py
```

This opens the mirror on the monitor and the control panel on the
touchscreen. The two settings in front make it use the desktop's own display
system (Wayland), which puts each window on the right screen; with
`DISPLAY=:0` instead, both can end up on the monitor. If
`ls /run/user/$(id -u)/` shows `wayland-1` rather than `wayland-0`, use that.
Every measurement is also appended to `measurements.jsonl`.

Stop it with Ctrl+C, or tap Kilépés (exit) twice on the touchscreen.

A keyboard is optional: **M** measure · **C** cancel · **N/→** next top ·
**P/←** previous top · **B** next bottom (or none) · **G** clothes on/off ·
**S** skeleton on/off · **Q/Esc** quit.

## Test without the hardware

On a laptop with a webcam. `requirements.txt` pins versions for the Pi 4;
on a laptop, especially with Python 3.13, install the newest ones instead:

```bash
python3 -m venv venv && venv/bin/pip install mediapipe pygame pytest gpiozero
venv/bin/python -m pytest
venv/bin/python run_mirror.py --camera-source 0 --windowed
```

Set `"rotate": 0` in `config.json` for a laptop webcam. `--windowed` opens the
mirror and the panel as normal windows. `--camera-source` also takes a video
or image file.

## Making the numbers right

1. Calibrate the camera, measure the floor-mark distance with a tape, and
   run `calibrate_floor.py` if the camera is tilted.
2. Measure a few people with a tape measure and compare with `measurements.jsonl`.
3. If a width is consistently off, move its line in `config.json`
   (`lines.chest`, `lines.waist`, `lines.hip`: 0.0 is the shoulder line, 1.0 the hip joints).
4. The pose guide makes people stand with arms away from the body and feet
   a little apart. Arms against the sides would be counted in the chest and
   waist widths; with the legs together there's no gap below the crotch, so
   the thigh shows "-".
5. What the leg numbers are: **leg** runs from the hip joints to the floor
   (a few centimetres shorter than a tailor's outside leg, which starts at the
   waist); **thigh** is the thigh's width seen from the front, just below the
   crotch. Like the other widths, it's a width, not a circumference. The
   inside leg is still saved in `measurements.jsonl`, but not shown.
6. The screens show whole centimetres; `measurements.jsonl` keeps one
   decimal, for comparing with a tape measure.

## Performance on a Pi 4

- Expect tracking at roughly 5–10 frames per second. If it's too slow, set
  `pose.track_every` to 2: the garment then moves every second frame, but the
  picture stays smooth.
- Set the monitor or projector to 1280 × 720; scaling to 1080p costs frame rate.

## Troubleshooting

- **"compiled with aes enabled … Illegal instruction"**: MediaPipe 1.x got
  installed, which doesn't run on a Pi 4. Install the pinned versions:
  `~/mirror-venv/bin/pip install -r requirements.txt`
- **"numpy.dtype size changed"** when the camera starts: numpy 2 got into the
  environment. Same fix as above.
- **The monitor stays black and the panel says it's waiting for the mirror**:
  start it with the Wayland settings shown under Run.
- **The picture is upside down or sideways**: change `camera.rotate` in
  `config.json` by 180 (upside down) or 90 (sideways). Left and right are
  swapped on purpose, like a real mirror.
- **"Nem látom a teljes alakodat"** (I can't see your whole body): the head, feet or sides touch the edge of
  the picture, so the measurement is refused. Step back, or lower the camera.
- **The distance "(talp alapján)" is wrong**: the camera was moved or tilted after
  `calibrate_floor.py`; run it again. Shoes or shadows that blend into the
  floor make it less exact; the ultrasonic sensor wins whenever it answers.
- **`libEGL.so.1: cannot open shared object file`**: `sudo apt install libegl1 libgles2`
- **The panel opens on the monitor, or the mirror on the touchscreen**: swap
  `mirror.display_index` and `panel.display_index`.
- **Touches land in the wrong place after rotating the touchscreen**: rotate it
  in the Pi's Screen Configuration tool, which turns the touch input with it.
- **The panel says "A tükör nem fut"** (mirror not running): `run_mirror.py` has stopped; check
  its terminal for the error.
